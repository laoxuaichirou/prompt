import json
from pathlib import Path
b=Path(__file__).resolve().parent;D={}
def a(id,n,ch,c,s='存在问题'):D[id]=dict(status=s,generated=n,opened=n,checks=[dict(requirement=x,result=y,evidence=z) for x,y,z in ch],conclusion=c)
a('T176-winter-role',1,[('人物冬装/表情/排版','符合要求','虚构成年人物长浅渐变发、珍珠发箍毛耳罩、白毛衣灰围巾戒指，双手轻握胸前、蓝白雪夜、星点眼妆，GENTLE白色细衬线标题及下方英文信息清楚。'),('动态/原模型','未执行','只验收静态角色视觉；唱歌与镜头互动、Sora2原模型未执行。年龄19为输入设定，不从外貌推定或核验实际年龄。')],'本次冬日静态角色适配符合可见要求，不代表Sora视频通过。','符合要求')
a('T177-rain-couple',1,[('雨夜/服装/雨伞/手机质感','基本符合','浅蓝雨衣女性靠深色卫衣男性，两人透明伞下拥抱；雨滴、霓虹水洼、拉面店自动售货机、雾化角落与褪色手机快照感可辨，9:16。'),('双手抓衣/背景电视','存在问题','女性仅一只抓衣手清楚可见，另一手不可验收；店内电视屏幕未明确出现。属于虚构东京氛围，不是实地或真实Facebook上传。')],'主要情侣雨夜快照实现，手部与背景电视细节未完整满足。')
a('T178-football-poster',1,[('双重曝光/站姿/球衣/文字','符合要求','前景人物偏左，右脚踩球看画右，后景同角色大脸、蓝白红泼墨与泛光体育场，合成7号球衣/圆徽/红袜保留，FRANCE与副标题正确。'),('8K/真实品牌','未满足/未验证','非8K；合成无品牌球衣不是法国官方队服，品牌与赞助商为已记录的适配改动，原版品牌要求未实测。'),('同页其他模板','未执行','其余足球动态/球迷静帧/后备箱/变身/四旅行场景等未执行。')],'静态足球海报适配已出图，8K未满足，原品牌版本与其他模板未覆盖。')
a('T179-fight-video',0,[('范围','本轮不适用','15秒连续动作、破镜状态持续、音效和运镜为核心，纯视频任务。')],'纯视频任务，本轮不适用。','本轮不适用')
(b/'batch36-inspections.json').write_text(json.dumps(D,ensure_ascii=False,indent=2))
p=b/'results/T179-fight-video/test.json';d=json.loads(p.read_text());d['tool']='无（本轮不适用）';p.write_text(json.dumps(d,ensure_ascii=False,indent=2))
