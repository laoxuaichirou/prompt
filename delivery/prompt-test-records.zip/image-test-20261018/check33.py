import json
from pathlib import Path
b=Path(__file__).resolve().parent;D={}
def a(id,n,ch,c,s='存在问题'):D[id]=dict(status=s,generated=n,opened=n,checks=[dict(requirement=x,result=y,evidence=z) for x,y,z in ch],conclusion=c)
a('T161-industrial-scene',2,[('初始/战斗后变体','基本符合','两图古松、云海、剑痕石、悬崖及夕阳位置基本固定，战后有断枝散落和新增石地剑痕。'),('空间精度','存在问题','剑痕石紧贴树根，未明显呈现古松左侧5m间距；高度、色温5500K、0.7阴影等数值未验证。'),('覆盖范围','未执行','只测试正文完整场景模板；角色资产、剧本、视频、音频与缺失的docx/最终V4文档未执行或缺失。')],'场景两变体成图，精确空间未满足；不代表工业影视全流程或视频通过。')
a('T162-design-sheet',1,[('设计表要素/非故事板','符合要求','12设计分区，环体主视觉/结构材质、物理学家语言学家、地面核心、营地封锁、道具、高空几何信息、视距对照、色板均有；不是连续剧情12分镜。'),('原文冲突','模型初评','已单独记录“不写STORYBOARD”与“要写12格分镜。不!”冲突的处理，按主要设计概念表目标验收。')],'本次解释后的电影前期设计概念表用例符合可见要求。','符合要求')
a('T163-missing-agent-system',0,[('原核心资料','缺失','核心CLAUDE.md、Subagents和7Skills只有会员解锁名称，未导出正文；文章结构介绍不等于可实测原系统。')],'原系统核心资料缺失，未补写冒充，未生成图片。','阻塞')
a('T164-qwen-next3',3,[('身份/服饰/场景','基本符合','三图成年男子绿色毛衣和同款Q版、小咖啡、木桌暖吊灯持续，放大杯到点桌的静态状态有推进。'),('镜头/道具连续','存在问题','前两图机位几乎相同，第二张未表现明显较低侧前方；第三张大杯相对男子与模型的位置向左移动，未严格沿用上一镜。'),('覆盖边界','未执行','仅第一组三条Next Scene，后续九键JSON模板未执行；无Qwen原模型或真实运动视频。')],'三张静态连续用例已生成并逐张检查，机位与杯位置一致性有偏差。')
a('T165-character-analysis',3,[('元输出/三视对比','符合要求','先输出包含characters/id/description/features的有效JSON，再独立生成正面、严格左侧、背面三图；白T深蓝裤白鞋和齐下巴黑发一致。'),('边界','未执行/未验证','背面为原图不可见区域的合成推断；100%身份/真实LoRA不验证，同页20镜等其余三个元任务未执行。')],'首个人物分析元任务及三视角最小用例符合主要视觉要求，不覆盖整套工作流。','符合要求')
(b/'batch33-inspections.json').write_text(json.dumps(D,ensure_ascii=False,indent=2))
p=b/'results/T163-missing-agent-system/test.json';d=json.loads(p.read_text());d['tool']='无（核心缺失未调用）';p.write_text(json.dumps(d,ensure_ascii=False,indent=2))
