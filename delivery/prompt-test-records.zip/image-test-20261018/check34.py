import json
from pathlib import Path
b=Path(__file__).resolve().parent;D={}
def a(id,n,ch,c,s='存在问题'):D[id]=dict(status=s,generated=n,opened=n,checks=[dict(requirement=x,result=y,evidence=z) for x,y,z in ch],conclusion=c)
a('T166-dog-story',3,[('逐镜过程/花园连续','基本符合','三张独立输出：出箱、四爪落地发现青蛙、低头靠近；共同初始参考与上一张引用真实保存，箱子篱笆红黄花及暖光延续。'),('外形不变','存在问题','后两张狗眼白与眼球比例扩大，前腿较长，未严格保持首图体型/脸部；第三张青蛙旁残留白色动作装饰线。'),('范围','未执行','自定义N3完整小故事已执行，原九镜上街例及真实运动视频未执行。')],'三镜故事推进实现，狗的眼部/体型一致性有偏差。')
a('T167-video-director',0,[('范围','本轮不适用','纯8秒动态视频脚本任务，无静态生图要求。')],'纯视频任务，本轮不适用。','本轮不适用')
a('T168-video-reverse',0,[('范围','本轮不适用','按视频逐秒反推并生成新视频，未提供视频，非图像任务。')],'纯视频任务，本轮不适用。','本轮不适用')
a('T169-wan-text-shots',2,[('两步动作/文字/人物','基本符合','两张依次拿牌、挂门，春字均正确，白T深蓝裤和短发基本一致，花店氛围连续。'),('道具背景一致','存在问题','木牌从横版白字变竖版黑字，第一张玻璃多格门变第二张实木门，未保持同一物件和背景结构。2026/东京属于虚构设定，不是地点事实验证。')],'元任务已执行两图，关键文字正确但木牌与门结构明显漂移。')
a('T170-swordsman-asset',1,[('角色/衣服/剑/风格','基本符合','成年剑仙月白流云长袍、长剑剑穗、修长身形，CG电影侧逆光与16:9基本完成。'),('8K/其余流程','未满足/未执行','非8K；仅原文完整华山角色资产示例，上文一分钟四段元任务、其余三角色和视频未执行。')],'单角色资产已出图，8K未满足，不代表全漫剧流程通过。')
(b/'batch34-inspections.json').write_text(json.dumps(D,ensure_ascii=False,indent=2))
for name in ['T167-video-director','T168-video-reverse']:
 p=b/'results'/name/'test.json';d=json.loads(p.read_text());d['tool']='无（本轮不适用）';p.write_text(json.dumps(d,ensure_ascii=False,indent=2))
