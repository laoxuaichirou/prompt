from pathlib import Path
import json,re
from prepare_batch import B
inv=json.loads((B/'inventory.json').read_text());w=str(B/'materials/adult-woman-synthetic.png');cafe=str(next((B/'results').glob('T145*/*.png')))
def body(t):return (B/next(r['local_path'] for r in inv if Path(r['original_filename']).name.endswith('] '+t+'.md'))).read_text().split('## 正文',1)[1]
a=[]
t='工业级影视生成流程';s=body(t);p='青云崖场景，前景：岩石地面 + 剑痕石（古松左侧 5m，高 0.5m），中景：千年古松（树干直径 1.5m，高 20m），远景：云海（悬崖下方 10m，厚度 50m），角色活动区域：古松周围 10㎡，光影：黄昏侧逆光，色温 5500K，阴影浓度 0.7，古风冷色调'
assert p in s
initial='仅生成静态写实电影场景资产，不加人物或文字。初始版：'+p
battle='参考同一场景初始版，保持岩石/古松/剑痕石/云海位置及相机光影。战斗后版：古松枝叶散落，地面新增剑痕。'+p
bd=str(B/'results/T161-industrial-scene/initial.png')
a.append(dict(id='T161-industrial-scene',title=t,type='流程中完整场景生图模板',input='仅测试正文Step2完整场景资产用例：初始/战斗后两变体。',refs=[],excerpt=p,changes=['全文阅读；区分聊天与文档缺失，不按聊天记录去注册工具/发布/执行旧请求。','选实际存在的场景模板与两变体说明，不把缺失docx及最终V4指南补写成原版。','战斗后图复用本条初始图参考，其余角色/脚本/视频/音频流程未执行。'],cases=[dict(name='initial',prompt=initial),dict(name='battle',prompt=battle,refs=[bd])]))
t='故事版提示词';p=body(t);meta='设计概念表提示词—《高空来信》：生成一张横向高端电影前期美术设定板，12个有序设计分区，非按时间推进的故事分镜，中文小标题清晰。真实电影概念设计质感，统一石墨黑、灰绿荒原、雾白天空与少量琥珀工作灯色板。1主视觉：巨大无纹黑色外星环体竖立荒原，低云穿环，营地渺小体现尺度；2环体正侧结构设定，边缘连续、无机械铆钉；3环体黑色微纹材质特写；4虚构成年物理学家林砚38岁，短黑发、灰绿色现场外套、深灰长裤、工靴，持无品牌测量仪，全身及面部小像；5虚构成年语言学家周岚36岁，肩长黑发、土色防风外套、黑裤、工靴，携纸质记录夹，全身及面部小像；6核心区近地环境，环体下部压迫视线，仪器只能见局部；7营地总平面设计，帐篷、测量三脚架、封锁线围绕环体；8军方封锁路障及观察点，装备写实但无品牌；9测量仪与带手绘符号的记录夹道具；10高空俯视场景设定，草地边界、蜿蜒河流、人类营地共同组成清晰完整的非文字几何信息，近地不可辨而高空可读；11地面与高空视距对照小图，同一环体和河道地理关系保持；12色板、雾光及情绪材质板，压迫、疑惑、发现，配柔和冷天光与暖营地灯，具体表现而不写剧情大纲。排版留白有层次，角色服装道具与地貌统一，所有图属于同一片场世界，不排连续剧情，不添加无关外星生物。'
a.append(dict(id='T162-design-sheet',title=t,type='元提示词→设计概念表生图',input='原文自带外星环体剧情，整体风格填写实电影概念设计。',refs=[],excerpt=p,changes=['清理HTML换行；“要写12格分镜。不!”为矛盾聊天残留。依正文主要要求不写STORYBOARD，采用12个非连续设计分区；单独记录解释。','人物姓名/年龄/服装与道具视觉细节由元任务执行补足，是本次输出，不是原文。'],meta_output=meta,cases=[dict(name='output',prompt=meta)]))
t='AI 视频分镜系统（无具体文档）';a.append(dict(id='T163-missing-agent-system',title=t,type='系统介绍/缺失核心文档',input='已读全文，核心CLAUDE.md/Subagents/7Skills仅会员解锁标题，实际未导出。',refs=[],excerpt=body(t),changes=[],cases=[]))
t='QWEN3分镜元提示词';raw=body(t);p=raw.split('提示词核心公式',1)[0];outs=[
'Next Scene: 暖木咖啡馆，中近景平视，承接参考中男子看向桌上Q版模型的视线。他保持绿色圆领毛衣和深色长裤，右手拿冰咖啡，轻轻把杯子移近桌面，含笑观察模型；模型仍站桌面持小咖啡，三盏暖吊灯、木吧台和后景咖啡机位置不变，肤色与柔暖光一致，固定镜头。',
'Next Scene: 同一暖木咖啡馆，稍低的侧前方中景，男子把大杯冰咖啡稳稳放在模型左侧，手指仍扶杯壁，目光落在两杯大小对比上，嘴角微笑；保持短深发、绿色毛衣和深裤，Q版模型脸发服装及小杯不变，木桌与三盏吊灯色温亮度延续，动作只推进放杯这一步。',
'Next Scene: 同一咖啡馆近景，男子放开已落桌的冰咖啡杯，左手轻点模型旁的桌面，低头会心微笑；Q版模型维持原地持小杯姿势，大小杯与模型相对位置沿用上一镜，短发绿色毛衣和深裤完全保留，木吧台及暖色吊灯自然虚化，固定镜头，不添加文字或额外人物。']
a.append(dict(id='T164-qwen-next3',title=t,type='元提示词→三张静态分镜',input='参考T145合成咖啡馆成人与Q版，剧情：看模型、放咖啡、会心一笑。',refs=[cafe],excerpt=p,changes=['仅执行第一段三条Next Scene元任务；后续独立九键JSON扩写模板未执行。','图像工具不支持真实运镜，仅验证三张静态状态；身份/道具参考共同输入原图，不冒充Qwen3或Qwen image。'],meta_output=outs,cases=[dict(name=f'scene{i+1}',prompt=o) for i,o in enumerate(outs)]))
t='未整理整套分镜提示词';raw=body(t);p=raw.split('<empty-block/>',1)[0];j={'characters':[{'id':'A','description':'虚构32岁成年东亚女性，椭圆脸，深棕杏眼，左脸小痣，短黑色侧分齐下巴波波头，白色短袖圆领T恤、深蓝直筒长裤、白色系带运动鞋，普通匀称体型，双手放松站立。','features':'短黑色侧分波波头、左脸小痣、白T、深蓝裤、白运动鞋，各角度保留；灰色无缝影棚，柔光由前上方照明。'}]};base=json.dumps(j,ensure_ascii=False)
a.append(dict(id='T165-character-analysis',title=t,type='元提示词→角色描述→多角度生图',input='合成成年女性参考；仅执行首段完整人物细节描述任务，再由该输出生成正面/左侧/背面三张对比。',refs=[w],excerpt=p,changes=['首段输出JSON字符小于3000；正文错误的多余逗号示例不照搬为无效JSON。','原Qwen2511/Lightning/Multiple-angles LoRA不可用；全为ChatGPT适配，不宣称真实LoRA控制。','其余20镜规划/分镜扩写/连续性分析模板未执行。'],meta_output=j,cases=[dict(name=n,prompt='依据同一参考和下列角色描述，生成单独一张写实全身角色设定照片，完整头脚、同一比例、灰影棚、不加文字。只改变观察角度为'+v+'，人物衣服发型体型保持。\n'+base) for n,v in [('front','正面平视'),('side','严格左侧90度平视'),('back','正后方平视')]]))
(B/'batch33-input.json').write_text(json.dumps(a,ensure_ascii=False,indent=2))
