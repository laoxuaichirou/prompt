from pathlib import Path
import json,shutil,sys
from prepare_batch import B
n=sys.argv[1]
for x in json.loads((B/f'batch{n}-output-map.json').read_text()):
    d=B/'results'/x['dir']
    if x.get('path'):shutil.copy2(x['path'],d/(x['name']+'.png'))
    if x.get('error'):(d/(x['name']+'-error.json')).write_text(json.dumps(x,ensure_ascii=False,indent=2))
for name,data in json.loads((B/f'batch{n}-inspections.json').read_text()).items():(B/'results'/name/'inspection.json').write_text(json.dumps(data,ensure_ascii=False,indent=2))
