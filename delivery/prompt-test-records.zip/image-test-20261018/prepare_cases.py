from pathlib import Path
import json,sys
from prepare_batch import prepare,B
items=json.loads(Path(sys.argv[1]).read_text()); tasks=[]
for item in items:
    prepare([item])
    d=B/'results'/item['id'];p=d/'test.json';data=json.loads(p.read_text())
    data['final_prompt']=[c['prompt'] for c in item['cases']]
    data['cases']=item['cases']
    data['meta_execution']=('本会话ChatGPT读取元提示词后执行，非单独模型API；输出已保存，不表示原指定LLM实测' if '元' in item.get('type','') else '直接生图或图像编辑；不另行执行提示词生成元任务')
    p.write_text(json.dumps(data,ensure_ascii=False,indent=2))
    for c in item['cases']:tasks.append({'id':data['test_id']+'-'+c['name'],'dir':item['id'],'name':c['name'],'prompt':c['prompt'],'refs':c.get('refs',item.get('refs',[]))})
(B/('tasks-'+Path(sys.argv[1]).stem+'.json')).write_text(json.dumps(tasks,ensure_ascii=False,indent=2))
print(json.dumps(tasks,ensure_ascii=False))
