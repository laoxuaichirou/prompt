from pathlib import Path
import json,re
from prepare_batch import B
inv=json.loads((B/'inventory.json').read_text());w=str(B/'materials/adult-woman-synthetic.png');dog=str(B/'materials/cartoon-dog-box-synthetic.png');d=B/'results/T166-dog-story'
def body(t):return (B/next(r['local_path'] for r in inv if Path(r['original_filename']).name.endswith('] '+t+'.md'))).read_text().split('## 正文',1)[1]
a=[]
t='AI脚本分镜';raw=body(t);p=re.findall(r'```[^\n]*\n(.*?)```',raw,re.S)[0];outs=[
'Next Scene: 花园石径，低位中景，三色短腿柯基从原来的敞口纸箱跃出，前爪伸向箱前石板，尾巴扬起，眼睛好奇；白脸线、棕眉黑背与白爪不变，纸箱留在身后，白篱笆和红黄花沿石径延续，左上方暖晨光与原图一致，柔和3D卡通材质，横向16比9，无文字。',
'Next Scene: 承接上一张落地动作，花园石径中景稍俯拍，同一三色柯基四爪落在纸箱前，转头看向右侧草坪；一只小绿蛙刚从草中跳到石径边缘，狗竖耳惊讶但友好，后方敞口纸箱、白篱笆和红黄花位置延续，左上暖晨光，3D卡通质感，横向16比9。',
'Next Scene: 同一花园，贴近地面的侧向近景，三色柯基朝小绿蛙靠近一步、低下头好奇闻看，绿蛙静坐石径边，两者保持友好距离；狗的白脸线棕眉黑背白爪与前镜相同，敞口纸箱仍在后方虚化，白篱笆红黄花和暖晨光连续，3D卡通横向16比9，不添加文字。']
refs=[[dog],[str(d/'scene1.png'),dog],[str(d/'scene2.png'),dog]]
a.append(dict(id='T166-dog-story',title=t,type='元提示词→三张连续静态分镜',input='N=3，自定义完整小故事：狗出纸箱、发现青蛙、靠近观察。原文9镜追蛙上街是可替换举例，本轮不执行该例。',refs=[dog],excerpt=p,changes=['按原文允许自定数量/剧情填N3；不是将原9镜例少做6镜后宣称通过。','先生成并打开普通3D小狗花园合成参考，再逐镜参考上一张及初始图，记录所有实际参考。'],meta_output=outs,cases=[dict(name=f'scene{i+1}',prompt=o,refs=refs[i]) for i,o in enumerate(outs)]))
for id,t,reason in [('T167-video-director','AI视频导演','纯8秒动态视频分镜脚本，未要求静态生图，本轮不适用。'),('T168-video-reverse','【AI影视】','视频链接逐秒反推并生成新视频，本轮不适用，未提供原视频。')]:a.append(dict(id=id,title=t,type='纯视频任务',input=reason,refs=[],excerpt=body(t),changes=[],cases=[]))
t='2509+WAN2.2，LLM';p=body(t);outs=[
'Next Scene: 2026年，东京附近一间虚构花店门前，中景平视。图一中的32岁东亚成年女性，短黑发左脸小痣、白T深蓝裤白鞋不变，站木门左侧，双手拿起一块小木牌，牌面清楚写着“春”。门旁红黄花盆和绿色藤叶、柔和阴天光，写实电影感，无品牌。',
'Next Scene: 承接上一镜，2026年东京附近同一虚构花店，略侧中景。图一中的同一位32岁女性保持短黑发、白T深蓝裤白鞋，双手将写有“春”的木牌挂到木门中央的小挂钩上，目光确认位置；门边红黄花盆与藤叶布局不变，柔阴天光与自然肤色统一。']
a.append(dict(id='T169-wan-text-shots',title=t,type='元提示词→两张静态分镜',input='图一=成年女性合成参考；2026年东京附近虚构花店：拿起写“春”的木牌，再挂门上。',refs=[w],excerpt=p,changes=['执行为两条Next Scene；保留图一引用、年代地点和引号文字“春”，不声称WAN原模型实测。','两图共同复用同一人物参考，花店为本次虚构场景，非实地照片。'],meta_output=outs,cases=[dict(name=f'scene{i+1}',prompt=o) for i,o in enumerate(outs)]))
t='AI漫剧提示词';raw=body(t);p=raw.split('华山剑仙（男）',1)[1].split('青城刀客',1)[0].strip();a.append(dict(id='T170-swordsman-asset',title=t,type='完整角色生图示例（混合元提示词文档）',input='华山剑仙，虚构28岁成年人；只测原文已给出的第一条完整角色资产示例。',refs=[],excerpt='华山剑仙（男）\n'+p,changes=['选择已存在完整角色资产示例，不将示例省略号补成原版；上文一分钟4x15秒全流程元任务和其余角色未执行。','填充成年28岁，原8K/16:9保留供检验。'],cases=[dict(name='output',prompt='虚构28岁成年男性华山剑仙，独立全身角色资产图，无文字。\n'+p)]))
(B/'batch34-input.json').write_text(json.dumps(a,ensure_ascii=False,indent=2))
