from pathlib import Path
import json,re
from prepare_batch import B
inv=json.loads((B/'inventory.json').read_text());w=str(B/'materials/adult-woman-synthetic.png');m=str(B/'materials/adult-man-synthetic.png')
def sel(t):
 body=(B/next(r['local_path'] for r in inv if Path(r['original_filename']).name.endswith('] '+t+'.md'))).read_text().split('## 正文',1)[1];bs=re.findall(r'```[^\n]*\n(.*?)```',body,re.S)
 return bs[0] if bs else body.split('**提示词\xa0(Original)复制**',1)[1].split('---',1)[0].strip()
a=[]
for id,t,refs,prefix in [('T136-winter-forest','冬季森林中年轻女子的3x3网格拼贴画',[w],'The subject is a fictional 32-year-old adult woman, use the reference face but change hair and clothing as instructed. '),('T137-winter-forest2','冬季森林中年轻女子的3x3网格拼贴画（同题2）',[w],'The subject is a fictional 32-year-old adult woman, use the reference face but change hair and clothing as instructed. '),('T138-own-caricature','创建您自己的3D漫画',[w],'The subject is the fictional 32-year-old adult woman from the synthetic reference. Choose a bright teal background. '),('T139-ink-profile','墨影狂魂侧写',[m],'Use the face of the fictional 43-year-old adult man from the synthetic reference. '),('T140-fashion-scrapbook','复古拼贴时尚档案',[w],'Use the fictional 32-year-old adult woman in the reference for face identity. ')]:
 p=sel(t);orig=p;ch=['填充虚构成年人；原文与最终输入分别保存。']
 if id.startswith(('T136','T137')):ch+=['两份同题独立文件使用完全相同提示词与同一参考，各自新调用，允许直接比较；不是跨模型测试。']
 if id.startswith('T138'):ch+=['背景色变量填青绿色。']
 if id.startswith('T140'):
  values={'Theme/Aesthetic keywords':'retro 1970s travel fashion','Character Description':'a fictional 32-year-old adult East Asian woman with a short side-parted black bob and small left-cheek mole','Pose & Action':'Standing relaxed with one hand on her hip','Detailed Outfit':'rust-orange corduroy jacket, cream crew-neck shirt, high-waisted dark blue jeans and brown leather ankle boots','Accessories':'a plain tan crossbody satchel','Layout Metaphor: DIY zine / field dossier / moodboard':'DIY travel zine','Thematic':'travel-fashion','Face/Makeup Detail':'her face with natural makeup','Fabric/Texture/Weapon Detail':'the rust-orange corduroy jacket weave','Footwear/Accessory Detail':'brown leather ankle boots','Style':'vintage travel','Clip Type: Silver clips / Gold clips / Rusted clips':'silver clips','Paper Stack Thickness':'thick stack','Tape Type: Washi / Duct / Masking':'washi','Doodle Type: arrows / stars / graffiti':'arrows and stars','Ink Type':'dark blue ink','Short Text 1':'ON THE ROAD','Short Text 2':'AUTUMN NOTES','Stickers/Stamps':'fictional postage stamp stickers','Paper Type: white sheets / cardstock / maps / folders':'old maps and cream cardstock','Surface Material & Color':'dark walnut desk','Lighting Style':'soft warm window light','Atmosphere':'nostalgic tactile editorial'}
  for k,v in values.items():p=p.replace('['+k+']',v)
  ch+=['全部变量逐项填入复古旅行测试用例：'+json.dumps(values,ensure_ascii=False),'保留括号权重作为原文文本，本工具未提供同名权重参数；子页未导出，未补写。']
 a.append(dict(id=id,title=t,type='直接生图/变量模板',input=prefix,refs=refs,excerpt=orig,changes=ch,cases=[dict(name='output',prompt=prefix+p)]))
(B/'batch28-input.json').write_text(json.dumps(a,ensure_ascii=False,indent=2))
