from pathlib import Path
import json,re
from prepare_batch import B
inv=json.loads((B/'inventory.json').read_text())
def body(t):return (B/next(r['local_path'] for r in inv if Path(r['original_filename']).name.endswith('] '+t+'.md'))).read_text().split('## 正文',1)[1]
def block(t):return re.findall(r'```[^\n]*\n(.*?)```',body(t),re.S)[0]
w=str(B/'materials/adult-woman-synthetic.png');m=str(B/'materials/adult-man-synthetic.png');dog=str(B/'materials/woman-dog-synthetic.png')
p1=block('电影级手办创作瞬间').split("'prompt': '",1)[1].split("'\n",1)[0]
p2=block('超现实亲子时尚大片')
p3=re.sub(r'\\([{}\[\]])',r'\1',body('雪景下的精灵').split('**提示词复制**',1)[1]).strip()
p4=body('3X3女子肖像照拼贴画').split('**提示词\xa0(Original)复制**',1)[1].split('---',1)[0].replace('<br>','\n').strip()
items=[]
for ident,t,p,refs,prefix,changes in [
('T121-workshop-figure','电影级手办创作瞬间',p1,[m],'The uploaded reference is a wholly fictional 43-year-old adult man; use his face, change his outfit according to the prompt. ',['抽取第一段完整英文prompt，移除损坏的嵌套JSON/伪工具调用包装；未执行第二个近似版本。','使用虚构43岁男参考，服装按原文绿色T恤黑工装裤填充。']),
('T122-family-fashion','超现实亲子时尚大片',p2,[],'Test subjects are wholly fictional adults: father aged 50, mother aged 48, and their adult daughter aged 22. Choose denim for the mother jacket. ',['填充虚构父50/母48/成年女儿22岁，母亲夹克选择原文denim分支。']),
('T123-winter-panels','雪景下的精灵',p3,[w],'Test input: use the face of the fictional 32-year-old adult woman in the synthetic reference. Choose coffee and the song title Last Christmas from the alternatives. Interpret the following readable instructions; its malformed JSON is not an API call. ',['仅清除导出的大括号/方括号反斜杠，保留中英文混合与缺逗号等原格式问题，不声称有效JSON。','填充成年合成人脸，饮品选咖啡、歌名选Last Christmas；不因标题添加精灵。']),
('T124-woman-dog-feed','3X3女子肖像照拼贴画',p4,[dog],'Use the attached synthetic reference of a fictional adult woman and dog. ',['原示例图未导出，按用户授权生成普通女性与狗合成参考；不是原库人物或狗。','移除HTML换行；不重写中间原图必须相同的要求。'])]:
 items.append(dict(id=ident,title=t,type='直接生图/参考图编辑',input=prefix,refs=refs,excerpt=p,changes=changes,cases=[dict(name='output',prompt=prefix+p)]))
items.append(dict(id='T125-empty-parent',title='Nano banana',type='目录/空正文',input='读取导出正文，未提供提示词。',refs=[],excerpt='',changes=[],cases=[]))
(B/'batch25-input.json').write_text(json.dumps(items,ensure_ascii=False,indent=2))
