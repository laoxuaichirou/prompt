import json
from pathlib import Path
b=Path(__file__).resolve().parent
D={}
def add(id,n,checks,c,status='存在问题'):D[id]=dict(status=status,generated=n,opened=n,checks=[dict(requirement=a,result=r,evidence=e) for a,r,e in checks],conclusion=c)
add('T121-workshop-figure',1,[('涂装自己手办/工坊','基本符合','本人直视镜头持细笔，绿色T恤/黑裤手办、透明底座、颜料与工具清楚。'),('完全同款/半身高','存在问题','真人未戴要求的墨镜，真人手表不可见；人物下身被裁，无法验收手办为站立身高一半。')],'核心工坊构图实现，穿戴一致与尺寸比例未完整满足。')
add('T122-family-fashion',1,[('三人/衣饰拆解','基本符合','成年父母女儿居中，三组列出的帽、表、衣、裤、鞋、包等均可辨，衣物悬浮且有材质标签。'),('引线/8K/材质','存在问题','多条虚线仅构成外圈，未逐件明确连接正确人物；非8K，棉含量、14K与皮革等为虚构文字不可当实物事实。')],'家庭时尚拆解成图，逐件引线及8K未满足。')
add('T123-winter-panels',1,[('三面板/服饰/道具','基本符合','左橱窗反射，右上雪地俯拍，右下咖啡自拍；毛皮短外套、黑裤、靴子、银手机、有线耳机、中央Last Christmas播放器出现。'),('严格零偏差与细节','存在问题','人脸表情/角度与参考改变，无法实现100%不变；右上双手藏在身后，未清楚表现双手插外套口袋。具体手机/靴子型号及真实镜头参数未验证。')],'主要冬日三场景实现，零偏差与插兜姿势未严格满足。')
add('T124-woman-dog-feed',1,[('九图不同场景/服饰','基本符合','九格含花园、山景、居家、咖啡、海边、街头及影棚，短发女性与三色狗有总体一致性。'),('每图含狗/中间同原图','存在问题','上中美容特写没有狗；中间参考被重新绘制，狗大小与位置、人物比例改变，非相同原照片。')],'九宫格已生成，缺狗一格且中间参考图未精确保留。')
add('T125-empty-parent',0,[('正文','缺失','仅目录标题，正文为空；子条目单独测试结果不能替代本父页实际提示词。')],'缺少提示词，无图，不能判生图实测通过。','阻塞')
(b/'batch25-inspections.json').write_text(json.dumps(D,ensure_ascii=False,indent=2))
p=b/'results/T125-empty-parent/test.json';d=json.loads(p.read_text());d['tool']='无（缺失未调用）';p.write_text(json.dumps(d,ensure_ascii=False,indent=2))
