from pathlib import Path
import json,re
from prepare_batch import B
inv=json.loads((B/'inventory.json').read_text());w=str(B/'materials/adult-woman-synthetic.png');m=str(B/'materials/adult-man-synthetic.png');dog=str(B/'materials/woman-dog-synthetic.png')
spec=[('T126-person-dog-duplicate','【人像】3X3女子肖像照拼贴画',[dog],'Use this synthetic reference of a fictional 32-year-old adult woman and dog. ',['与T124近同文，但本文件单独新调用；复用相同合成参考以便对比。']),('T127-saree-grid','【人像】3x3网格构图进行拍摄照片',[w],'Use the face of the fictional 32-year-old adult woman in the synthetic reference. ',['原构图参考未导出，仅按正文列出的九个镜头执行；人脸使用合成参考。']),('T128-car-three','【人像】人和汽车的三视图',[m],'The subject is the fictional 43-year-old adult man in the synthetic reference. ',['YOUR NAME变量填ALEX CHEN；车由本工具合成，非实车品牌核验。']),('T129-gallery-chair','【人像】女子赤脚盘腿坐在简朴的木椅上',[w],'Use the facial identity of the fictional 32-year-old adult woman in the reference, with long hair and clothing as instructed. Choose sunglasses. ',['填入成年合成人脸；按原文改长发与服装，眼镜二选一选太阳镜；保留向左看但画在右侧的原文矛盾。','保留原文签名字符串，仅图案文字不是创作者身份认证。']),('T130-fingerheart-film','【人像】镜前比心的甜妹胶片肖像',[],'The subject is a wholly fictional 25-year-old adult woman, not a real idol. ',['填充虚构25岁成年人，房间风格与原文保留，不引用真实偶像。'])]
a=[]
for id,t,refs,prefix,ch in spec:
 body=(B/next(r['local_path'] for r in inv if Path(r['original_filename']).name.endswith('] '+t+'.md'))).read_text().split('## 正文',1)[1];p=re.findall(r'```[^\n]*\n(.*?)```',body,re.S)[0];orig=p
 if id.startswith('T128'):p=p.replace('YOUR NAME','ALEX CHEN')
 a.append(dict(id=id,title=t,type='直接生图/参考编辑',input=prefix,refs=refs,excerpt=orig,changes=ch,cases=[dict(name='output',prompt=prefix+p)]))
(B/'batch26-input.json').write_text(json.dumps(a,ensure_ascii=False,indent=2))
