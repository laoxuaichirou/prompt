from pathlib import Path
import json,re
from prepare_batch import B
inv=json.loads((B/'inventory.json').read_text());w=str(B/'materials/adult-woman-synthetic.png');cafe=str(B/'results/T164-qwen-next3/scene3.png')
def body(t):return (B/next(r['local_path'] for r in inv if Path(r['original_filename']).name.endswith('] '+t+'.md'))).read_text().split('## 正文',1)[1]
a=[]
t='【视频分镜】（测试过，还不错，不过只有单帧分镜）分镜连贯生成场景丨反推的聊天设置（喂给LLM的）';raw=body(t);p=raw.split('反推的聊天设置（喂给LLM的）：',1)[1].split('优化版：',1)[0];outs=[
'Next Scene: 暖色木质咖啡馆，平视中近景，固定镜头缓慢推进的单帧状态。承接参考中男子点桌微笑的姿势，他收回左手，右手握住桌上大杯冰咖啡，将吸管移到唇边轻抿一口，目光仍停在右侧桌上的Q版模型。保持男子短深色卷发、五官、绿色圆领毛衣、深色长裤不变，Q版模型同款绿毛衣与小杯、黑色鞋子不变。桌子后方三盏暖吊灯、木吧台、咖啡机和玻璃展柜位置连续，暖光从上方包围，肤色、木纹与奶油散景和上一张一致，无新增人物与文字。',
'Next Scene: 延续上一张咖啡馆饮咖啡瞬间，男子将吸管离开嘴唇，右手仍扶住同一杯冰咖啡、杯底贴近原来桌上位置，抬眼向镜头露出满足的轻笑，左手放松落在桌沿。平视略侧中近景，轻微侧移感的静态构图，保持人物短深卷发、绿色毛衣深裤、同一面部和体型。Q版模型位于画面右侧，仍持小杯站在桌上，发型与衣服保持。三盏暖吊灯、木质墙面、咖啡机和展柜延续，软暖光、自然肤质、浅景深和真实木纹一致，叙事只推进放低杯子与抬眼微笑，不变换场所和时间。']
a.append(dict(id='T171-continuity-meta',title=t,type='元提示词→两张静态分镜',input='参考T164第三张合成咖啡馆图；N2：抿咖啡，再抬眼微笑。',refs=[cafe],excerpt=p,changes=['执行原版约200字Next Scene，优化版未执行；25分镜子页缺失不补写。','仅静态关键状态，不宣称真实推进/侧移视频，旧标题“测试过”不算本轮证据。'],meta_output=outs,cases=[dict(name=f'scene{i+1}',prompt=o) for i,o in enumerate(outs)]))
t='小说转影视流程（初版）';raw=body(t);p=raw.split('"Character design sheet',1)[1].split('"`',1)[0];p='Character design sheet'+p
q=p.replace('- Exact face replication from reference:','- Exact face replication from reference: fictional 32-year-old adult woman, oval face, dark almond eyes, small left-cheek mole, short black side-parted bob.').replace('- Costume:','- Costume: plain white crew-neck T-shirt, navy straight trousers, white lace-up sneakers.').replace('- Proportions:','- Proportions: natural adult proportions from reference.')
a.append(dict(id='T172-novel-asset7',title=t,type='参数化角色设计表直接生图',input='成年女性合成参考，原1.1全身3视图+上半身3视图+证件脸共7视图。',refs=[w],excerpt=p,changes=['选择原文1.1完整角色设计表，填入空缺的脸/衣服/比例字段，未删减七视图要求。','保留原8K/16:9及MJ后缀为文本，工具不提供原MJ参数。','其余动作/武器/场景/特效/小说拆分/视频流程与缺失子页未执行。'],cases=[dict(name='output',prompt=q)]))
t='镜头角度与提示词：6 - Camera Angles & Movements';raw=body(t);high='High angle shot of the fictional 32-year-old adult woman from the reference seen from above, looking up, cinematic lighting';low='Low angle shot of the fictional 32-year-old adult woman from the reference seen from below, looking down, cinematic lighting, powerful stance'
a.append(dict(id='T173-camera-angles',title=t,type='静态镜头模板对比',input='同一成人合成参考，分别高角度与低角度，保留白T深蓝裤灰棚。',refs=[w],excerpt='"High angle shot of \\ seen from above, looking up, cinematic lighting”\n"Low angle shot of \\ seen from below, looking down, cinematic lighting, powerful stance”',changes=['原文主体位置只留反斜杠，填同一虚构成年女性；同衣同景供机位对比。','其余静态镜头模板未执行，后半纯运镜目录不可用静态图验收。'],cases=[dict(name='high',prompt=high+' Keep her original outfit and gray studio background, one photograph.'),dict(name='low',prompt=low+' Keep her original outfit and gray studio background, one photograph.')]))
for id,t,reason in [('T174-lingjing-video','灵境出的分镜提示词','75秒动态视频分镜，包含声音/台词/连续运镜，本轮纯视频不适用。'),('T175-magic-video','远程法术打戏提示词生成专家','15秒远程法术动态视频元任务，硬规则要求动作节拍与终帧，不是静态生图任务。')]:a.append(dict(id=id,title=t,type='纯视频任务',input=reason,refs=[],excerpt=body(t),changes=[],cases=[]))
(B/'batch35-input.json').write_text(json.dumps(a,ensure_ascii=False,indent=2))
