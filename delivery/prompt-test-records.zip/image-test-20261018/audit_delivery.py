from pathlib import Path
import json,hashlib,re
from PIL import Image
from prepare_batch import B
inv=json.loads((B/'inventory.json').read_text());errors=[]
for row in inv:
    p=B/row['local_path']
    if hashlib.sha256(p.read_bytes()).hexdigest()!=row['sha256']:errors.append('Original changed: '+row['original_filename'])
tests=0;images=0;opened=0
for p in sorted((B/'results').glob('*/test.json')):
    d=json.loads(p.read_text());tests+=1
    if hashlib.sha256((p.parent/'original.md').read_bytes()).hexdigest()!=d['original_sha256']:errors.append('Source copy differs: '+str(p.parent))
    refs=d.get('reference_material',[]);refs=[refs] if isinstance(refs,str) else refs
    portable=[]
    for ref in refs:
        q=Path(ref) if ref.startswith('/') else B/ref
        if q.exists():
            try:portable.append(str(q.relative_to(B)))
            except ValueError:errors.append('Reference outside archive: '+ref)
        elif re.search(r'\.(png|jpg|jpeg|webp)$',ref,re.I):errors.append('Missing reference: '+ref)
        else:portable.append(ref)
    d['reference_material_portable']=portable
    for case in d.get('cases',[]):
        case_portable=[]
        for ref in case.get('refs',refs):
            q=Path(ref) if ref.startswith('/') else B/ref
            if not q.exists():errors.append('Missing case reference: '+ref);continue
            try:case_portable.append(str(q.relative_to(B)))
            except ValueError:errors.append('Case reference outside archive: '+ref)
        case['reference_material_portable']=case_portable
    p.write_text(json.dumps(d,ensure_ascii=False,indent=2))
    ins=json.loads((p.parent/'inspection.json').read_text());n=0
    for q in p.parent.glob('*.png'):
        with Image.open(q) as im:im.verify()
        n+=1
    if ins.get('opened',0)!=n:errors.append('Open/save count mismatch: '+d['test_id'])
    if ins['status']=='符合要求' and n==0:errors.append('No actual image: '+d['test_id'])
    images+=n;opened+=ins.get('opened',0)
out={'original_files_verified':len(inv),'test_records_verified':tests,'test_png_verified':images,'opened_count':opened,'synthetic_materials':len(list((B/'materials').glob('*.png'))),'errors':errors,'note':'文件审计不替代视觉验收；视觉验收结论见inspection.json。'}
(B/'交付审计.json').write_text(json.dumps(out,ensure_ascii=False,indent=2));print(json.dumps(out,ensure_ascii=False));assert not errors
