from pathlib import Path
import json,re
from prepare_batch import B
inv=json.loads((B/'inventory.json').read_text());w=str(B/'materials/adult-woman-synthetic.png')
def body(t):return (B/next(r['local_path'] for r in inv if Path(r['original_filename']).name.endswith('] '+t+'.md'))).read_text().split('## 正文',1)[1]
def sel(t):
 s=body(t);bs=re.findall(r'```[^\n]*\n(.*?)```',s,re.S)
 return bs[0] if bs else s.split('**提示词\xa0(Original)复制**',1)[1].split('---',1)[0].strip()
a=[]
for id,t,refs,prefix in [('T141-retro-sailor','复古时尚九宫格大片',[],'Portray the fictional adult character Steve Harrington as a 25-year-old man. '),('T143-life-collage','女性一生电影拼贴',[],'Create a wholly fictional symbolic life journey, not a real person or real ultrasound medical record. '),('T144-home-triptych','居家光影三联画',[w],'使用参考中的32岁虚构成年女性面部，服装按下文更换。'),('T145-cafe-mini','摆放着一个与本人相似的Q版模型',[],'The subject is a wholly fictional 28-year-old adult man with short dark hair, a plain forest-green crew-neck sweater, dark trousers and no logos. ')]:
 p=sel(t);a.append(dict(id=id,title=t,type='直接生图/参考编辑',input=prefix,refs=refs,excerpt=p,changes=['填充虚构人物/年龄；其他要求保留，非原示例人物实测。'],cases=[dict(name='output',prompt=prefix+p)]))
t='套图写真：顶级商业人像摄影导演';raw=body(t);p1="Next Scene: Please shift the fictional 32-year-old adult woman's weight onto her left leg, relax the right knee, and place one hand at her waist to create a subtle S-line through her fully clothed body. Turn her shoulders slightly away while she looks back toward the camera with a poised, gently flirtatious half-smile. Use an eye-level three-quarter full-length fashion portrait with natural proportions. Crucially, keep the original plain white T-shirt, navy trousers, white sneakers, neutral gray studio background and soft even lighting exactly consistent with the original image."
p2="Next Scene: Please turn the fictional 32-year-old adult woman into a side-on standing pose, bend one knee lightly forward, and lift both hands loosely behind her head so the elbows form a relaxed asymmetric line. She should angle her chin down and meet the lens with a soft, confident gaze and slightly parted lips. Use a modest high-angle medium-full fashion portrait with editorial restraint. Crucially, keep the original plain white T-shirt, navy trousers, white sneakers, neutral gray studio background and soft even lighting exactly consistent with the original image."
a.insert(1,dict(id='T142-portrait-director',title=t,type='元提示词→图像编辑',input='N=2；参考为32岁虚构成年女性白T深蓝裤灰影棚。依据实际参考构思动作，示例内衣卧室不属于本次输入。',refs=[w],excerpt=raw,changes=['执行元提示词输出两条英文Next Scene，分别实际编辑同一参考。','用例衣服/场景依据参考，不照搬示例内衣或床；保留女性魅力的普通时尚姿态。'],meta_output=[p1,p2],cases=[dict(name='pose1',prompt=p1),dict(name='pose2',prompt=p2)]))
(B/'batch29-input.json').write_text(json.dumps(a,ensure_ascii=False,indent=2))
