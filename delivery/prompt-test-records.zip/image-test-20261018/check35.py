import json
from pathlib import Path
b=Path(__file__).resolve().parent;D={}
def a(id,n,ch,c,s='存在问题'):D[id]=dict(status=s,generated=n,opened=n,checks=[dict(requirement=x,result=y,evidence=z) for x,y,z in ch],conclusion=c)
a('T171-continuity-meta',2,[('元任务/动作推进','符合要求','先输出两段Next Scene，再生成抿吸管咖啡、放低杯子看镜头微笑两张图，人物与模型服饰发型、桌面暖灯咖啡机保持。'),('边界','未执行/未验证','只验证两静态状态；真实推镜/侧移不验收，优化版及缺失25镜子页未执行；不证明长期连续稳定。')],'原版元任务的两个连续静态用例符合主要可见要求。','符合要求')
a('T172-novel-asset7',1,[('七视图/服饰/背景','符合要求','全身正侧背三图、上半身正面与左右3/4三图、证件式正脸一图均有，白T深蓝裤白鞋、灰棚一致。'),('8K/无阴影','存在问题','非8K；脚下有轻微地面投影，没有完全无背景地面阴影；不可见背面为合成推断。'),('其余工作流','未执行','仅1.1角色设计表，变体/武器/场景/小说拆解/视频与诊断任务未执行。')],'七视图最小资产用例已出图，8K与完全无阴影未满足，不代表全影视流程通过。')
a('T173-camera-angles',2,[('同人高低角对比','符合要求','高角度图明显从上方看、人物抬眼；低角度图地面仰拍、人物向下看，白T深蓝裤灰棚均保留。'),('范围','未执行','仅高/低静态模板，其余静态模板与全部真实运镜未执行；两图不证明稳定性。')],'所选高低机位两图对比符合主要视觉要求。','符合要求')
for id in ['T174-lingjing-video','T175-magic-video']:a(id,0,[('范围','本轮不适用','仅动态视频分镜/音效/连续运镜要求，未把静态单帧当视频验证。')],'纯视频任务，本轮不适用。','本轮不适用')
(b/'batch35-inspections.json').write_text(json.dumps(D,ensure_ascii=False,indent=2))
for name in ['T174-lingjing-video','T175-magic-video']:
 p=b/'results'/name/'test.json';d=json.loads(p.read_text());d['tool']='无（本轮不适用）';p.write_text(json.dumps(d,ensure_ascii=False,indent=2))
