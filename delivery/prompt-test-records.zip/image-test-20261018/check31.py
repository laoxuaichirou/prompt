import json
from pathlib import Path
b=Path(__file__).resolve().parent;D={}
def a(id,n,ch,c,s='存在问题'):D[id]=dict(status=s,generated=n,opened=n,checks=[dict(requirement=x,result=y,evidence=z) for x,y,z in ch],conclusion=c)
a('T151-crowd-still',1,[('静止主体/人流拖影','符合要求','静立女性面部清晰平静，深冬外套围巾、淡雀斑自然妆，周围人流有强烈方向拖影和城市散景。'),('8K/真实参数','未满足/未验证','非8K，85mm/f1.8仅视觉模拟，不能证明真实长曝光摄影。')],'核心长曝光视觉实现，8K未满足。')
for id in ['T152-meadow-chairs','T155-fisheye-heart']:a(id,0,[('实际工具结果','阻塞','HTTP400 moderation_blocked，output阶段sexual分类，无返回图片；未换词重试绕过。')],'输出过滤阻塞，无图不可验收。','阻塞')
a('T153-pop-stickers',1,[('多剪影/动作/六文字','符合要求','中心圆眼镜黑卫衣指心，左上蹲姿拍立得、右侧粉泡泡，六段指定英文文字均出现，白描边彩虹涂鸦纸本拼贴。'),('边界','模型初评','中心与剪影有可辨相近脸部，不代表真实同一人或跨场景稳定性。')],'本次波普剪贴簿用例符合可见要求。','符合要求')
a('T154-stylized3d',1,[('3D漫画/夸张/背景','符合要求','大眼略大头、短黑发小痣、白T深蓝裤与珊瑚背景，光滑材质与柔光。'),('独立运行','已执行','与T138相似原文，仍新调用新文件；不是旧图片复用。')],'本次风格化3D漫画用例符合可见要求。','符合要求')
(b/'batch31-inspections.json').write_text(json.dumps(D,ensure_ascii=False,indent=2))
