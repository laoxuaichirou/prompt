# WAN2.1-aniwan

| 属性 | 值 |
|---|---|
| 状态 | 已淘汰 |
| 评分 | 1 |
| 模型 | 通用 |
| 场景 | 视频生成 |
| Notion | [WAN2.1-aniwan](https://app.notion.com/p/WAN2-1-aniwan-2dd079fdbc3880ed8fb6e911841fb4ca) |

**备注**：两行备忘无内容；WAN2.1代际已过时

---

## 正文

动物开口说话
搭配infinitetalk
<empty-block/>
