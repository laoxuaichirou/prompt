# 【图片】Sys洗图丨搭配光影和色彩

| 属性 | 值 |
|---|---|
| 状态 | 已淘汰 |
| 评分 | 1 |
| 模型 | 通用 |
| 场景 | 图像编辑 |
| Notion | [【图片】Sys洗图丨搭配光影和色彩](https://app.notion.com/p/Sys-2dd079fdbc3880998ae3e9df13d2e044) |

**备注**：仅一行字，信息量近零，可被任何反推模板覆盖

---

## 正文

Provide a detailed description of this image, including composition, color scheme, character dynamics, etc
请详细描述这张图片，包括构图、色彩搭配、人物动态等方面。
<empty-block/>
