# Agent

| 属性 | 值 |
|---|---|
| 状态 | 仅参考 |
| 评分 | 1 |
| 模型 | 通用 |
| 场景 | Agent应用 |
| Notion | [Agent](https://app.notion.com/p/Agent-316079fdbc388074b1baf3d833ae3a48) |

**备注**：空壳目录页，价值在子页面「AI影视工业化流程」

---

## 正文

![](https://prod-files-secure.s3.us-west-2.amazonaws.com/bbcfb07b-b0c8-41fd-b8ac-003bd9bb920b/a6a58a6f-7c9e-413c-9671-085f3d61513b/image.png?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Credential=ASIAZI2LB4664XXS6XLK%2F20261017%2Fus-west-2%2Fs3%2Faws4_request&X-Amz-Date=20261017T091848Z&X-Amz-Expires=3600&X-Amz-Security-Token=IQoJb3JpZ2luX2VjEDAaCXVzLXdlc3QtMiJGMEQCIFTpV9HMy0umd2IE77MU6DdI3gC5XLDKKopXK7h53VwWAiBat97pNdaytUygL1CacbPWIWhPh0xLIQXqNhMtEHqn3CqIBAj5%2F%2F%2F%2F%2F%2F%2F%2F%2F%2F8BEAAaDDYzNzQyMzE4MzgwNSIM3fmXbgvK76fIIvULKtwDBUxixMK8Dh%2BNkDPXeCoJnxv0n2ycYGzu6sGtcIA8N8KTtG66hWOMDC8dFM35lGPVeSrq9ksOZIhg4OyYR%2FKWlMlJGH3luPMvHAau9f7%2BIv3FHG0jzSeydEKCetUEFLfq2MWszLqjQy6yYd5oWe3sYghI229P1eVuJ8r%2BsT5yLaMjSDZygdv2NO5Ll7aJHAUnkyVWvuAAJWab6y7hYUA4Z9gnDysOoKr6tH6A9p0XKSgF3FeyacXLgZIuAJ0u%2BYUgpginOArBMmr0vuXseJA0k5n6t3QPm2I4UpGCysTxudkp8gAJZ8eOlFc0GOCttOseTSjbdSaRRlgTWn%2FJMvhCGlOlJmqJtSOvHon%2BW6w2KkRrOqJ2WAKFMfv%2BD4cdrHWYO1QZnYa5vXtj7QvcrX%2FBp0oNCg44bBEqRMxBelbaM%2Fhh2oBGFJShOjdGXIi0iFVvIUfir0pZjbVpuGnJkXFyNwj04bJ90XGB%2BSkFiT9MTWm873uNTnOMuHmJRDxx%2FYFm1EAngaMtulyGhmkNg1WBqwEVFwzZDm8Pim9nRfzlVsa9zFKBT8tNycGWFSE3mX7ajOpF1l6Xsy26foJeZB99Rp2TqDR0lJzeQylxsNrpC2i%2FzhxjvPjeM2Jwjowwy9HM1gY6pgGcuAvx74RzDQQNR4wOJWxVc7hgvW7mzJjQSaNg2F46fQMyN%2FErdqqHbcn94ys0SC18qxzD442LUkWdvesxesedjttcCh5tL3nhvz3yAbMxf6wDxGxICLJ1i0UuGGn2Ij6mHQPfliXBvdLHF1yZOBBl60q1erF8fCcCSjcTuqU4ljztdzBhHhV380%2BEtPFcjuoCH%2B5CPHr2kZN76Y3%2F4FH5J050XNXY&X-Amz-Signature=17d1c1d9ae280e7fa37c92cc5f1ca7fffa90ccac1a980ec45583ab7710e763f2&X-Amz-SignedHeaders=host&x-amz-checksum-mode=ENABLED&x-id=GetObject#notion_record=block.316079fd-bc38-8013-9f02-f1568c15a1d6.bbcfb07b-b0c8-41fd-b8ac-003bd9bb920b)
<page url="https://app.notion.com/p/316079fdbc38801fa58adb8462495a2f">AI影视工业化流程</page>
<empty-block/>
