# GIF提示词（未测试）

| 属性 | 值 |
|---|---|
| 状态 | 待测试 |
| 评分 | 3 |
| 模型 | Nano Banana |
| 场景 | 视频生成 |
| Notion | [GIF提示词（未测试）](https://app.notion.com/p/GIF-303079fdbc3880239904fbb7943602e3) |

**备注**：动作迁移双图技巧值得提炼；当前是原始笔记态含聊天残留

---

## 正文

生成一张6x6GIF动漫风格拼图，包含了36个连续动作帧。
设计说明：<br>角色与表情：芙莉莲全程保持了您要求的夸张“阿黑颜”表情（双眼上翻、舌头伸出、面颊潮红、神情恍惚），并在不同动作幅度下有所变化。<br>动作序列：<br>第1-6格（起势）：芙莉莲身体微微后仰，表情开始失控，身体因某种冲击或快感而颤抖。<br>第7-12格（积蓄/受击前奏）：身体蜷缩或反弓，法杖挥舞，伴随小的魔法粒子溢出，表情愈发崩坏。<br>第13-18格（腹部受击瞬间）：这是您补充提到的“被打肚子”的核心帧。身体呈夸张的“\<”形弯折，腹部凹陷，背部弓起，表情痛苦与恍惚并存，口水飞溅。<br>第19-24格（击飞/硬直）：身体向后滑行或滞空，法杖脱手或勉强握住，高饱和度的金色光效（代表防御或魔法溃散）爆发。<br>第25-30格（落地/挣扎）：跌坐在地或膝盖着地，身体抽搐，试图用法杖支撑，表情依然维持阿黑颜状态。<br>第31-36格（余韵/恢复）：倒在地上或勉强站立，身上残留魔法烟雾，眼神涣散，作为循环的结尾。<br>画面风格：动漫小人，白色背景，方便您直接进行裁切和GIF合成。
<empty-block/>
<empty-block/>
修改后的 Prompt:
主题： Asuna (SAO) 大摆锤舞蹈动作序列拼图 (5x5 Grid)
画面整体结构：
一张完整的 5x5 网格图像，包含总共 25 个连续的动漫风格动作帧。背景为纯白色或透明，每帧之间有细微间隔，方便裁切用于制作 GIF 循环动画。整体风格为干净、明亮的日式 TV 动画截图或精细的动画原画风格。
角色设定：角色： 结城明日奈 (Asuna Yuuki) -来自于《刀剑神域》(Sword Art Online)。
服装： 经典的血盟骑士团 (Knights of the Blood Oath) 白底红边制服，配有轻甲和腰部的细剑（剑鞘随着舞蹈摆动）。
表情： 全程保持开朗、自信、富有韵律感的笑容，眼神跟随舞蹈动作看向不同方向，享受舞蹈。
动作序列说明 (25帧循环)：
这 25 帧表现了一个完整的“大摆锤舞蹈”循环，核心在于夸张且富有弹性的腰部扭动和臀部左右摇摆。第 1-5 帧（起始与向左摆动）： 角色从中心站立姿势开始，重心下沉，腰部开始向画面左侧发力扭动，带动臀部向左摆出，双臂自然弯曲配合身体平衡。
第 6-10 帧（左侧顶点）： 到达左侧摆动的最高点。臀部夸张地顶向左侧，上半身向右侧倾斜以保持平衡，腰部线条极度扭曲，长发和裙摆随着惯性向左飞扬。
第 11-15 帧（回中与过渡）： 身体像钟摆一样从左侧顶点迅速回荡过中心点，惯性带动身体准备向右侧摆动，腰部肌肉紧绷进行蓄力。
第 16-20 帧（右侧顶点）： 到达右侧摆动的最高点。臀部夸张地顶向右侧，上半身向左侧倾斜，展现出与第 6-10 帧相反的极致扭腰姿态。
第 21-25 帧（回归循环）： 身体从右侧顶点摆回中心，逐渐恢复到第 1 帧的起始姿势，准备开始下一个循环。
风格细节强调：强调腰部和臀部的动态线条和衣物褶皱变化，以体现“扭腰”的力度感。
头发和裙摆的飘动要符合物理惯性，增加舞蹈的动感。
色彩鲜艳，光影简洁，突出角色轮廓。
<empty-block/>
<empty-block/>
<empty-block/>
这个视频展示的是 **ComfyUI + Nano Banana Pro (Google Gemini Image) 的工作流**，用于**生成角色动作序列图（Sprite Sheet）**。
让我分析这个提示词的结构和用途：
---
## **提示词内容提取**
### **markdown**复制
`Analyze image 1. It contains a sequence of animation frames arranged in a grid. Return the result in JSON format.<br><br>Create a high-quality animate sprite sheet based on the image2, notice the weapon are in all frames, notice the character's size should be same in all frames.<br><br>CRITICAL INSTRUCTIONS:<br>1. The layout, grid structure, and poses MUST EXACTLY match the first image (the template sprite sheet), need pure white background<br>2. DO NOT STRETCH the sprites. Maintain the original internal aspect ratio of the characters.<br>3. If the output aspect ratio (${targetAspectRatio}) differs from the template, add padding (empty space) rather than stretching the content.<br>4. Apply the character's appearance (colors, clothing, features) to the poses in the template.<br><br>${prompt ? "Additional instructions: ${prompt}" : ""}`
---
## **这是做什么用的？**
### **表格**复制
<table header-row="true">
<tr>
<td>**项目**</td>
<td>**说明**</td>
</tr>
<tr>
<td>**目的**</td>
<td>把参考角色（image2）的动作/姿势，迁移到模板布局（image1）上</td>
</tr>
<tr>
<td>**输出**</td>
<td>角色动作序列图（Sprite Sheet），用于游戏或动画</td>
</tr>
<tr>
<td>**核心技术**</td>
<td>Google Gemini Image (gemini-3-pro-image-preview)</td>
</tr>
<tr>
<td>**输入**</td>
<td>image1=动作模板（网格布局）+ image2=角色参考图</td>
</tr>
<tr>
<td>**关键约束**</td>
<td>保持动作一致、不拉伸、纯白背景、武器保留</td>
</tr>
</table>
---
## **与你之前需求的对比**
### **表格**复制
<table header-row="true">
<tr>
<td>**你的需求**</td>
<td>**这个工作流**</td>
<td>**差异**</td>
</tr>
<tr>
<td>**人物三视图**（正/侧/背）</td>
<td>❌ 动作序列图（多帧动态）</td>
<td>用途不同</td>
</tr>
<tr>
<td>**Seedance视频生成**</td>
<td>❌ 静态Sprite Sheet</td>
<td>输出格式不同</td>
</tr>
<tr>
<td>**角色一致性控制**</td>
<td>✅ 通过模板强制约束姿势</td>
<td>原理相似</td>
</tr>
<tr>
<td>**AI生成提示词**</td>
<td>✅ 结构化指令+变量</td>
<td>可以借鉴</td>
</tr>
</table>
---
## **这个提示词的核心技巧（可借鉴）**
### **1. 双图输入结构**
### **plain**复制
`image1 = 模板（控制布局/姿势/网格）<br>image2 = 内容（控制角色外观/服装/武器）`
**借鉴到你的流程：**
- 可以用类似思路做**角色姿势迁移**
- 比如：把角色A的外貌 + 角色B的动作 = 新图
### **2. 严格约束指令（CRITICAL INSTRUCTIONS）**
### **markdown**复制
`1. MUST EXACTLY match（强制匹配）<br>2. DO NOT STRETCH（禁止拉伸）<br>3. add padding rather than stretching（保持比例）<br>4. Apply appearance to poses（外观迁移）`
**借鉴到你的流程：**
- 在人物三视图生成中，增加类似严格约束
- 确保正/侧/背视图比例一致、不拉伸
### **3. 变量插值**
### **markdown**复制
`${prompt ? "Additional instructions: ${prompt}" : ""}<br>${targetAspectRatio}`
**借鉴：**
- 你的元提示词也可以用变量，方便批量替换
---
## **为你优化的"动作迁移"元提示词**
基于这个思路，补充到你的资产工厂中：
### **plain**复制
`【角色动作迁移生成器】<br><br>输入：<br>- image1: 动作模板（可以是其他角色的动作序列/手绘草图/3D渲染图）<br>- image2: 你的角色参考图（三视图或单张）<br><br>输出：你的角色执行相同动作的序列图<br><br>【提示词】<br><br>"Analyze image 1. It contains [动作描述: 挥剑/闪避/轻功等] poses.<br>Create a high-quality character sheet based on image 2,<br>applying image 2's character appearance to image 1's poses.<br><br>CRITICAL INSTRUCTIONS:<br>1. Character face MUST EXACTLY match image 2 (facial features, hairstyle, expression)<br>2. Costume MUST EXACTLY match image 2 (colors, patterns, accessories)<br>3. Weapon style MUST match image 2's weapon type<br>4. DO NOT STRETCH the character. Maintain original body proportions.<br>5. If aspect ratio differs, add padding rather than stretching.<br>6. [动作] poses must be dynamic and readable.<br><br>Output: Grid layout matching image 1, pure white background,<br>showing [角色名] performing [动作名] sequence."<br><br>【Seedance适配】<br>把生成的动作序列图拆成单帧，作为视频生成的首帧参考`
---
## **关键结论**
### **表格**复制
<table header-row="true">
<tr>
<td>**问题**</td>
<td>**答案**</td>
</tr>
<tr>
<td>这是生成提示词吗？</td>
<td>✅ 是的，但这是给 **Gemini Image** 的，不是给Seedance的</td>
</tr>
<tr>
<td>能直接用吗？</td>
<td>❌ 需要改写，目标不同（Sprite Sheet vs 视频生成）</td>
</tr>
<tr>
<td>有价值吗？</td>
<td>✅ 非常有价值，展示了**双图参考+严格约束**的高级技巧</td>
</tr>
<tr>
<td>怎么融入你的流程？</td>
<td>作为**动作资产生成**环节，输出关键帧pose图，再喂给Seedance</td>
</tr>
</table>
---
需要我把这个 **"动作迁移"** 功能整合进之前的人物资产工厂吗？这样你的流程就是：
### **plain**复制
`角色三视图 → 动作迁移（生成pose序列）→ Seedance视频生成`
高峰时段算力不足，已切换至 K2.5 快速，升级会员畅用思考模型
<empty-block/>
