# 多总结 by：大呲花

| 属性 | 值 |
|---|---|
| 状态 | 仅参考 |
| 评分 | 3 |
| 模型 | 通用 |
| 场景 | 视频生成 |
| Notion | [多总结 by：大呲花](https://app.notion.com/p/by-303079fdbc38803ba81ad2a94a2d3827) |

**备注**：运镜短语库有用；剪映破解和飞书图链部分应删

---

## 正文

AI友好型镜头运动短语 ：<br>缓慢电影感推进<br>强烈冲击式推进<br>细腻后拉揭示镜头<br>急速骤拉变焦<br>瞬间聚焦主体变焦<br>左右快速甩镜<br>甩镜揭示画面<br>流畅跟拍镜头<br>手持跟拍漂移感<br>固定机位主体运动<br>动态运动与能量感：<br>高速横向扫摄<br>环绕主体圆周运镜<br>360度环绕镜头<br>角色弧线绕拍<br>轨道前移穿越场景<br>轨道后移退却镜头<br>前景至背景视差运动<br>前景元素掠过镜头<br>镜头滑行穿越环境<br>构图与视角短语：<br>低角度英雄式构图<br>高角度俯视构图<br>极致特写构图<br>电影感广角定场镜头<br>过肩视角构图<br>主观视角镜头<br>上帝视角俯拍<br>中心对称构图<br>焦点与景深(AI可用)：<br>浅景深效果<br>深焦电影感画面<br>前景到主体焦点转换<br>背景虚化主体清晰<br>前景模糊揭示效果<br>主体锐利环境柔和<br>风格化电影运动：<br>慢镜头推进<br>超现实电影运动<br>梦境般漂浮镜头<br>失重感镜头运动<br>轻微手持不稳定感<br>完美稳定电影机位<br>戏剧性透视变形<br>广角镜头电影化夸张<br>高效提示片段组合：<br>缓慢电影感推进，浅景深效果<br>甩镜揭示画面，动态视差运动<br>固定机位，混乱主体运动<br>360度环绕镜头，戏剧性低角度构图<br>手持跟拍漂移感，超现实电影质感
### 四、最近有几位水友在问，comfyui中的禁用多框和忽略多框，有的时候不喜欢一次显示很多行，如果只想保留显示一行怎么办？
- **首先右键单击禁用多框或忽略多框，然后在match title这一行输入想要保留的关键字，就会只保留一行组开关了，同一关键词也可以关联多个组开关**
- toggleRestriction是切换规则：max one 代表每次最多只有一个组被启用并可以关闭，可以自由切换，always one 代表一直有一个组开启，不全部关闭
- 还有一个喜欢加载多个lora的**权重lora加载器，十分简洁**
- 更多关于RG节点使用，请各位看[**RG节点教学视频**](https://www.bilibili.com/video/BV1Gb421J76u/?spm_id_from=333.1387.favlist.content.click&vd_source=324ab94653925ab7a5c2ca6f5f9924d0)
![](https://my.feishu.cn/space/api/box/stream/download/asynccode/?code=Y2FmZTFhZDc2N2ZmZTg5OWZkODY0MDE3MzNhZDA0MTBfZkJCMWJvdkpWOUlkZERobUptM3daNXd0ZXNRMWcyeEJfVG9rZW46TE4wUGJJS3I1b0taNVB4Y0RrSmM0VWlHbkFkXzE3NzA3NDg2Nzk6MTc3MDc1MjI3OV9WNA)
![](https://my.feishu.cn/space/api/box/stream/download/asynccode/?code=M2NkYWE5YTFmNDQ4OGY5MzgyY2Y4NzM5N2FjOGQ4ZjVfZEQ0cnM2NUNjUVRUcWppNzhCZHZQQXFzVHRCUHB3ZTdfVG9rZW46SUJMV2J2QUxkb3BCdnd4WmNiTWNuUWptbk9kXzE3NzA3NDg2Nzk6MTc3MDc1MjI3OV9WNA)
![](https://my.feishu.cn/space/api/box/stream/download/asynccode/?code=MWNhYjBmYjZhYjg1NjJiNGZhYjUwZmJlZTAxMzc1ZTFfN3J6MlZqVnBqTTJJclU4UjI0a3RPYXpTYU91c0t3MlNfVG9rZW46UjBnRWJaTGpWb3pCdEZ4VDRneGNJTlN2blRoXzE3NzA3NDg2Nzk6MTc3MDc1MjI3OV9WNA)
![](https://my.feishu.cn/space/api/box/stream/download/asynccode/?code=NjE0OWE4ZTZhOTZiM2ZlOGZlNmExZmRhOWIxMzdlZDZfYklqRHhzdEQ3Y08zRnFIZnlWRHRZcFV6RDJWSTZMYXJfVG9rZW46TnZNdWJvdmoxb3RhUkt4SWl6VmNFQXFHbm9oXzE3NzA3NDg2Nzk6MTc3MDc1MjI3OV9WNA)
![](https://my.feishu.cn/space/api/box/stream/download/asynccode/?code=NzZlNTgzZmYyNzI4M2JjZWFiODUwZmNkNTk1NGJlNGRfQ2hneFRMeGJYbHFkeHRzMUI1UDJ0UWdPNmdoUTBxVjVfVG9rZW46UUJacGJuS1lvb1F2S0N4SUd3Z2NIRlpQbnpmXzE3NzA3NDg2Nzk6MTc3MDc1MjI3OV9WNA)
<page url="https://app.notion.com/p/303079fdbc3880f699bac3fe4ac98e9f"></page>
### **三、剪映5.9破解版**
![](https://my.feishu.cn/space/api/box/stream/download/asynccode/?code=YjgyYzJlMWEyZjM5NWNhMjE4OWM5NDNiYmNkYTU4NDZfckNzbGJTZU1JdzZpblJxQ2RCMVd5QmlSOTBpZXBWRHZfVG9rZW46VzZiZ2JiSG1mb3BMRkV4NEhvTWNWTmNVbnBlXzE3NzA3NDkxMDM6MTc3MDc1MjcwM19WNA)
![](https://my.feishu.cn/space/api/box/stream/download/asynccode/?code=ZGMyNGFiNmVlNDdjOWE4YzQ4YjA1NGY5YTdkOTZhMTNfZHBYMXhQVkVxc3EzWnpmdDFsY05ZY28zcU1CTWx3Ym9fVG9rZW46U3VwT2J1SUJwb1U0Slh4bVhQUWNaVVUybjNmXzE3NzA3NDkxMDM6MTc3MDc1MjcwM19WNA)
![](https://my.feishu.cn/space/api/box/stream/download/asynccode/?code=NzUzN2FkZjQxNmE5MzUwZmQxYjI3ZThkYWU4ZTQ3NWZfdk1RSVhnYjJZVmRDdjFacjVNRGVuMGdEdGs0UVJtSHBfVG9rZW46V1hLeWJlOU9Ib3ZhYkp4Z1NnVmNvSG1UbmtiXzE3NzA3NDkxMDM6MTc3MDc1MjcwM19WNA)
![](https://my.feishu.cn/space/api/box/stream/download/asynccode/?code=YjRhNzcyNzAyMzUxZDM0ZDFhMmEwNjZiMWE3NDZmYzdfMW1DRU1Fbnl6N3BVYWtkOTRPd1dKeDJlSWEyajUwYnlfVG9rZW46V2VUNGJHZnp6b3ozcFB4RDdLUmNiZ2VTbklvXzE3NzA3NDkxMDM6MTc3MDc1MjcwM19WNA)
![](https://my.feishu.cn/space/api/box/stream/download/asynccode/?code=NzJjNjk3MDkwNWU2YTU2NTJhYThkYmRhMDc0MWQ2OWNfeHVLcmJhdnNHZzRrRVhIa0gwWUJuS1hBYjBlSUJsSHNfVG9rZW46RGthQ2JZN0xXb3RsSG94YzNuUWNlWml1bmJiXzE3NzA3NDkxMDM6MTc3MDc1MjcwM19WNA)
![](https://my.feishu.cn/space/api/box/stream/download/asynccode/?code=OWMwOTRiYjhlYTMwMjc4ZmM4MzVmMzdjZDk1ZDBlYWFfdm9yc0NLd21USFFxTVhkS2IzWHZCV1doSEV3aVUwOGpfVG9rZW46TzhpUGI1MXp4b2haWVN4RVdHa2MxQlN6bjFkXzE3NzA3NDkxMDM6MTc3MDc1MjcwM19WNA)
1. 剪映5.9（无需安装、解压即用，不会自动更新）.zip版下载，其他测试不通过
教学：https://zhuanlan.zhihu.com/p/1951439646178402444，你按它说的，把版本升级关了，一切OK
1. 夸克：https://pan.quark.cn/s/abfc11df910a#/list/share/2decb6c2d55441df89c97769dacbd15f
