# 专业影视级CG漫剧分镜-Supervideo2.0

| 属性 | 值 |
|---|---|
| 状态 | 已投产 |
| 评分 | 5 |
| 模型 | LTX |
| 场景 | 视频分镜 |
| Notion | [专业影视级CG漫剧分镜-Supervideo2.0](https://app.notion.com/p/CG-Supervideo2-0-34a079fdbc38809aa806d2dde5ef0c69) |

**备注**：剧本→Prompt Relay闭环方案；AI对话产出稿，用前跑一遍验证参数

---

## 正文

给你一套**可直接落地的"剧本→分镜→Prompt Relay"复刻方案**，包含填空模板、元提示词、转换规则，以及你这套白羽君案例的完整适配版本。
---
## **一、通用剧本想法模板（填空式）**
这是用户填的"故事梗概"，越结构化，LLM 输出越稳定：
### **Text**复制
`【项目类型】：[游戏CG / 影视广告 / 角色展示 / 剧情短片]<br>【时长规格】：[X]秒，[X]K[X]帧，[风格关键词]<br>【核心角色】：[姓名/身份]，[外貌特征]，[服装/武器]<br>【核心场景】：[环境描述，如：雾霭竹林 / 赛博都市 / 荒漠战场]<br>【色调氛围】：[主色调+辅色调，如：冷青+暖褐 / 霓虹紫+深夜蓝]<br>【视觉特效】：[粒子/光效/环境特效关键词]<br>【运镜风格】：[FPV第一人称 / 手持跟随 / 航拍 / 固定机位]<br>【情绪曲线】：[起-承-转-合，如：静谧→蓄势→爆发→余韵]<br>【必避问题】：[无穿模 / 无文字 / 无变形 / 人物一致]<br><br>剧情概述：<br>[用2-3句话描述从头到尾发生了什么，包含关键动作转折]`
---
## **二、元提示词（让 LLM 输出专业分镜剧本）**
把这段贴进 `Text Replace` 或 QwenVL 的 custom_prompt：
### **Text**复制
`You are a senior cinematic storyboard director specializing in game CG and AI video generation. Based on the user's story idea below, generate a professional shot-by-shot breakdown.<br><br>Requirements:<br>- Total duration: exactly as specified in the story idea<br>- Divide into 4 or 5 temporal segments with precise second marks (e.g., 0-3s, 3-6s...)<br>- Each segment MUST include these 4 fields in this exact order:<br>  1. 运镜方式 (Camera motion)<br>  2. 角色动作 (Character action)<br>  3. 视觉特效 (Visual effects)<br>  4. 情绪/氛围 (Mood/Atmosphere)<br>- Write in Chinese. Use vivid, concise language suitable for video diffusion models.<br>- Camera motion must be specific: FPV, tracking, orbit, zoom, dolly, crane-up, etc.<br>- Visual effects must describe color, particle, light interaction, and environmental reaction.<br>- Mood must use 2-4 Chinese adjectives.<br>- Do NOT add scene numbers or shot labels like "第一段". Use time marks only.<br>- Output format: plain text with time headers, each segment separated by a blank line.<br><br>Story Idea:<br><story_idea>`
---
## **三、分镜剧本 → Prompt Relay 的转换规则**
LLM 输出的分镜剧本不能直接塞进 Prompt Relay，需要**提取合并**。转换原则：
### **表格**
<table header-row="true">
<tr>
<td>**分镜剧本字段**</td>
<td>**是否保留**</td>
<td>**转换方式**</td>
</tr>
<tr>
<td>时间标记（0-3s）</td>
<td>❌ 删除</td>
<td>由 `segment_lengths` 接管</td>
</tr>
<tr>
<td>运镜方式</td>
<td>✅ 保留</td>
<td>核心，必须写进 Local</td>
</tr>
<tr>
<td>角色动作</td>
<td>✅ 保留</td>
<td>核心，必须写进 Local</td>
</tr>
<tr>
<td>视觉特效</td>
<td>✅ 保留</td>
<td>精简后写进 Local</td>
</tr>
<tr>
<td>情绪/氛围</td>
<td>⚠️ 精简</td>
<td>只留1-2个关键词，或并入 Global</td>
</tr>
<tr>
<td>色调/风格</td>
<td>⚠️ 上移</td>
<td>重复出现的色调写进 Global</td>
</tr>
</table>
**Global Prompt 写法**（锁定全片统一元素）：
### **Text**复制
`a handsome ancient Chinese man named Bai Yujun, long silver hair flowing, wearing pristine white flowing robes, holding an ornate folding fan, misty bamboo forest, cold cyan and warm brown color palette, cinematic game CG style, consistent character, no text, no deformed hands`
**Local Prompt 写法**（每段保留：运镜 + 动作 + 核心特效）：
### **Text**复制
`FPV camera skims low over wet moss and bamboo, smoothly rises locking onto Bai Yujun's back. His silver hair sways gently, right hand slowly lifts touching void. Cold cyan mist fills bamboo forest, floating fluorescent spores drift in air, light dapples through shadows. | FPV rapidly closes on his profile gliding silk-smooth toward the folding fan. He elegantly opens the fan, ink on surface instantly animates into warm brown flowing light particles bursting forth. | FPV orbits 360 degrees following the fan's arc, capturing ink splash micro-details. Bai Yujun sweeps fan horizontally, body spins lightly, robes flutter. Giant ink arc condenses into semi-transparent calligraphy shadow in air, warm brown particles explode with the move. | FPV rapidly pulls back from his shoulder rushing toward clouds, bird's-eye view of entire forest. Bai Yujun stands center with closed fan, aura expanding outward. Below, ink strokes weave into massive golden calligraphy array covering hundred meters, lava-like warm light penetrates mist. | High angle slow pullback from above. Bai Yujun's figure gradually shrinks merging into the grand array center. Entire bamboo forest enveloped by flowing warm array, cold cyan mist and warm brown light deeply blend, chromatic aberration at frame edges, particles slowly dissipate.`
---
## **四、白羽君案例完整适配版**
### **1. 剧本想法（填进左侧 String）**
### **Text**复制
`【项目类型】：游戏CG技能动画<br>【时长规格】：15秒，4K60帧，好莱坞级东方美学<br>【核心角色】：白羽君，银发古风男子，白衣长袍，手持折扇<br>【核心场景】：雾霭竹林<br>【色调氛围】：冷青+暖褐，冷暖交织<br>【视觉特效】：荧光孢子、星尘、墨迹粒子、书法阵图、光学色散<br>【运镜风格】：FPV第一人称极度丝滑<br>【情绪曲线】：静谧神圣→灵动优雅→力量爆发→神圣庄严→静谧余韵<br>【必避问题】：无穿模，无文字，无变形<br><br>剧情概述：<br>银发白衣男子白羽君于雾霭竹林中展开折扇，墨迹化光、星尘流转。FPV镜头从贴地缓行到挥扇释能，冷青与暖褐交织的水墨粒子随招式爆发，最终俯瞰整片森林被浮现的书法阵图笼罩。`
### **2. 元提示词（贴进 Text Replace）**
用上面第二节的模板即可，`<story_idea>` 会被自动替换。
### **3. LLM 输出后的分镜剧本（预期格式）**
### **Text**复制
`0-3s<br>运镜方式：FPV镜头贴地低掠过湿润的青苔与翠竹，随后丝滑上移，由远及近锁定白羽君的背影。<br>角色动作：白羽君银发随风轻晃，右手缓缓抬起，指尖触碰虚空。<br>视觉特效：冷青色浓雾在竹林间弥漫，空气中漂浮着大量细碎的荧光孢子，光影在竹影间斑驳流转。<br>情绪/氛围：静谧神圣，空灵压迫感。<br><br>3-6s<br>运镜方式：FPV极速贴合角色侧脸，镜头如丝绸般滑向其手中折扇。<br>角色动作：白羽君优雅展扇，扇面如水墨画卷瞬间绽放，折扇边缘带起一圈气流。<br>视觉特效：折扇上的墨迹瞬间活化，化作暖褐色的流光粒子喷薄而出，与周遭冷青色调形成强烈的冷暖对比，星尘开始在扇面汇聚。<br>情绪/氛围：灵动优雅，蓄势待发。<br>...`
### **4. 转换后 Prompt Relay 参数**
**Global Prompt**：
### **Text**复制
`Bai Yujun, a handsome ancient Chinese man with long flowing silver hair, wearing pristine white robes, holding an ornate folding fan, misty bamboo forest background, cold cyan and warm brown cinematic palette, game CG quality, no text, no deformed hands, consistent character throughout`
**Local Prompts**（5段 → Prompt Relay 需要5个数字）：
### **Text**复制
`FPV camera skims low over wet moss and bamboo, smoothly rises locking onto Bai Yujun's back. His silver hair sways gently, right hand slowly lifts touching void. Cold cyan mist fills bamboo forest, floating fluorescent spores drift in air. | FPV rapidly closes on his profile gliding toward the folding fan. He elegantly opens the fan, ink animates into warm brown flowing light particles bursting forth, strong warm-cold contrast. | FPV orbits 360 degrees following the fan arc, capturing ink splash micro-details. Bai Yujun sweeps fan horizontally, body spins lightly, robes flutter. Giant ink arc condenses into semi-transparent calligraphy shadow, warm brown particles explode. | FPV rapidly pulls back from his shoulder rushing toward clouds, bird's-eye view of entire forest. Bai Yujun stands center with closed fan, aura expanding outward. Ink strokes weave into massive golden calligraphy array covering hundred meters, lava-like warm light penetrates mist. | High angle slow pullback from above. Bai Yujun's figure gradually shrinks merging into grand array center. Entire bamboo forest enveloped by flowing warm array, cold cyan mist and warm brown light blend, chromatic aberration at edges, particles slowly dissipate.`
**Segment Lengths**（15秒，LTX 25fps = 375帧，latent 约 47帧，按情绪比例分配）：
### **plain**复制
`10,8,12,10,7`
> 解释：爆发段（6-10s）最长，给足视觉震撼；起势和收尾稍短。
**Epsilon**：
### **plain**复制
`0.001`
> 这是动作+特效片，段落感需要清晰，但运镜是丝滑 FPV，所以用默认平衡值。
---
## **五、给你的教程建议**
在视频里可以把这个流程包装成**"AI 导演工作流三步法"**：
### **表格**
<table header-row="true">
<tr>
<td>**步骤**</td>
<td>**观众操作**</td>
<td>**节点/工具**</td>
</tr>
<tr>
<td>**Step 1：填剧本**</td>
<td>复制模板，填空</td>
<td>`PrimitiveStringMultiline`</td>
</tr>
<tr>
<td>**Step 2：AI 写分镜**</td>
<td>一键运行，LLM 自动出分镜</td>
<td>`QwenVL` + `Text Replace`</td>
</tr>
<tr>
<td>**Step 3：绑定时间轴**</td>
<td>复制分镜进 Prompt Relay，调 segment</td>
<td>`PromptRelayEncode`</td>
</tr>
</table>
**封面标题**：
> 【AI导演工作流】从一句话到专业分镜：剧本模板+Prompt Relay时间轴控制，复刻平台级CG动画！
需要我把这个**完整的元提示词 + 转换后的 Prompt Relay 参数**打包成一个可直接导入你工作流的文本文件，或者做一个**对照表格**方便你视频里展示吗？
