# Lora提示词

| 属性 | 值 |
|---|---|
| 状态 | 仅参考 |
| 评分 | 2 |
| 模型 | 通用 |
| 场景 | 模型工具 |
| Notion | [Lora提示词](https://app.notion.com/p/Lora-332079fdbc3880cd98dcf22f8019a8bc) |

**备注**：草稿页一行话+一个子页链接，信息密度低

---

## 正文

溶图：溶图,纠正产品透视角度和光影并使产品融入背景
<empty-block/>
<page url="https://app.notion.com/p/326079fdbc3880ffa073e1604b547e3e">klein tryon元提示词</page>
<empty-block/>
