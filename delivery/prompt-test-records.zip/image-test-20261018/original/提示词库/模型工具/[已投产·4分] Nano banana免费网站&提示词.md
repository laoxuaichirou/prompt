# Nano banana免费网站&提示词

| 属性 | 值 |
|---|---|
| 状态 | 已投产 |
| 评分 | 4 |
| 模型 | Nano Banana |
| 场景 | 模型工具 |
| Notion | [Nano banana免费网站&提示词](https://app.notion.com/p/Nano-banana-300079fdbc388028a8a0e2b5d61789e8) |

**备注**：实测充分（效果图+失败自嘲）；免费额度表需定期复核

---

## 正文

## 免费网站
<table>
<tr>
<td>工具/平台</td>
<td>地址</td>
<td>免费额度 / 限制</td>
</tr>
<tr>
<td>**Google Gemini 网页版 App**</td>
<td>(https://gemini.google.com/app)</td>
<td>每天 **2 次**</td>
</tr>
<tr>
<td>**LMArena**</td>
<td>(https://lmarena.ai/)</td>
<td>**1小时内约5次**</td>
</tr>
<tr>
<td>**flowith**</td>
<td>(https://flowith.io/)</td>
<td>未注明具体额度（免费可用），据说是**33张一个月**</td>
</tr>
<tr>
<td>**Lovart**国内直连</td>
<td>(https://www.lovart.ai/)</td>
<td>**每天约3张**</td>
</tr>
<tr>
<td>**幻舟AI**国内直连</td>
<td>(https://www.huanzhou.art/)</td>
<td>**100积分**（1张图≈4积分）→ 可生成约 **25张**</td>
</tr>
<tr>
<td>**海螺视频（MiniMax）**国内直连</td>
<td>(https://hailuoai.com/)</td>
<td>注册送 **500积分**（1图≈4积分） → 可生成 **120+ 张**</td>
</tr>
<tr>
<td>**Google 学生优惠**</td>
<td>(https://gemini.google/tw/students/)</td>
<td>学生可享 **1年内无限生成**</td>
</tr>
</table>
## 提示词
### 漫画
```plain text
Create a 7-panel cute chibi-style comic titled “需求评审研发走神时都在干啥？” with Nano Banana Pro 🍌

=== Global Style ===
- Art style: 简笔画风格，可爱
- Character consistency:
  - Name: 鳕小堡
  - Look: 我提供的人物简笔画图
- General tone: humorous, relatable, office-life chaos, light and cute.
- Screens and dashboards should be simplified, readable but not cluttered.
- Dialogue in simplified Chinese, inside clean comic speech bubbles.

=== Panel Guide ===

[Panel 1]
Title: “乖乖听需求（假象）”
Scene: Online requirement review meeting.
鳕小堡 sits upright with earphones, staring seriously at his MacBook.
Laptop details: macOS desktop, Feishu 99+ notifications, dock icons (GoLand, Arc, Terminal).
Product manager presenting PPT (blurred content).
Mood: looks serious but slightly clueless.

[Panel 2]
Title: “突然警铃大作”
鳕小堡’s eyes widen in shock.
Mac screen pops a red alert:
“Critical × 100”
“xx 接口错误率上升”
Red warning icon flashing.
Tone: cute but chaotic.

[Panel 3]
Title: “快速接警（慌）”
鳕小堡 switches to monitoring dashboard.
Chart shows a red line sharply rising.
A coworker message pops:
“堡哥！你是不是挂了？我们调不通了！”
鳕小堡 sweating nervously.

[Panel 4]
Title: “急查现场（更慌）”
Close-up monitoring dashboard:
- error rate spike
- CPU usage shooting to max
- error code “上游超时”
鳕小堡 leans forward, tiny trembling eyes.
Thought bubble:
“我靠……CPU怎么突然炸了？”

[Panel 5]
Title: “被产品点名（致命一击）”
Switch back to meeting.
Product manager asks:
“堡哥，我确认一下历史逻辑，是这样吗？”
鳕小堡 sits straight, awkward smile, sweating.
He replies:
“刚刚 miss 了……能再说一遍吗？”

[Panel 6]
Title: “找到真相（扩流事故）”
鳕小堡 investigates and sees QPS surge.
He finds upstream service owner, a chibi character with guilty smile.
Dialogue:
“我刚做实验扩流……可能忘记通知你了。”
鳕小堡 looks exhausted and speechless.

[Panel 7]
Title: “回到评审（收尾）”
鳕小堡 returns to the meeting window, tired expression.
Product still presenting PPT seriously.
鳕小堡 inner monologue bubble:
“需求我听得不多，但线上我救得真快。”
Final mood: relatable, cute, funny.

=== Output Format ===
A sequential 7-panel comic, consistent characters, pastel kawaii style, clear text bubbles, minimal flat UI design.
```
### Chiikawa 漫画
```plain text
请用nanobanana pro生成 四天的中国云南的旅游指南 ，每一天一张图，手账形式，整体风格用chikawa三小只，纯中文，信息可以足够详细一点，比例3: 4
```
![](https://my.feishu.cn/space/api/box/stream/download/asynccode/?code=NDQ1ZWQ4NjA2YjJkNGMyMmQ2NjVjYTNiZTk1ZTY5M2ZfaEoxbXdkMDhiMkFhcjY5VVp0bXhEc2dQcFE4TnN6MUhfVG9rZW46STBoMGJIUGFib1hUeWt4S2NuM2Njd01hbm1jXzE3NzA0Njk3ODc6MTc3MDQ3MzM4N19WNA)
### 元素拆解
（提示词来自https://www.xiaohongshu.com/explore/6926e745000000001f00b13a?xsec_token=ABqxNLX_NtiJEqk0CohhOpxHcT9KjVVnT65WZigT7Z2xY=&xsec_source=pc_search&source=unknown）
```plain text
视觉规范
1. 构图布局 :
• 中心位 : 放置角色的全身立绘或主要动态姿势，作为视觉锚点。
• 环绕位 : 在中心人物四周空白处，有序排列拆解后的元素。
• 视觉引导 : 使用手绘箭头或引导线，将周边的拆解物品与中心人物的对应部位或所属区域（如包包连接手部）连接起来。
2. 拆解内容 核心迭代区域:
服装分层  :
将角色的服装拆分为单品展示。如果是多层穿搭，需展示脱下外套后的内层状态。
新增：私密内着拆解 : 独立展示角色的内层衣物，重点突出设计感与材质。
表情集 :
在角落绘制 3-4 个不同的头部特写，展示不同的情绪。
材质特写 :
选取 1-2 个关键部位进行放大特写。
新增：物品质感特写: 增加对小物件材质的描绘
关联物品  :
此处不再局限于大型道具，需增加展示角色的“生活切片”。
随身包袋与内容物 : 绘制角色的日常通勤包或手拿包，并将其“打开”，展示散落在旁的物品。
美妆与护理 : 展示其常用的化妆品组合。
私密生活物件 : 具象化角色隐藏面的物品。根据角色性格可能包括：私密日记本、常用药物/补剂盒、电子烟、或者更私人的物件。
3. 风格与注释 :
画风: 保持高质量的 2D 插画风格或概念设计草图风格，线条干净利落。
背景: 使用米黄色、羊皮纸或浅灰色纹理背景，营造设计手稿的氛围。文字说明: 在每个拆解元素旁模拟手写注释，简要说明材质或品牌/型号暗示。
执行逻辑
当用户提供一张图片或描述时：
1. 分析主体的核心特征、穿着风格及潜在性格。
2. 提取可拆解的一级元素（外套、鞋子、大表情）
3. 脑补并设计二级深度元素（她内衣穿什么风格？她包里会装什么口红？）
4. 生成一张包含所有这些元素的组合图，确保透视准确，光影统一，注释清晰。
5. 使用中文
————————————
请生成一张漫画角色芙莉莲拿着法杖的符合上述视觉效果的解析图
```
生成图：
![](https://my.feishu.cn/space/api/box/stream/download/asynccode/?code=NTkwYzkyODI1MzY0MTE2ZmZjZjIxZDNmZDRmZjU3ZTFfT0JZU2JhUTNCY1VYRUxXb2NuRHZkQ2w4a2pXdkl1UlZfVG9rZW46UDFVNmJMWmZKb2MyU0h4NGJ4OGNsOEZUbmdEXzE3NzA0Njk3ODc6MTc3MDQ3MzM4N19WNA)
![](https://my.feishu.cn/space/api/box/stream/download/asynccode/?code=ZGRiNmMzN2I2MWViYTU3OTZiZTI3OTE0NTAxNGE5MGVfVGFxQU1CQzBtWGt1RExSU2U1YTFVQzN4eUt3cXFqYU9fVG9rZW46T3k5VGJjaXpZbzBhbzN4Z3BYS2NwaUxUbnloXzE3NzA0Njk3ODc6MTc3MDQ3MzM4N19WNA)
图片喂的南宫婉。。好像不太像hhh
![](https://my.feishu.cn/space/api/box/stream/download/asynccode/?code=MjY0MTAzMmJjNjlmMWQ3MDg1Y2I3MzE4OGUwYmMxZjFfMjJ3NkhuSEkxelFIZmE2WDRUWG1ZQk5YdlhyemticTVfVG9rZW46RGFXcGJVSjZvb3dtRlp4d0t5V2NTQVhJbmNnXzE3NzA0Njk3ODc6MTc3MDQ3MzM4N19WNA)
### 哆啦A梦漫画讲解知识
步骤：
1. 喂一本书 pdf 给 notebook lm/ chatgpt，提示词：
```plain text
让野比太和哆啦A梦为主人公，以漫画的形式，带领读者由浅入深地学习并了解这本书的主要观点
```
1. 让 chatgpt 写漫画页和格
```plain text
请基于以上讨论，分析并告知这个漫画学习读本要划分为多少页比较合适，每页的内容是什么？
```
1. 让 Nano Banana Pro 画漫画
```plain text
请基于以上讨论，使用 nano banana pro 生成学习漫画第一页的图像（页面分辨率统一为小红书尺寸，语言是中文）。
```
最终提示词：
```plain text
📘《哆啦 A 梦带你读懂 <思考，快与慢>》
8 页精细扩展版 · 完整分镜脚本
第 1 页：开场——为什么我总是“想得太慢”？
🎯目标

让读者进入剧情；呈现“思考＝痛苦”这一普遍现象。

格1：大雄面对数学题的绝望

画面：书桌上是一张数学卷子——17×24、分数加法等。
大雄撑着头，眼神空洞。
大雄（心声）：“为什么我的脑袋一动就像要冒烟？”

旁白（柔和）：几乎所有人都有这种感觉，这不是你笨，是你的大脑构造导致的。

格2：外部压力一起袭来

画面：

手机上飞书消息 99+

“考试倒计时 24 小时” 的日历

妈妈在门口喊：“大雄！你写完作业了吗？”

胖虎的威胁性影子投射在窗外

大雄：“救命……我真的快不行了……”

格3：哆啦 A 梦登场

哆啦 A 梦从抽屉里钻出来，手里拿着一本《思考，快与慢》。
表情认真但温柔。
哆啦 A 梦：“大雄，你的脑袋不是出问题……而是你不认识住在里面的两个家伙。”

第 2 页：系统 1 与系统 2——大脑里的两个室友
🎯目标

让读者在 1 页内立刻理解两个系统“谁是谁、怎么运作”。

格1：打开“脑内观察灯”

哆啦 A 梦拿出科技道具：脑内观察手电筒。
一道蓝光照进大雄的大脑内部。

画面切换到“脑内小世界”。

格2：系统1登场——小急匆匆

人物：一个小小的精灵，跑得飞快，留下一串速度线。
戴着一个闪电徽章。
表情灵敏、过度自信。

系统1：“快问我快问我！我马上告诉你答案！”

旁白：系统1 = 快速直觉 + 自动反应 + 情绪化判断。

格3：系统2登场——慢吞吞先生

人物：戴眼镜的沉稳书生，手里抱着一本厚书。
走路很慢，思考时额头会亮光。

系统2：“等一下……让我仔细想想……”

旁白：系统2 = 深思熟虑 + 努力 + 理性。

格4：大雄的困惑

大雄看着两个角色，满头问号。
大雄：“那为什么我平时感觉是‘不小心就做出错误判断’？”

哆啦 A 梦笑着回应：
“因为系统1非常快，但也特别爱犯错。”

第 3 页：系统1 的误区三连击
🎯目标

用三个最经典的偏差来展现系统1的不可靠性。

格1：代表性偏差（像 ≠ 概率大）

哆啦 A 梦展示一张害羞、戴眼镜的年轻人资料卡。
“他是农民还是图书管理员？”

系统1立刻跳出来：
“长这样当然是图书管理员！”

哆啦 A 梦用全息投影显示数据：
“可现实是农民数量比图书管理员多 20 倍。”

大雄震惊：“啊？原来我只是看着像就乱判断了！”

格2：可得性偏差（想得起来 ≠ 更常见）

大雄：“我觉得政客特别容易出事，新闻天天报！”

哆啦 A 梦打开电视墙，显示：

各种政客新闻头条

医生或普通人相关新闻数量稀少

哆啦 A 梦：“那只是因为他们更容易出现在新闻，而不是他们更常犯错。”

系统1在旁边点头：“因为我最先想到他们！”

格3：锚定效应（数字会控制你）

哆啦 A 梦：“你觉得我有 500 公斤吗？”

大雄吓一跳：“不至于……可能 200？”

旁白：虽然大雄知道“500”不对，但系统1 的第一反应已经决定了他的估算。

哆啦 A 梦拿出真实数据：
“我只有 129.3kg。”

第 4 页：系统2 为什么常常救不了你？
🎯目标

让读者理解：不是你不用系统2，而是它太累、太慢。

格1：系统2的疲劳

系统2瘫在沙发上，汗流浃背。
“大雄今天做了数学、被妈妈催、被胖虎追……我脑袋已经烧掉了。”

哆啦 A 梦旁白：
“系统2非常耗能，一旦你分心，它就会自动下线。”

格2：大雄的多任务爆炸

画面同一时间呈现：

大雄写作业

回飞书

胖虎喊他出去打棒球

妈妈让他倒垃圾

系统2慌张：“我没办法同时处理这些，我退出了！”

格3：系统1趁机接管

系统1兴奋跳上“控制台”：
“系统2 不干？太好了！现在我说啥就是啥！”

旁白：当系统2缺席时，人就进入【直觉自动模式】＝容易犯错的模式。

第 5 页：前景理论——为什么人类判断风险那么奇怪
🎯目标

用两个经典场景讲清“收益时保守、损失时冒险”。

格1：收益情境

哆啦 A 梦展示两张卡：
A：确定 +900
B：90% 概率 +1000，10% 0

大雄瞬间选择：“选 A！”

系统1：“确定更舒服！”

格2：损失情境

哆啦 A 梦再展示：
A：确定 -900
B：90% 概率 -1000，10% 0

大雄犹豫后：“那我选 B……也许会不亏。”

哆啦 A 梦：“这就是——损失时变得更愿意赌。”

格3：哆啦 A 梦总结框

带图表：收益区 → 曲线平缓；损失区 → 曲线陡峭。

哆啦 A 梦：
“人的情绪对损失非常敏感，‘怕亏’会让你变得不理性。”

第 6 页：损失厌恶 & 框架效应——情绪如何欺骗你
🎯目标

用 2 个关键人性弱点说明：我们不是“怕失败”，而是“太怕损失”。

格1：损失厌恶（痛感是 2 倍）

场景并排展示：

左侧：大雄捡到 100 元，微笑平淡。
右侧：大雄掉了 100 元，满地找、抓头发、崩溃。

哆啦 A 梦：“同样是 100 元，失去时痛苦是得到时的 2 倍。”

格2：框架效应（说法不同，感觉天差地别）

哆啦 A 梦：
“这杯牛奶——有 90% 的人喝了没事。”

大雄：“那还不错。”

换种说法：
“有 10% 的人喝了会拉肚子。”

大雄：“那我不要喝了！！”

旁白：两句话一样，但系统1 只听感觉。

第 7 页：两个自我——体验与记忆如何打架
🎯目标

浓缩说明为什么我们会做“听起来好，但未必真正幸福”的决定。

格1：体验自我（当下感受）

大雄看牙：
“疼死了！快停下！！”

体验自我在旁边捂脸：“我快崩溃了！”

格2：记忆自我（讲故事的那个你）

结束后大雄若无其事地走出牙医诊所：
“还好嘛，其实不太疼。”

旁边记忆自我穿着记者衣服：
“我会把这写成‘还可以的一天’。”

格3：哆啦 A 梦总结

哆啦 A 梦画出两个自我：

体验自我：活在当下
记忆自我：写你人生故事，做大多数决定

哆啦 A 梦：“记忆自我只关注两件事：最痛的瞬间 + 最后的感受。”
因此你做出的选择……常常不是为了当下舒服，而是为了“回头看起来不错”。

第 8 页：终页——哆啦 A 梦的 3 个黄金建议
🎯目标

让读者“看完马上能应用”。

格1：建议 1——重要决定必须慢一点

哆啦 A 梦：“重要的事 → 给系统2 时间。”
画面：大雄深呼吸，把手机丢一边，拿起纸笔。

格2：建议 2——写下来（强制启动系统2）

大雄把自己的直觉写成一句话，然后画个问号。
系统2从旁边钻出来：“你叫我？”

哆啦 A 梦：“写下来的瞬间，系统2 就会醒来。”

格3：建议 3——问自己：这是体验自我想要的？还是记忆自我？”

并排画两个大雄，一个想“舒服一点”，一个想“听起来更体面”。

哆啦 A 梦：“别被记忆自我骗了，它是个爱讲故事的导演。”

格4（收束）

大雄精神抖擞：“原来我不是笨，是我的脑袋太复杂！”
哆啦 A 梦微笑：“懂你的大脑，你就能做更聪明的决定。”

旁白：“你已经比大多数人更了解自己了。”

————————————————————
基于以上讨论请生成第一页漫画的内容
```
效果：
![](https://my.feishu.cn/space/api/box/stream/download/asynccode/?code=MDYzMGRlM2Y5ODZmOGFhMzBlMjU2NWU0YmMyMGZhNWVfSzYxMjlHVmpydFR5SUlXVlpzSmJrODRMeThJZTZCeTlfVG9rZW46VUQybWJmeUh6b2JtUVl4VGZpUWNQdm5rbkpiXzE3NzA0Njk3ODc6MTc3MDQ3MzM4N19WNA)
![](https://my.feishu.cn/space/api/box/stream/download/asynccode/?code=MDFmZjYwMDBjNzRmYWM4N2M3MmY5ZGI5NTZlMmYyN2FfVk5pSzFScDlmdWg1SnZxb01yT2g4eGxNNGdvaGJzTmdfVG9rZW46RW1UNGJTVXF4b25RM0l4ckpyMGNsMUhWblpkXzE3NzA0Njk3ODc6MTc3MDQ3MzM4N19WNA)
### 建筑图结构解析
提示词：帮我生成一张广州小蛮腰结构解析图
效果图：
![](https://my.feishu.cn/space/api/box/stream/download/asynccode/?code=ZGI3MTdhZWRhZGUzOTdiMTYwYzVkYjVjMzYxMmRlMTJfSkRNTUdaWUU0N3RlSngyOUxRWWVpeERZMGpaN0V6ZU9fVG9rZW46SExldmJmSk4zb1haNmF4OWd2emNqSDRTbjhjXzE3NzA0Njk3ODc6MTc3MDQ3MzM4N19WNA)
### 精灵图
提示词：
（灵感来自https://www.xiaohongshu.com/explore/6921abf7000000000d03d19a?xsec_token=AByM-q552BPiCOJYezLskdzdH4DYfj3KsO-GVUzvvxdsc=&xsec_source=pc_search&source=unknown）
```plain text
请为我的角色扮演游戏制作一个可爱的角色动作精灵图，它应该涵盖探索游戏中10个主要角色动作，并相应地标注精灵图的不同部分。
```
效果图：
![](https://my.feishu.cn/space/api/box/stream/download/asynccode/?code=ZjE3ZDlkZjUzZGYxMjExNmI5ZDRjZjdkOTA2ZTIyM2VfUHBhSnhwMnMwZjRZNENjSzdjejNuWmdXWnNPdm9tZjZfVG9rZW46Tno2TWJzMWtub3hud0d4SU5hZWNuWms2blFiXzE3NzA0Njk3ODc6MTc3MDQ3MzM4N19WNA)
### 古典诗词
提示词：
```plain text
请生成一张中国古诗意境图，描述风景的
```
效果图：
![](https://my.feishu.cn/space/api/box/stream/download/asynccode/?code=MGJkOTIzMmY0MDg5YjVmYWZiZjVhYzcyYzU0N2FkOWFfRVQ3S1hxNXR6TnNFRXVLMkM0YjFjQml3aHVJTzZzcG1fVG9rZW46TWtPTGJJVWF1b3BBOHZ4elhsbWNTTUcybm9mXzE3NzA0Njk3ODc6MTc3MDQ3MzM4N19WNA)
