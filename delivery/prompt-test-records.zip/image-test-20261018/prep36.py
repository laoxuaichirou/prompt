from pathlib import Path
import json,re
from prepare_batch import B
inv=json.loads((B/'inventory.json').read_text());w=str(B/'materials/adult-woman-synthetic.png');kit=str(B/'materials/football-kit-synthetic.png')
def body(t):return (B/next(r['local_path'] for r in inv if Path(r['original_filename']).name.endswith('] '+t+'.md'))).read_text().split('## 正文',1)[1]
a=[]
t='【示例】Sora2创建任务角色示例';p=body(t).replace('<empty-block/>','').strip();a.append(dict(id='T176-winter-role',title=t,type='角色视觉描述静态适配',input='按原19岁年龄填虚构成年人物，静态视觉测试，唱歌/镜头互动不验收。',refs=[],excerpt=p,changes=['原文指定Sora2，本轮ChatGPT静态适配；唱歌及动作时序未执行。','底部未指定英文信息填WINTER REVERIE / A MOMENT IN THE SNOW；保留GENTLE标题原字。'],cases=[dict(name='output',prompt='生成一张静态人物视觉参考图，主体为虚构19岁成年女性，服饰表情和排版按下文；本图不验证唱歌与动态。下方小字填写WINTER REVERIE / A MOMENT IN THE SNOW。\n'+p)]))
t='wan2.2文生图单个提示词';raw=body(t);p=raw.split('翻译：',1)[0].strip();q=p.replace('â\x80\x99','’');a.append(dict(id='T177-rain-couple',title=t,type='直接生图',input='虚构28岁女性和30岁男性，普通雨夜拥抱场景。',refs=[],excerpt=p,changes=['只选完整英文原文；将mojibake â还原为弯引号，另存原文。','填入虚构成年年龄，不声称真实东京实拍或上传Facebook；原WAN2.2未实测。'],cases=[dict(name='output',prompt='Both people are wholly fictional adults: the woman aged 28 and the man aged 30. '+q)]))
t='世界杯';p=re.findall(r'```[^\n]*\n(.*?)```',body(t),re.S)[0];q=p.replace('@图片1','@图片1（本次参考1：32岁虚构成年女性脸部）').replace('@图片2','@图片2（本次参考2：无品牌法国配色合成球衣）');a.append(dict(id='T178-football-poster',title=t,type='参考编辑/海报直接生图',input='第一条体育海报模板。图1=成年女性身份参考；图2=合成球衣，7号。',refs=[w,kit],excerpt=p,changes=['缺少普通球衣参考，生成无品牌法国配色测试球衣，非官方队服，队徽采用合成圆形三色徽记。','原品牌/赞助商要求本次适配为无品牌配色测试，保留原文另记改动；标题未指定填FRANCE / RISE TO THE MOMENT。','同页足球进攻视频/子弹时间/球迷静帧/后备箱/变身/四旅行背景均未执行。'],cases=[dict(name='output',prompt='本次为虚构足球运动员的静态体育海报。参考1只锁定合成成年女性面部，参考2为本次虚构无品牌球衣。球衣号码7，胸部采用参考的圆形三色徽记；本次不加入厂商品牌或赞助商标志，原文品牌美学仅作为抽象视觉参考。粗体标题FRANCE，副标题RISE TO THE MOMENT。\n'+q)]))
t='超燃AI打斗提示词分享';a.append(dict(id='T179-fight-video',title=t,type='纯视频任务',input='15秒连续长镜头打斗视频，时序与动作及破镜连续性要求，本轮不适用。',refs=[],excerpt=body(t),changes=[],cases=[]))
(B/'batch36-input.json').write_text(json.dumps(a,ensure_ascii=False,indent=2))
