from pathlib import Path
import json,re,shutil,sys
B=Path(__file__).resolve().parent
def prepare(items):
    tasks=[]
    for item in items:
        title=item['title']
        row=next(r for r in json.loads((B/'inventory.json').read_text()) if Path(r['original_filename']).name.endswith('] '+title+'.md'))
        p=B/row['local_path']
        text=p.read_text(); body=text.split('## 正文',1)[1]
        blocks=re.findall(r'```[^\n]*\n(.*?)```',body,re.S)
        if 'excerpt' in item: selected=item['excerpt']
        elif blocks: selected=blocks[item.get('block',0)]
        else:
            selected=re.sub(r'!\[.*?\]\([^\n]*','',body).replace('<empty-block/>','').replace('<br>','\n').strip()
            match=re.search(r'\*\*提示词[^\n]*Original[^\n]*\*\*',selected)
            if match:selected=selected[match.end():].split('---',1)[0].strip()
        if item.get('unescape_json'):
            selected=re.sub(r'\\([{}\[\]])',r'\1',selected)
        for key,value in item.get('replacements',{}).items():selected=selected.replace(key,value)
        prompt=item.get('prefix','')+selected+item.get('suffix','')
        d=B/'results'/item['id'];d.mkdir(exist_ok=True)
        shutil.copy2(p,d/'original.md')
        data={'test_id':item['id'].split('-')[0],'title':title,'type':item.get('type','直接生图/参考编辑提示词'),'test_input':item['input'],'reference_material':item.get('refs',[]),'tool':'image_gen.imagegen','image_model':'未知','adaptation':'ChatGPT适配测试，非原指定模型实测','changes':item.get('changes',[]),'selected_source_prompt':selected,'final_prompt':prompt}
        if 'meta_output' in item:data['meta_output']=item['meta_output']
        (d/'test.json').write_text(json.dumps(data,ensure_ascii=False,indent=2))
        tasks.append({'id':data['test_id'],'dir':item['id'],'prompt':prompt,'refs':item.get('refs',[])})
    return tasks
if __name__=='__main__':
    items=json.loads(Path(sys.argv[1]).read_text());tasks=prepare(items)
    (B/('tasks-'+Path(sys.argv[1]).stem+'.json')).write_text(json.dumps(tasks,ensure_ascii=False,indent=2))
    print(json.dumps(tasks,ensure_ascii=False))
