from pathlib import Path
import json,re
from prepare_batch import B
inv=json.loads((B/'inventory.json').read_text());w=str(B/'materials/adult-woman-synthetic.png')
def sel(t):
 s=(B/next(r['local_path'] for r in inv if Path(r['original_filename']).name.endswith('] '+t+'.md'))).read_text().split('## 正文',1)[1];bs=re.findall(r'```[^\n]*\n(.*?)```',s,re.S)
 if bs:return bs[0]
 return s.split('**提示词',1)[1].split('**',1)[1].split('---',1)[0].replace('<br>','\n').strip()
a=[]
for id,t,refs,prefix in [('T146-tokyo-poses','生成人物不同姿势九宫格',[w],'测试主体为参考中的32岁虚构成年女性，保留白T深蓝裤白鞋。地点东京塔35.6586N 139.7454E，时间为工具读取2026-10-18 07:46 JST。天气查询被网络403拒绝，因此本次仅假设晴天早晨画面，不能视为实时天气核验。'),('T147-mirror-field','电影感十足的肖像摄影作品',[],'The subject is a wholly fictional 28-year-old adult woman. '),('T148-pajama-wink','缎面睡衣甜心眨眼萌拍',[w],'The subject is a fictional 32-year-old adult woman, use her face from the synthetic reference. '),('T149-pink-scale','芭比粉巨人娃娃视差术',[],'Both different-scale figures portray the same wholly fictional 30-year-old adult woman. '),('T150-caricature-square','超写实3D漫画肖像',[w],'Use the face of the fictional 32-year-old adult woman in the synthetic reference. ')]:
 p=sel(t);orig=p;ch=['填入虚构成年人物，原文保留。']
 if id.startswith('T146'):ch+=['填充东京塔坐标及实际读取的日本时间。','天气数据请求失败：URLError Tunnel connection failed:403 Forbidden；采用假设晴天，仅画面测试。']
 if id.startswith('T148'):
  p=p.replace('[User Portrait Slot]','a fictional 32-year-old adult woman with a short side-parted black bob and small left-cheek mole').replace('[Apparel/Outfit Slot]','white satin button-up shirt and shorts, white socks')
  ch+=['填充肖像槽与服装槽；--ar/--v/--no保留文本，不冒充Midjourney参数执行。']
 if id.startswith('T150'):
  values={'[NAME\\]':'the fictional adult woman in the reference','[OUTFIT / SIGNATURE LOOK\\]':'a plain white T-shirt, navy trousers and white sneakers','[POSE / ACTION\\]':'cheerful standing pose with one hand waving'}
  for k,v in values.items():p=p.replace(k,v)
  ch+=['填充姓名/造型/动作槽：'+json.dumps(values,ensure_ascii=False),'1080x1080为原文要求，实际文件尺寸在记录中检验，不后处理伪造。']
 a.append(dict(id=id,title=t,type='直接生图/参考编辑',input=prefix,refs=refs,excerpt=orig,changes=ch,cases=[dict(name='output',prompt=prefix+p)]))
(B/'batch30-input.json').write_text(json.dumps(a,ensure_ascii=False,indent=2))
(B/'tokyo-weather-batch30.json').write_text(json.dumps(dict(clock_utc='2026-10-17 22:46:22 UTC',tokyo_time='2026-10-18 07:46 JST',source='clock.curr_time',weather_url='https://api.open-meteo.com/v1/forecast?latitude=35.6586&longitude=139.7454&current=temperature_2m,relative_humidity_2m,is_day,precipitation,weather_code,cloud_cover,wind_speed_10m&timezone=Asia%2FTokyo',weather_error='URLError: Tunnel connection failed:403 Forbidden',assumption='晴天，仅画面测试，实时天气未验证'),ensure_ascii=False,indent=2))
