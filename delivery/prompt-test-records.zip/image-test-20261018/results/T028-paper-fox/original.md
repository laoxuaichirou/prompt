# 头部的几何肖像

| 属性 | 值 |
|---|---|
| 状态 | 已投产 |
| 评分 | 4 |
| 模型 | Nano Banana |
| 场景 | 海报封面 |
| Notion | [头部的几何肖像](https://app.notion.com/p/305079fdbc3880229c69fe18a771ee75) |

**备注**：纸艺拼贴模板，[ANIMAL]占位可替换

---

## 正文

## **头部的几何肖像**
**来源: **@TechieBySA
![](https://prod-files-secure.s3.us-west-2.amazonaws.com/bbcfb07b-b0c8-41fd-b8ac-003bd9bb920b/d4e71272-808c-4486-b74c-ca398a7aae8c/image.png?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Credential=ASIAZI2LB466SJXLBTIT%2F20261017%2Fus-west-2%2Fs3%2Faws4_request&X-Amz-Date=20261017T092620Z&X-Amz-Expires=3600&X-Amz-Security-Token=IQoJb3JpZ2luX2VjEDAaCXVzLXdlc3QtMiJHMEUCIQDXQmM4FVGy7PJVtELf%2FdW5pYLQKkG47GjUtCwPK5BJVAIgYK%2FO2nZo7F0%2FksECW%2FqPmStztibAErw0OWw0KietHtkqiAQI%2BP%2F%2F%2F%2F%2F%2F%2F%2F%2F%2FARAAGgw2Mzc0MjMxODM4MDUiDAnuTx%2FOYOlOCbhAqyrcA%2FcdueIn1lnLxxsVz%2FuPGB%2F7sNX3dqZ2IxGXxZH4kG4Wul7heKhkzwf4S5MpVm5orSk8OFJoOM44dAa1AK4VHAlM8bmN0ojyyj8H1iJaLPLdJBf5HlGfhgK%2B4R2pcp3Tv9q%2BaCfmjBquZySCzDF06m5sI%2F4zbR5nTsaqZOqbvZCoyo%2FVxYu5TPzT8%2FCmyKJfx6ZtN6BnABq1nSxk9JRpIVvtitO5ZujSv1KUq0haE1t8mrTJPUDO9FjFwKwZz0N18BN6mn5z1LavdMSb4HmQxWyP8N1DhW1TOkLkDU9hbLcVWtbPvXdfFG71qvDJh%2Fl%2F3%2F%2FF6M4rwNdwopqlLQrJrA3tRnNqh5QEE7YK7YVIqCQuOg60h4AbmHj%2F9B2ClyS5ylBMtjEFMOvmVj1AUUFHLcawNTPu1OCbIt6O%2FAsPkmrN9ZDTMO4d%2FcdYYwIuTRhz7qf%2FgeOPkIj32E44hqLuL4XeC%2FPoxxixQJIzIWMHCZJEu2wOfvEivU%2Bs651h7BgVQP20kaCqx%2FoaKMH1CorNld2H%2BsgEN86X9271%2BRs1O7JupQTZGcpji1%2BpHWajOiL8mw%2FeuPR5fTzwcePvWpiUxUo5tHG%2BPIja0%2FMTfaX6uLHL53IymFPYTxjx2tMzMMrRzNYGOqUBal8BMVjBwBpot%2B5hvh8oqaRn0M11KCz1ArZVjGKX10GdBgzR0RtKm29uDzZIhttl%2B0nKuk%2FHG6Do4myDZJzS0khMb2PiH1V56CxkjI3Uov3GTSLdHgWGKPIAevttI7v%2BNRDuj%2BfH19Q6y5oJwXzL7vp8h0FaPNbVN65CEu2Tx85T1PmWLQUHdyLp2ASB0AczrF5Dz%2BRGYl349IyXF98uMcd355fu&X-Amz-Signature=e4488b1c1e1fdc5a3f6f54deed56b80006ed35a2b2f104e4c66c3cf2ecb1adcd&X-Amz-SignedHeaders=host&x-amz-checksum-mode=ENABLED&x-id=GetObject#notion_record=block.305079fd-bc38-80e4-9fcd-dbff480800e7.bbcfb07b-b0c8-41fd-b8ac-003bd9bb920b)
**提示词 (Original)复制**
Design a geometric portrait of a [ANIMAL\] head in the style of contemporary paper craft collage. Use multiple overlapping paper textures and shadow effects to build dimensional depth. Focus on botanical-inspired color palettes with matte finish aesthetics. The composition should feature bold, angular cuts that form the animal’s distinctive characteristics while maintaining facial symmetry. Set against a minimalist backdrop with subtle gradient. The final piece should evoke the craftsmanship of museum-quality paper installations. Square format, 1080x1080 pixels.
---
**提示词 (中文)复制**
设计一幅[动物\]头部的几何肖像，采用当代纸艺拼贴风格。运用多种重叠的纸张纹理和阴影效果来构建立体深度。聚焦于植物灵感的色彩搭配，呈现哑光质感美学。构图应采用大胆的棱角切割，既塑造出该动物的独特特征，又保持面部对称性。背景为简约风格，带有微妙的渐变效果。最终作品需展现出博物馆级纸艺装置的精湛工艺。尺寸为正方形，1080x1080像素。
