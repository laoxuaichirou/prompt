# 液态芭蕾与弗拉明戈

| 属性 | 值 |
|---|---|
| 状态 | 已投产 |
| 评分 | 4 |
| 模型 | Nano Banana |
| 场景 | 海报封面、电商产品 |
| Notion | [液态芭蕾与弗拉明戈](https://app.notion.com/p/305079fdbc38803ca925f4cc516914b1) |

**备注**：创意强，中文段instructions标签粘连

---

## 正文

![](https://prod-files-secure.s3.us-west-2.amazonaws.com/bbcfb07b-b0c8-41fd-b8ac-003bd9bb920b/9ceb0bd7-c05d-4e97-a5f6-39682a16c30b/image.png?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Credential=ASIAZI2LB466SCC6P2XP%2F20261017%2Fus-west-2%2Fs3%2Faws4_request&X-Amz-Date=20261017T091938Z&X-Amz-Expires=3600&X-Amz-Security-Token=IQoJb3JpZ2luX2VjEDAaCXVzLXdlc3QtMiJHMEUCIQDCSXBI0%2BB0C%2BaodF7TI3KsiNU0%2BRnE%2FbGmTOMP4ZQKswIgQ4CfON6YP6i4bnS9rJfsuV0B07xeGOK8saCTBxTwnFYqiAQI%2BP%2F%2F%2F%2F%2F%2F%2F%2F%2F%2FARAAGgw2Mzc0MjMxODM4MDUiDPdJZ7wVjWU%2FFSQssSrcA27yNdIjmr13tSEakDlSAd5u93o5d8oXERwWW3hZF9vLj9uSgbHh9obkXPQRnH1ZLd48jAsCjkICS82xf8sL5PWUhG3TTYVn1NrNo%2B18SGEOPm%2Be4grEa7bdaxEq0vmcZS44sO2zRv34FORS2ImfcNar7iakKDc5R2wfYCFrSmWRvwDJLFRH4YrDfL8hGbZzYRGJ%2BdKJt56tYXsMb16tShZKwaGLH0J9wyMiY2IJfcDBOoU5DgkZ9aVsAzx7eALPm1EEgf1BUzHOV2w%2BqrROfwYDRpUVOR%2FTtY19qySbJeYqUDjJkTPe1KxiMILQ52R2tkj7LdcR%2BqldNNIeVgs13nNw7PHC8ACjKss1yMyvuHZoF2ypnA9UJJ10kwvDX%2BFopUhhp2meWpF6nqDmY0rsn6%2BZYOHw4vc6YE%2BCKXTddzH7xAsfKWH67CvdSzNbr6OoHNiAyA39b8kQ%2Flxo43MRpcrVRdIpHs%2FIf8eB6WtvEOXBAFsxvbXSm9rVuDcEGbDKZ5mnByvQDnhjLoYK2ocaubxyRA1f%2BNitSy%2BMRl7RaTpixFvV2AyCFAqzHUsQPalqALtQ%2B1yB7%2FEFSBREMibkW%2Bbn9o6gQ5%2BrrEY9XNns18ObmbGFVBpcDz%2B186h%2BMKbTzNYGOqUBEapcfCXwSBub1PHUxEF4wK%2FmpzwaLXVNNSAgfE%2FphdZ0h64Q1eCdplhgSlPvJ7raBV%2F4s1oV52L1DAwYGPjAly%2FxPt1temB5nSXrrzt2Pfw7vpi6H0A5xlZoB2DVDbw9UzX1yhDwkeRYaofVLbY0Q4aS3dSB8bumyEI%2BNfObZR18oaQkd%2FqUR9hCByRjsFKDKKIq56uUiH7XQHF69SEIQNi5yj%2Fx&X-Amz-Signature=7532e472a0d3a5ba2cd3101a0aa2258dd7e074a1110e2042f7d35d15d3cfc18d&X-Amz-SignedHeaders=host&x-amz-checksum-mode=ENABLED&x-id=GetObject#notion_record=block.305079fd-bc38-80c4-bb30-c5bcb5ab80f4.bbcfb07b-b0c8-41fd-b8ac-003bd9bb920b)
## **提示词**
**English**
<empty-block/>
```plain text
do this for 4 random distinct dance styles from around the world in a 2x2 grid, include country and dance name in each grid
<instructions>
Input Variable: [Dance Style] (e.g., Ballet, Breakdance, Tango)
Phase 1: Material & Viscosity Logic (AI Deduce)
Select the "Body Material": Choose a liquid relevant to the culture.
Logic: If Ballet -> White Milk/Cream (Smooth, opaque).
Logic: If Flamenco -> Red Wine/Sangria (Translucent, vibrant).
Logic: If Breakdance -> Black Coffee/Cola (High contrast, gritty).
Select the "Accent Material": A secondary liquid for contrast (like the yellow yolk in your example).
Constraint: Must be a complementary color.
Phase 2: The "Hydro-Anatomy" Construction
The Pose: The liquid is frozen in a Signature Move of that dance (e.g., An Arabesque, A Headspin, A Dip).
The Anatomy:
The Torso: Thick, cohesive liquid (high viscosity).
The Limbs: As the limbs extend, the liquid stretches thin, becoming translucent or breaking into droplets at the fingers/toes.
The Head: A perfect, spherical droplet or a coalesced blob of sauce.
The Dress/Clothing: The "Splash" at the base or waist acts as the skirt or baggy clothes, fanning out due to centrifugal force.
Phase 3: The Collision (The Garnish)
The Impact: The figure is rising out of a Splash Crown on the plate (Slate or Stone).
The Shatter: Where the secondary liquid meets the primary liquid, small shards/droplets fly off, adding dynamic energy.
Output: 1/10,000th Shutter Speed, Macro Studio Photography, Black Background, "Liquid Sculpture."
</instructions>
```
**中文**
<empty-block/>
```plain text
在一个2x2网格中展示来自世界各地的4种随机不同舞蹈风格，每个格子中都要包含国家和舞蹈名称<instructions>
输入变量：[舞蹈风格]（例如，芭蕾、霹雳舞、探戈）
阶段1：材料与黏度逻辑（AI推理）
选择“身体材料”：选择一种与相关文化有关的液体。
逻辑：如果是芭蕾->白色牛奶/奶油（顺滑、不透明）。
逻辑：如果是弗拉明戈->红葡萄酒/桑格利亚（半透明、鲜艳）。
逻辑：如果是霹雳舞->黑咖啡/可乐（高对比、粗犷）。
选择“强调材料”：一种用于对比的次级液体（如示例中的黄色蛋黄）。
约束：必须是互补色。
阶段2：“流体解剖”构建
姿势：液体凝固在该舞蹈的标志性动作中（例如，阿拉贝斯克、头旋、俯身下腰）。
解剖结构：
躯干：浓稠、有凝聚力的液体（高黏度）。
四肢：当四肢伸展时，液体被拉薄，变得半透明或在手指/脚趾处断裂成液滴。
头部：一个完美的球体液滴或一团凝结的酱汁。
服装/衣物：底部或腰部的“飞溅”充当裙摆或宽松衣物，因离心力而展开。
阶段3：碰撞（装饰点缀）
冲击力：人物从盘子（石板或石头）上的飞溅皇冠中升起。
破碎：次级液体与主液体相遇处，小碎片/液滴飞出，增加动态能量。
输出：1/10000秒快门速度，微距工作室摄影，黑色背景，“液体雕塑”。
</instructions>
```
