# C站提示词摘取 

| 属性 | 值 |
|---|---|
| 状态 | 仅参考 |
| 评分 | 2 |
| 模型 | 通用 |
| 场景 | 模型工具 |
| Notion | [C站提示词摘取 ](https://app.notion.com/p/C-2dc079fdbc3880e7b653c1f48b8d34de) |

**备注**：已修机翻错词；内容仍较零散

---

## 正文

![](https://prod-files-secure.s3.us-west-2.amazonaws.com/bbcfb07b-b0c8-41fd-b8ac-003bd9bb920b/dccbacec-1dda-4acf-8b6b-4ef44140bc6a/image.png?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Credential=ASIAZI2LB46624ZR27PU%2F20261017%2Fus-west-2%2Fs3%2Faws4_request&X-Amz-Date=20261017T092029Z&X-Amz-Expires=3600&X-Amz-Security-Token=IQoJb3JpZ2luX2VjEDAaCXVzLXdlc3QtMiJHMEUCIQDpMBjBMg0XxnbbEv3UX77uNOlesyorzJ22hg3a5hpPZAIgHrfVGZ5o00tbUiON9bfhOd8B0E7Q3g93U%2BsogRwLmYoqiAQI%2Bf%2F%2F%2F%2F%2F%2F%2F%2F%2F%2FARAAGgw2Mzc0MjMxODM4MDUiDJf1t3CiIHSm2J8cOCrcA%2BHZ6zG2sxyhamtkj9t6dBBpVqW%2FO27YGOLTZLlPR1%2FKn%2BHm6Z6DE2e8UTusOV4eyVUggqbYUJNJ2VW3yvj2lWCI5E7yDdo8ZZpRvzl%2BMX5xdY4fp4HCwUF%2B%2BuSEtA3VI85PAMYqJ32EiEW6mBIo6eq39Z9F%2BR5ivWncA17FbRyfg%2FRnfTUjm7tcm0uLE%2F4KabSohj1MMg7f6gmG8wNTGwhIIv7ejugVenPcsXx2HvPhqYB5VxY6%2FK1WgKG%2BE%2BIFjtfRImG%2FuZj3fbbJofl5P0ENZOeLktPyS6RMDdtQn%2B2sRe2HC0Hr47Wbh5alMi3HrU525n572jlSSe405XpZpYIdYwHzWzzeQWM4GlJWxCe3Us4jySgA5VpLip1R1KagtpKf7VyFZYE%2FSYyFmNMad0WvwwWrsvxi%2FGm6O%2FjUv%2FH%2FWLTR3b24TpcqjjMlpbDP7kUTl511OhO1I%2BkyHLy78V%2F1NLpTFNeDhJ2K6Qt96ToNCFLC%2FRC%2BgmXFMkjGcX1yZ7FrnjrB7QuhPawt0%2FY%2Bl2FIYPFn4H5JISrcMtEiH8rXp43Raaw5v77iKPpe1DKNb4svqFwVuBwPJHFV%2Bco0Dm%2FviRP9dqG6O1PHb9SIPb2fk934n0y9%2BihAPc8zMJ%2FTzNYGOqUB8kyPozFMw0%2FZl5LtATnfs6PHbQ2dvpmxfgB%2FrkIprU%2BaUNgD7%2F5bgrSa220cH9WXY0w%2Fgmn9M8sty4fZUj4uLjmCNb9xiefM2PvKcP2Qr2ELuWgZ5RgEteHwQj5g1cqCqu4C01i8odZ2Dohpit8MvGVyTpUL9AcnFL2n6C1PDwH1lrFjeeQZ6WX81%2F05ikJJD%2FYulsSL%2B75Cq1ahrrSz9yUei2dC&X-Amz-Signature=d2ba44b9015b7cb3eff407d4e3fe6a1fa79d4bcb22b0e00f77378ad319c1caff&X-Amz-SignedHeaders=host&x-amz-checksum-mode=ENABLED&x-id=GetObject#notion_record=block.2dc079fd-bc38-81c2-b104-ce639168e879.bbcfb07b-b0c8-41fd-b8ac-003bd9bb920b)
<page url="https://app.notion.com/p/2dc079fdbc388187861aedb6ac277cdd">提示词01</page>
<empty-block/>
![](https://prod-files-secure.s3.us-west-2.amazonaws.com/bbcfb07b-b0c8-41fd-b8ac-003bd9bb920b/c4ccbd94-242e-4dcd-b2ee-6ccd0c28fea3/image.png?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Credential=ASIAZI2LB46624ZR27PU%2F20261017%2Fus-west-2%2Fs3%2Faws4_request&X-Amz-Date=20261017T092029Z&X-Amz-Expires=3600&X-Amz-Security-Token=IQoJb3JpZ2luX2VjEDAaCXVzLXdlc3QtMiJHMEUCIQDpMBjBMg0XxnbbEv3UX77uNOlesyorzJ22hg3a5hpPZAIgHrfVGZ5o00tbUiON9bfhOd8B0E7Q3g93U%2BsogRwLmYoqiAQI%2Bf%2F%2F%2F%2F%2F%2F%2F%2F%2F%2FARAAGgw2Mzc0MjMxODM4MDUiDJf1t3CiIHSm2J8cOCrcA%2BHZ6zG2sxyhamtkj9t6dBBpVqW%2FO27YGOLTZLlPR1%2FKn%2BHm6Z6DE2e8UTusOV4eyVUggqbYUJNJ2VW3yvj2lWCI5E7yDdo8ZZpRvzl%2BMX5xdY4fp4HCwUF%2B%2BuSEtA3VI85PAMYqJ32EiEW6mBIo6eq39Z9F%2BR5ivWncA17FbRyfg%2FRnfTUjm7tcm0uLE%2F4KabSohj1MMg7f6gmG8wNTGwhIIv7ejugVenPcsXx2HvPhqYB5VxY6%2FK1WgKG%2BE%2BIFjtfRImG%2FuZj3fbbJofl5P0ENZOeLktPyS6RMDdtQn%2B2sRe2HC0Hr47Wbh5alMi3HrU525n572jlSSe405XpZpYIdYwHzWzzeQWM4GlJWxCe3Us4jySgA5VpLip1R1KagtpKf7VyFZYE%2FSYyFmNMad0WvwwWrsvxi%2FGm6O%2FjUv%2FH%2FWLTR3b24TpcqjjMlpbDP7kUTl511OhO1I%2BkyHLy78V%2F1NLpTFNeDhJ2K6Qt96ToNCFLC%2FRC%2BgmXFMkjGcX1yZ7FrnjrB7QuhPawt0%2FY%2Bl2FIYPFn4H5JISrcMtEiH8rXp43Raaw5v77iKPpe1DKNb4svqFwVuBwPJHFV%2Bco0Dm%2FviRP9dqG6O1PHb9SIPb2fk934n0y9%2BihAPc8zMJ%2FTzNYGOqUB8kyPozFMw0%2FZl5LtATnfs6PHbQ2dvpmxfgB%2FrkIprU%2BaUNgD7%2F5bgrSa220cH9WXY0w%2Fgmn9M8sty4fZUj4uLjmCNb9xiefM2PvKcP2Qr2ELuWgZ5RgEteHwQj5g1cqCqu4C01i8odZ2Dohpit8MvGVyTpUL9AcnFL2n6C1PDwH1lrFjeeQZ6WX81%2F05ikJJD%2FYulsSL%2B75Cq1ahrrSz9yUei2dC&X-Amz-Signature=817fe6e5961bca3abf18aac688890a7e1695a7519df06013573b068b8fc43517&X-Amz-SignedHeaders=host&x-amz-checksum-mode=ENABLED&x-id=GetObject#notion_record=block.305079fd-bc38-80ed-95db-f99fa2e61ddf.bbcfb07b-b0c8-41fd-b8ac-003bd9bb920b)
这是一张充满活力和童趣的开学主题宣传海报,整体设计色彩鲜艳,活泼,传达出积极向上的氛围,画面以明亮的蓝色为主色调,象征希望与活力,背景简洁,突出主体内容,中央是一个可爱的卡通男孩形象,表情开心,眼神闪烁着兴奋的光芒,显得充满活力和期待,他身穿白色短袖衬衫,深色裤子和橙色运动鞋,背着棕色书包,迈步向前走,姿态轻快,展现出迎接新学期的干劲,周围点缀着学习相关的元素,如笔记本,pencil,爱心等,增添了趣味性和童真感,顶部大标题“你好 新学期”字体醒目,左侧有国际化元素“NIHAO XINXUEQI”,右侧小标题“新学期新起点”搭配学士帽图标,强调新开始的意义,右上角的日历显示日期为“17”,底部隐约可见祝福语“GONGXI”,整体色调明亮,以蓝色,yellow long upper shirt,粉色为主,角色服装颜色鲜艳,与背景形成对比,使人物更加突出,动态效果自然流畅,男孩的动作和周围的装饰元素增加了画面的动感和层次感,这张海报通过欢快的角色姿态和丰富的细节,成功传递了新学期的喜悦与期待,充满了青春活力,非常适合用于开学季的宣传,
<empty-block/>
<empty-block/>
<empty-block/>
