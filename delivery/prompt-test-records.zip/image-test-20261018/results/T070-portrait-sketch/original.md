# 绕过真人检测方法

| 属性 | 值 |
|---|---|
| 状态 | 仅参考 |
| 评分 | 3 |
| 模型 | 通用 |
| 场景 | 模型工具 |
| Notion | [绕过真人检测方法](https://app.notion.com/p/315079fdbc3880f78e76faaf37339c6b) |

**备注**：草稿态思路；商用需自行评估合规风险

---

## 正文

![](https://prod-files-secure.s3.us-west-2.amazonaws.com/bbcfb07b-b0c8-41fd-b8ac-003bd9bb920b/d36b28ce-0ea7-4a1f-9de6-70a7ef95c56d/image.png?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Credential=ASIAZI2LB466ZE4Z5QZL%2F20261017%2Fus-west-2%2Fs3%2Faws4_request&X-Amz-Date=20261017T091852Z&X-Amz-Expires=3600&X-Amz-Security-Token=IQoJb3JpZ2luX2VjEDAaCXVzLXdlc3QtMiJHMEUCIDivcFDF5dQ%2Fg%2BgKuEUQQW3QyA8KVmQts2DJci5w4thLAiEA%2Bf0ChGzAjeL3DTpX6NCWkOhz2cQ8P3evy3eiXYEmk50qiAQI%2Bf%2F%2F%2F%2F%2F%2F%2F%2F%2F%2FARAAGgw2Mzc0MjMxODM4MDUiDPExXcflG5uZGUJ7%2FCrcAwA1nvwQ5ypeLC8pL53C1iaV6ykvyLdlALD%2BLSI5OJK30%2FFFDeoU66cZZbSJRh4Gjn67weXnfiknMRv7mbEuPo8BTW65TupVs%2BLJg%2B7vxiy%2Bxw4bn3yd1RH11dRAd1HAzO5hl2rVnsX%2BJcTdXP1ZJ3Z%2F3hZ8uyinFLobiRGy75sO2295iu6zvBJBQnyMM6JnKSoPuxmsIfs9YYNA6N3eslgNW%2FRrOOS%2FgPKjwlaLdbjuX65e%2F7ys2YoVq1RnneWwwfetiEXaVfWMoQCbZfOsLgcXExikcB9DWf42u1d61IYQ3qQHNL%2FeN%2B%2FCgSxzmqTlUn0T3%2BmYQx5zxBDtkrDDP35aulzUR4a4jh%2BEtu04y0yv2OouFpbjxvrE7B50LeFGHpxsu91rwr%2BBLdus5r2nVV20EiK%2FBFwqrPXxNAfjxwt8hEy2LQSjz%2ByeZQDAp5wpJHm1EJ6k%2FYE7KBbkaKYLgRYBAGYpuIrUo9AuCvs4xWPHGGcmJDz37Dw8YtfIDJv6f7IKfd7CGpQUG1gvOdhxNYfW1HtTJ38wniQyh6DN59gmRdHRoVPwb294Nx4A4U3%2FCDLy6uTgae9rDA3a%2F0Clh7XY6LW4PUWsOg3WFQlAbEEDWCGKBzK9KwkOZqW1MNTRzNYGOqUBfuDJD4KOdQYnhV7yc1UD9olZL8MNpaotUkPSTQDHDMmPEDJPyZwgWxqaiy8I4mjanV6FT0%2Bi9G0b6y9utndxBRBY2hDajG3QzCfQTpXR88dCe%2BgnqzVkRI7xxMUUnt5Itmle4eaNrW3yMNHEzCpgcdUyUxlQo37wWhS91MW9SW1qs8%2FM7dm50GWzYgwsvGm2Zy1IisgZh1grKfchRk4zCqQGT7dA&X-Amz-Signature=079a36a0e67bca8a895c741c3e07dc37754f031116bd04b76d0363b2cf24ec18&X-Amz-SignedHeaders=host&x-amz-checksum-mode=ENABLED&x-id=GetObject#notion_record=block.315079fd-bc38-80f5-b0b2-c0d8d509d00a.bbcfb07b-b0c8-41fd-b8ac-003bd9bb920b)
将图片改成素描
![](https://prod-files-secure.s3.us-west-2.amazonaws.com/bbcfb07b-b0c8-41fd-b8ac-003bd9bb920b/5d296b88-8a6e-47c4-b0d8-cc15dc7f45c4/image.png?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Credential=ASIAZI2LB466ZE4Z5QZL%2F20261017%2Fus-west-2%2Fs3%2Faws4_request&X-Amz-Date=20261017T091852Z&X-Amz-Expires=3600&X-Amz-Security-Token=IQoJb3JpZ2luX2VjEDAaCXVzLXdlc3QtMiJHMEUCIDivcFDF5dQ%2Fg%2BgKuEUQQW3QyA8KVmQts2DJci5w4thLAiEA%2Bf0ChGzAjeL3DTpX6NCWkOhz2cQ8P3evy3eiXYEmk50qiAQI%2Bf%2F%2F%2F%2F%2F%2F%2F%2F%2F%2FARAAGgw2Mzc0MjMxODM4MDUiDPExXcflG5uZGUJ7%2FCrcAwA1nvwQ5ypeLC8pL53C1iaV6ykvyLdlALD%2BLSI5OJK30%2FFFDeoU66cZZbSJRh4Gjn67weXnfiknMRv7mbEuPo8BTW65TupVs%2BLJg%2B7vxiy%2Bxw4bn3yd1RH11dRAd1HAzO5hl2rVnsX%2BJcTdXP1ZJ3Z%2F3hZ8uyinFLobiRGy75sO2295iu6zvBJBQnyMM6JnKSoPuxmsIfs9YYNA6N3eslgNW%2FRrOOS%2FgPKjwlaLdbjuX65e%2F7ys2YoVq1RnneWwwfetiEXaVfWMoQCbZfOsLgcXExikcB9DWf42u1d61IYQ3qQHNL%2FeN%2B%2FCgSxzmqTlUn0T3%2BmYQx5zxBDtkrDDP35aulzUR4a4jh%2BEtu04y0yv2OouFpbjxvrE7B50LeFGHpxsu91rwr%2BBLdus5r2nVV20EiK%2FBFwqrPXxNAfjxwt8hEy2LQSjz%2ByeZQDAp5wpJHm1EJ6k%2FYE7KBbkaKYLgRYBAGYpuIrUo9AuCvs4xWPHGGcmJDz37Dw8YtfIDJv6f7IKfd7CGpQUG1gvOdhxNYfW1HtTJ38wniQyh6DN59gmRdHRoVPwb294Nx4A4U3%2FCDLy6uTgae9rDA3a%2F0Clh7XY6LW4PUWsOg3WFQlAbEEDWCGKBzK9KwkOZqW1MNTRzNYGOqUBfuDJD4KOdQYnhV7yc1UD9olZL8MNpaotUkPSTQDHDMmPEDJPyZwgWxqaiy8I4mjanV6FT0%2Bi9G0b6y9utndxBRBY2hDajG3QzCfQTpXR88dCe%2BgnqzVkRI7xxMUUnt5Itmle4eaNrW3yMNHEzCpgcdUyUxlQo37wWhS91MW9SW1qs8%2FM7dm50GWzYgwsvGm2Zy1IisgZh1grKfchRk4zCqQGT7dA&X-Amz-Signature=54f7a7aafd8de58dc95d3d3bbe260ba45073b7a879004e21d5165052d028e9e4&X-Amz-SignedHeaders=host&x-amz-checksum-mode=ENABLED&x-id=GetObject#notion_record=block.315079fd-bc38-8050-831d-c60bf7a1d6d6.bbcfb07b-b0c8-41fd-b8ac-003bd9bb920b)
详细描述这张图片，我希望通过你描述的提示词，可以最大程度的还原图片角色外貌。
你检查一下，用你的提示词生成的图片和原图的相似程度，能不能尽可能的还原原图。
生图测试。
角色是一名女性，参照生成，Photorealistic portrait of a young East Asian woman, perfectly symmetrical front-facing close-up. Oval face, fair skin with realistic subtle texture, gentle closed-mouth smile. Large almond-shaped dark brown eyes, clear double eyelids, soft naturally arched eyebrows, refined straight nose, matte rose-nude lips. Long straight dark brown hair, middle part, subtle messy flyaways. Wearing a light beige classic trench coat with dark round buttons over a light grey fine-ribbed crew-neck sweater. A tiny subtle mole on the center lower neck. Soft flat studio lighting, solid warm light-beige background, 8k resolution, ultra-detailed face.
画面(0-5秒): 一位25岁的中国女性，身穿米白色丝绸质感的风衣，内搭浅灰色高领针织衫，黑色长发微卷。她正沿着种满梧桐树的都市人行道优雅漫步，脚步轻盈，风衣下摆随步伐有节奏地摆动，阳光透过树叶在她脸上投下斑驳的光影。<br>音效(0-5秒): 清脆且有节奏的皮鞋敲击柏油路面的“哒、哒”声，微风拂过树叶的沙沙声，远处隐约的车流白噪音，丝绸风衣摩擦发出的细微“簌簌”声。<br>运镜/环境: 低角度侧跟拍镜头（Low-angle tracking shot），背景是虚化的现代都市街道与秋日落晖，景深较浅，突出主体。<br>画面(5-10秒): 镜头缓慢推近至人物面部特写，她微微转头看向镜头方向，嘴角扬起一抹自信而温柔的微笑，眼神明亮，几缕发丝被风吹乱贴在脸颊上，她抬手轻轻将头发别到耳后。<br>音效(5-10秒): 脚步声渐弱，风声略微放大，手指划过发丝的轻微摩擦声，一声轻柔自然的呼吸声。<br>台词: “今天的风景，刚刚好。”<br>音色: 温柔、知性、带有轻微的气声，语速舒缓，充满愉悦感。<br>风格/限定: 4K分辨率，电影级调色，暖色调，伦勃朗光效，胶片颗粒感，高细节皮肤纹理 --no text, --no watermark, --no cartoon
<empty-block/>
