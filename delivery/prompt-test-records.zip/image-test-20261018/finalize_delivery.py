from pathlib import Path
import json,collections,hashlib
from prepare_batch import B
rows=json.loads((B/'ledger.json').read_text());tests=json.loads((B/'test-records.json').read_text())
counts=dict(collections.Counter(r['status'] for r in rows));blocked=[dict(test_id=r['test_id'],title=r['title'],reason=r['reason']) for r in rows if r['status']=='阻塞']
summary=dict(prompt_entries=len(rows),instruction_documents=3,total_original_files=222,batches=36,last_batch_entries=4,test_records=len(tests),entries_with_images=sum(r['generated_images']>0 for r in rows),test_output_images=sum(r['generated_images'] for r in rows),opened_output_images=sum(r['opened_images'] for r in rows),synthetic_materials=len(list((B/'materials').glob('*.png'))),status_counts=counts,source_missing_blocks=9,tool_filter_blocks=14,wholly_unexecuted_entries=sum(r['status']=='未执行' for r in rows),tool='image_gen.imagegen',image_model='未知',adaptation='ChatGPT适配测试，不是原指定模型实测',assessment='视觉验收为模型初评；符合要求仅针对记录内最小完整用例，不代表全子模板覆盖或稳定性验证。')
(B/'交付汇总.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2))
(B/'续跑位置.json').write_text(json.dumps(dict(last_completed_batch=36,last_test_id='T179',next_regular_batch=None,wholly_unexecuted_entries=0,blocked_entries=blocked,uncovered_subcases='见未完成与续跑.md，以及各条inspection.json/test.json中的明确范围。',resume_rule='补齐原文或特定素材后另建重测子用例，保留本轮原结果；工具过滤无图项目不得记通过；多版本/连续性需足够对比。'),ensure_ascii=False,indent=2))
md='''# 本轮交付说明

219条提示词、3份说明文档已清点。原始文件和原评分未改动。36批逐条分流，最后一批4条；优先待测试14条，随后处理其余非淘汰图像项目。

| 项目 | 本轮数量 |
|---|---:|
| 实际有图的条目 | 146 |
| 测试输出 / 已打开验收 | 217 / 217 |
| 合成测试参考素材（另计） | 16 |
| 符合所测用例要求 | 50 |
| 存在问题 | 96 |
| 阻塞 | 23 |
| 纯视频、音频、Agent等本轮不适用 | 29 |
| 原库已淘汰，跳过 | 21 |
| 整条尚未处理 | 0 |

23条阻塞中，9条缺少原文或子页、14条实际调用后被工具内容过滤且没有返回图片；这些都没有记为生图通过。原库14条待测试中：8条出图但存在问题、2条原文缺失阻塞、4条纯视频不适用。

本轮工具为 image_gen.imagegen，后端模型不可见，记录为未知。原文指定其他模型的均为ChatGPT适配测试。分镜只验收静态画面，没有完成任何视频生成测试。符合要求是模型视觉初评，限定于各条记录的最小完整用例，不代表所有子模板覆盖或稳定性验证。

解压完整包后打开 `图片与记录.html` 可浏览图片与展开记录；`测试记录.md` 是逐项结论与证据；`测试清单.csv`、`ledger.json` 覆盖全部219条；`test-records.json` 汇总179份详细测试/范围记录。每项 `results/` 含原文、测试输入、参考素材、最终提示词、图片及验收；真实工具错误也保留。`materials/` 为16份合成测试素材。原始222文件及路径映射见 `original/` 与 `inventory.json`。

`未完成与续跑.md` 列出阻塞和未覆盖子模板、时序/数值等未验证要求。整条处理完毕不等于这些内容已通过。`续跑位置.json` 给出补齐素材后重测的入口。仅记录包不包含PNG，需使用完整包查看图片。

文件审计通过：222原文SHA256、179原文副本、217张PNG可读性、全部已打开计数与参考路径一致；详情见 `交付审计.json`。文件审计不能替代视觉验收。
'''
(B/'交付说明.md').write_text(md)
# Preserve an auditable list of every batch and its outputs.
batch_index=[]
for n in range(1,37):
 p=B/f'batch{n:02d}-output-map.json'
 batch_index.append(dict(batch=n,output_map=p.name,exists=p.exists()))
(B/'批次索引.json').write_text(json.dumps(batch_index,ensure_ascii=False,indent=2))
assert len(rows)==219 and sum(counts.values())==219
assert summary['test_output_images']==summary['opened_output_images']==217
assert summary['wholly_unexecuted_entries']==0
print(json.dumps(summary,ensure_ascii=False))
