from pathlib import Path
import json,re
from prepare_batch import B
inv=json.loads((B/'inventory.json').read_text());w=str(B/'materials/adult-woman-synthetic.png')
def sel(t):
 s=(B/next(r['local_path'] for r in inv if Path(r['original_filename']).name.endswith('] '+t+'.md'))).read_text().split('## 正文',1)[1];bs=re.findall(r'```[^\n]*\n(.*?)```',s,re.S)
 return bs[0] if bs else s.split('**提示词\xa0(Original)复制**',1)[1].split('---',1)[0].replace('<br>','\n').strip()
a=[]
for id,t,refs,prefix in [('T151-crowd-still','都市静影·人流穿梭',[],'The subject is a wholly fictional 28-year-old adult woman. '),('T152-meadow-chairs','金棕草地黑西装六格时尚大片',[w],'Use the fictional 32-year-old adult woman from the synthetic reference for the face, with brown wavy hair and bangs as instructed. '),('T153-pop-stickers','青春波普贴纸秀',[],'The subject is a wholly fictional 28-year-old adult man with short dark hair. '),('T154-stylized3d','风格化的3D人物漫画',[w],'Use the fictional 32-year-old adult woman in the synthetic reference. Choose a bold coral background. '),('T155-fisheye-heart','鱼眼镜头下的日本女子比心',[],'The model is a wholly fictional 28-year-old adult woman, choose Gyaru styling and a Tokyo subway setting. ')]:
 p=sel(t);orig=p;ch=['填充虚构成年人；按照正文规定造型，不引用原示例身份。']
 if id.startswith('T155'):p=re.sub(r'\\([{}\[\]])',r'\1',p);ch+=['清理HTML换行与导出括号反斜杠；选择Gyaru与地铁场景分支。']
 if id.startswith('T154'):ch+=['背景色填珊瑚色。与近同文T138为不同文件独立新调用。']
 a.append(dict(id=id,title=t,type='直接生图/参考编辑',input=prefix,refs=refs,excerpt=orig,changes=ch,cases=[dict(name='output',prompt=prefix+p)]))
(B/'batch31-input.json').write_text(json.dumps(a,ensure_ascii=False,indent=2))
