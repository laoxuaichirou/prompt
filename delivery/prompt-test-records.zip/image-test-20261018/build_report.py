from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
import json, csv, re, hashlib, zipfile, html
from PIL import Image

B = Path(__file__).resolve().parent
inventory = json.loads((B / 'inventory.json').read_text())
rows = []
pure_video = {'人物集结15S和一分钟【元提示词】', '粒子 特效', '网格动态提示词大师', '【视频】WAN2.2图生视频提示词扩写'}
for item in inventory:
    p = B / item['local_path']
    text = p.read_text()
    m = re.match(r'\[([^·]+)·(\d+)分\] (.+)\.md$', Path(item['original_filename']).name)
    if not m:
        continue
    old_status, old_score, title = m.groups()
    category = Path(item['original_filename']).parts[1]
    state, reason = '未执行', '尚未轮到，未生成图片，未判通过'
    if old_status == '已淘汰':
        state, reason = '跳过', '原库已淘汰，按用户要求跳过'
    elif category in ('Agent应用', '音频音乐'):
        state, reason = '本轮不适用', '纯Agent/音频任务，不纳入生图实测'
    elif title in pure_video:
        state, reason = '本轮不适用', '正文目标为动态视频/转场或视频提示词，未以静态图冒充视频验证'
    override_path=B/'scope-overrides.json'
    if override_path.exists():
        override=json.loads(override_path.read_text()).get(title)
        if override: state,reason=override['status'],override['reason']
    rows.append({'title': title, 'original_filename': item['original_filename'], 'local_path': item['local_path'], 'sha256': item['sha256'], 'category': category, 'old_status': old_status, 'old_score': old_score, 'status': state, 'reason': reason, 'test_id': '', 'generated_images': 0, 'opened_images': 0, 'result_dir': ''})

tests=[]
for p in sorted((B/'results').glob('*/test.json')):
    data=json.loads(p.read_text())
    title=data.get('title',data.get('original_title'))
    row=next((x for x in rows if x['title']==title),None)
    if row is None: raise ValueError('Unmatched test: '+str(p))
    data['original_filename']=row['original_filename']
    data['original_sha256']=row['sha256']
    data['test_date_timezone']='2026-10-18 Asia/Shanghai'
    data['tool']=data.get('tool','image_gen.imagegen' if list(p.parent.glob('*.png')) else '无生图调用')
    data['image_model']=data.get('image_model','未知')
    p.write_text(json.dumps(data,ensure_ascii=False,indent=2))
    q=p.parent/'inspection.json'
    ins=json.loads(q.read_text()) if q.exists() else {'status':'已出图' if list(p.parent.glob('*.png')) else '未执行','conclusion':'待验收'}
    images=[]
    for im in sorted(p.parent.glob('*.png')):
        with Image.open(im) as image:
            images.append({'file':str(im.relative_to(B)),'width':image.width,'height':image.height,'sha256':hashlib.sha256(im.read_bytes()).hexdigest()})
    if ins.get('opened',0)>len(images): raise ValueError('Opened count exceeds saved outputs: '+str(p))
    row.update(status=ins['status'],reason=ins.get('conclusion',''),test_id=data['test_id'],generated_images=len(images),opened_images=ins.get('opened',0),result_dir=str(p.parent.relative_to(B)))
    tests.append({'test':data,'inspection':ins,'images':images})

(B/'ledger.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2))
(B/'test-records.json').write_text(json.dumps(tests,ensure_ascii=False,indent=2))
with (B/'测试清单.csv').open('w',encoding='utf-8-sig',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
counts={s:sum(x['status']==s for x in rows) for s in sorted(set(x['status'] for x in rows))}
md=['# 本轮测试记录（独立于原库评分）','', '更新时间：'+datetime.now(ZoneInfo('Asia/Shanghai')).isoformat(timespec='seconds'),'', '生图工具 image_gen.imagegen；后端模型未知；指定其他模型的均为ChatGPT适配测试。视觉验收为模型初评，不代表稳定性已验证。', '', '原库219条、说明3份。当前状态：'+json.dumps(counts,ensure_ascii=False), '', f'已保存测试输出 {sum(x["generated_images"] for x in rows)} 张；已打开验收 {sum(x["opened_images"] for x in rows)} 张。合成参考素材另计。', '', '|测试ID|原条目|状态|图片/已打开|结论|','|---|---|---|---|---|']
for x in rows:
    if x['test_id']:
        md.append('|'+ '|'.join([x['test_id'],x['title'],x['status'],str(x['generated_images'])+'/'+str(x['opened_images']),x['reason'].replace('|','/').replace('\n',' ')])+'|')
md += ['','## 逐项证据','']
for t in tests:
    d,i=t['test'],t['inspection'];md += ['### '+d['test_id']+' '+d.get('title',d.get('original_title','')),'','原文件：`'+d['original_filename']+'`','', '完整输入、改动、提示词：`'+next(x['result_dir'] for x in rows if x['test_id']==d['test_id'])+'/test.json`','']
    for c in i.get('checks',[]): md.append('- '+c['requirement']+'：'+c['result']+'。'+c.get('evidence',''))
    md.append('')
(B/'测试记录.md').write_text('\n'.join(md))
pending=[x for x in rows if x['status'] in ('未执行','已出图')]
resume=['# 续跑清单','', '未实际生成的项目不能标记为生图实测通过。已存在的results目录不要覆盖，重测另建子用例。优先完成待测试，再按分类复测其余非淘汰图像项目。', '', '未执行条目仍需逐项人工/模型阅读正文后确认是否属于纯视频、缺失页面或可生图，不能仅凭所在分类一概断定。', '']
for x in sorted(pending,key=lambda x:(x['old_status']!='待测试',x['category'],x['title'])): resume.append('- '+x['original_filename'])
if not pending: resume += ['整条未执行/待打开验收：0。各条结论仅覆盖已记录的最小用例；以下阻塞和未覆盖子模板仍不算通过。']
resume += ['', '## 阻塞条目（需素材补齐或工具允许后再跑）', '']
for x in rows:
    if x['status']=='阻塞': resume.append('- '+x['test_id']+' '+x['title']+'：'+x['reason'])
resume += ['', '## 已测条目中的未覆盖子项或限制', '']
for t in tests:
    d,i=t['test'],t['inspection']
    for c in i.get('checks',[]):
        if any(w in c['result'] for w in ('未执行','阻塞','未验证','未验收','不足')):
            resume.append('- '+d['test_id']+' '+c['requirement']+'：'+c['result']+'。'+c.get('evidence',''))
    if d.get('missing'):resume.append('- '+d['test_id']+' 原文缺失：'+str(d['missing']))
(B/'未完成与续跑.md').write_text('\n'.join(resume))
page=['<!doctype html><meta charset="utf-8"><title>真实生图测试记录</title><style>body{font:16px system-ui;margin:30px;background:#f5f5f5;color:#222}article{background:white;padding:22px;margin:24px 0}img{max-width:560px;max-height:650px;object-fit:contain;margin:5px}pre{white-space:pre-wrap}summary{cursor:pointer}h2{margin-top:0}</style><h1>提示词库真实生图测试</h1><p>ChatGPT适配测试；生图后端未知。视觉结果为模型初评，原库评分未改动。</p><p>'+html.escape(json.dumps(counts,ensure_ascii=False))+'</p>']
for t in tests:
    d,i=t['test'],t['inspection'];page += ['<article><h2>'+html.escape(d['test_id']+' '+d.get('title',d.get('original_title','')))+'</h2><p>'+html.escape(i['status']+'：'+i.get('conclusion',''))+'</p>']
    for im in t['images']: page.append('<a href="'+html.escape(im['file'])+'"><img loading="lazy" src="'+html.escape(im['file'])+'"></a>')
    page.append('<details><summary>输入、提示词、清理与验收完整记录</summary><pre>'+html.escape(json.dumps(t,ensure_ascii=False,indent=2))+'</pre></details></article>')
(B/'图片与记录.html').write_text('\n'.join(page))
print(json.dumps({'states':counts,'tests':len(tests),'test_images':sum(x['generated_images'] for x in rows),'opened':sum(x['opened_images'] for x in rows),'materials':len(list((B/'materials').glob('*.png')))},ensure_ascii=False))
