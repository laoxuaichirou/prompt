import json
from pathlib import Path
b=Path(__file__).resolve().parent;D={}
def a(id,n,ch,c,s='存在问题'):D[id]=dict(status=s,generated=n,opened=n,checks=[dict(requirement=x,result=y,evidence=z) for x,y,z in ch],conclusion=c)
a('T146-tokyo-poses',1,[('九格/透视/衣着/地标','基本符合','九格白T深蓝裤同人，东京塔、手掌鞋底近镜头和仰拍等可辨。'),('每格夸张/机位变化','存在问题','第4格普通栏杆回望，无极近前景部位；高位俯拍变化不足。地理范围不能由合成地标外观验证。'),('实时天气','阻塞','实际天气接口网络403失败，仅假设晴天，时间取clock工具实际日本时间；天气要求未验证。')],'九格已出图，透视逐格覆盖及实时天气要求未完整满足。')
a('T147-mirror-field',1,[('田野/镜面/人物造型','符合要求','金色时刻田野，短银金发成年女性黑T浅头巾，坐姿靠镜有相应对称反射，背景虚化，暖光柔对比。'),('边界','模型初评','镜面为合成视觉效果，不代表真实摄影或参数。')],'本次田野镜面肖像符合可见要求。','符合要求')
for id in ['T148-pajama-wink','T149-pink-scale']:a(id,0,[('实际工具结果','阻塞','HTTP400 moderation_blocked，output阶段sexual分类，无返回图片，原始错误及实际Prompt均保存。')],'输出过滤阻塞，无图不可验收。','阻塞')
a('T150-caricature-square',1,[('漫画/服装/动作','基本符合','短黑发大眼3D女性、白T深蓝裤白鞋，微笑挥手、柔棚光与织物细节。'),('头身比例/尺寸','存在问题','身体明显长于头部，未满足body slightly smaller than head；文件1254x1254，不是1080x1080。')],'3D漫画成图，头身比例与精确尺寸未满足。')
(b/'batch30-inspections.json').write_text(json.dumps(D,ensure_ascii=False,indent=2))
