from pathlib import Path
import json,re
from prepare_batch import B
inv=json.loads((B/'inventory.json').read_text());w=str(B/'materials/adult-woman-synthetic.png')
def body(t):return (B/next(r['local_path'] for r in inv if Path(r['original_filename']).name.endswith('] '+t+'.md'))).read_text().split('## 正文',1)[1]
def sel(t):
 s=body(t);bs=re.findall(r'```[^\n]*\n(.*?)```',s,re.S)
 if bs:return bs[0]
 return s.split('**提示词\xa0(Original)复制**',1)[1].split('---',1)[0].replace('<br>','\n').strip()
a=[]
for id,t in [('T131-window-doll','【创意人像】橱窗里出现了一个小小的动画版的自己'),('T132-coffee-story','【剧情人像】金色时光里的咖啡女孩'),('T133-expression-grid','九宫格拼贴画'),('T135-gengar','人物和大型耿鬼')]:
 p=sel(t);orig=p;ch=['填充32岁虚构成年女性，使用同一合成参考；原示例图不当作已取得素材。'];prefix='Use the fictional 32-year-old adult woman in the synthetic reference. '
 if id.startswith('T133'):
  p=re.sub(r'\\([{}\[\]>])',r'\1',p);ch+=['清理导出括号反斜杠与HTML换行；本工具不提供reference strength，0.5-0.7不作为实际参数宣称。']
 if id.startswith('T132'):prefix+='Use one eight-frame storytelling contact sheet, preserving the same short black bob, white T-shirt and navy trousers throughout. ';ch+=['填充统一服装发型和原生8帧拼图布局，不增加故事步骤。']
 if id.startswith('T135'):prefix+='Choose the hooded jacket option. ';ch+=['选择原文连帽夹克分支；不宣称8K或人脸100%已由工具保证。']
 a.append(dict(id=id,title=t,type='直接生图/参考编辑',input=prefix,refs=[w],excerpt=orig,changes=ch,cases=[dict(name='output',prompt=prefix+p)]))
t='人物一致性';p=body(t).split('<empty-block/>',1)[0].strip();c=[]
for name,pattern in [('garden','T077*/*.png'),('street','T101*/*.png')]:
 src=str(next((B/'results').glob(pattern)));refs=[src,w];c.append(dict(name=name,refs=refs,prompt='图1为此前生成的虚构成年场景人物；图2为32岁虚构成年女性身份参考。按下文执行写实身份替换，保留图1服装和动作。\n'+p))
a.insert(3,dict(id='T134-person-swap',title=t,type='图像编辑',input='跨两个合成源场景应用相同女性目标身份，保留各自服装/姿态。',refs=[str(next((B/'results').glob('T077*/*.png'))),w,str(next((B/'results').glob('T101*/*.png')))],excerpt=p,changes=['选择第一个完整替换模板，在两个不同源场景复用同一目标脸执行；后续10角度模板未执行。','风格选择写实，不更改源衣服。'],cases=c))
(B/'batch27-input.json').write_text(json.dumps(a,ensure_ascii=False,indent=2))
