from pathlib import Path
import json,re
from prepare_batch import B
inv=json.loads((B/'inventory.json').read_text());w=str(B/'materials/adult-woman-synthetic.png')
def sel(t):
 s=(B/next(r['local_path'] for r in inv if Path(r['original_filename']).name.endswith('] '+t+'.md'))).read_text().split('## 正文',1)[1];bs=re.findall(r'```[^\n]*\n(.*?)```',s,re.S)
 return bs[0] if bs else s.split('**提示词\xa0(Original)复制**',1)[1].split('---',1)[0].replace('<br>','\n').strip()
a=[]
for id,t,refs,prefix in [('T156-emerge-print','女子仿佛从刚冲洗出来的照片中浮现出来',[w],'Use the synthetic adult woman reference for facial identity; portray this fictional adult as age 28 with long loose waves as specified. Choose blowing a kiss. Set the small frame caption to AUTUMN IN PARIS. '),('T157-character-cartoon','将明星变成趣味十足的3D卡通肖像',[w],'Use the fictional 32-year-old adult woman in the synthetic reference, wearing her white T-shirt, navy trousers and white sneakers. '),('T158-palm-beard','巨人指尖轻戳微缩世界超现实肖像',[],'The miniature man is a wholly fictional 35-year-old adult man, and the palm and finger belong to a fictional adult. '),('T159-beige-editorial','干净柔和的米色工作室中的3x3照片',[w],'Use the fictional 32-year-old adult woman in the synthetic reference. '),('T160-alpine-storyboard','电影照片故事板',[],'The woman is a wholly fictional 28-year-old adult woman. This output is a static storyboard sheet. ')]:
 p=sel(t);orig=p;ch=['填充虚构成年人；不声称原示例人物或原模型实测。']
 if id.startswith('T156'):
  p=re.sub(r'\\([{}\[\]])',r'\1',p);ch+=['清理导出反斜杠/HTML换行；原20多岁槽填28岁，合成参考素材设定32岁，本次仅参考面部，头发按正文改长波浪。','飞吻/撅嘴选飞吻；底部未指定标题填AUTUMN IN PARIS。']
 if id.startswith('T157'):
  p=p.replace('[Character Name\\]','the fictional adult woman from the reference');ch+=['姓名槽填虚构合成人物；这是模板适配测试，不冒称真实明星还原。']
 a.append(dict(id=id,title=t,type='直接生图/参考编辑',input=prefix,refs=refs,excerpt=orig,changes=ch,cases=[dict(name='output',prompt=prefix+p)]))
(B/'batch32-input.json').write_text(json.dumps(a,ensure_ascii=False,indent=2))
