# DirectorX RH 任务恢复模块候选

独立完成原附件的任务三：一个**不依赖 UI 的 JavaScript 状态机**，附模拟服务、真实运行的故障测试及脱敏持久化样例。模块和测试只用 Node 标准库，零 npm 依赖，不安装第三方包。

**未接入 DirectorX，未修改现有画布，没有真实 RH 客户端、密钥入口或生成媒体。** 这是可执行的恢复设计候选，不是已上线功能。任务一的 ZIP 不在本包内，也未被覆盖。

## 关键行为

- 同一个 `intentKey` 的重复点击返回同一个任务；原输入固定，不重新排队。`intentKey` 是**本地一次用户意图的稳定标识**，必须跨点击、刷新复用；不是 RH 幂等键，不发送给 RH。如果接入层每次点击都生成新标识，那就是不同请求，模块不会猜测它们是同一次点击。
- 调用 submit 前先持久化 `SUBMITTING`。提交超时/断线/恢复时拿不到 taskId，进入 `SUBMISSION_UNKNOWN`，冻结自动提交。没有按本地 ID 查询 RH 的接口，也没有“超时自动重发”。
- 已有 taskId 就查询原任务；查询超时可以重查，终态/重复成功不能触发重生成或重复下载。
- 明确 421 且无 taskId：保留 `WAITING_CAPACITY` 任务及 FIFO 位置。**必须观察到在途任务的终态后**才允许再尝试；如果根本不知道正在运行的 taskId，停等人工核实，不按定时器猜空位。
- 成功与下载分开。下载失败保留原 taskId/结果来源，显式 `retryDownload()` 只下载已有结果。
- 提示词、参考顺序及 SHA256、工作流版本及 SHA256、参数在入队时深拷贝并计算快照哈希；同 intent 编辑会报错，新 intent 才新建任务，旧快照不变。
- 账本按 taskId 唯一记录。重复费用不累加，null 保持未知，已知值冲突进入对账记录；RH_COIN 与 CNY 分列，**没有跨币种总金额**。

“同请求不重提”指：明确受理或受理未知后不再调用 submit；421 是附件指定的**明确未受理**例外，可以在容量终态证据出现后发起下一次尝试。模块没有服务端 exactly-once 能力，也不能替 RH 证明账单不会重复扣款；它消除自身盲目重发和重复记账，真实费用仍需账单对账。

## 运行

要求 Node >=18.17；本次实际测试为 Node v24.19.0、Linux。Node 18、Windows、浏览器和产品运行时尚未实测。

```bash
node tools/verify.mjs
node tools/run-tests.mjs
node examples/offline-demo.mjs
```

第一个命令核对原包文件哈希。第二个执行实际故障测试，保存 `results/test-results.tap`、stderr 和结构化 summary，并返回底层失败退出码；零测试、跳过或取消均不算通过。第三个只生成 JSON 样例，不下载或生成媒体。

也可直接 `node --test test/recovery.test.mjs`。不需要 npm install、API key、GPU、RH、Hermes 或 ComfyUI。

已执行结果：19 个具体故障场景通过，失败/跳过/取消均为 0；详见 [TESTS.md](TESTS.md) 和真实日志。场景各对应一个故障及恢复断言，不以数量代替结论。

## 最小离线使用

```js
import { RecoveryQueue, MemoryStore, ledgerSummary } from './src/recovery.mjs';
import { MockService, success } from './test/mock-service.mjs';
import { spec } from './test/fixtures.mjs';

const store = new MemoryStore();
const adapter = new MockService({
  submissions: [{ taskId: 'mock-task' }],
  queries: { 'mock-task': [success('mock-result', {
    currency: 'RH_COIN', amount: null,
  })] },
});
const queue = await RecoveryQueue.open({ store, adapter });
await queue.enqueue('one-local-intent', spec());
await queue.enqueue('one-local-intent', spec()); // 同一次意图，仅保留一个任务
await queue.step(); // 持久化意图后，模拟提交一次
await queue.step(); // 按 mock-task 查询，保存结果
await queue.step(); // 模拟下载回执；不会生成媒体字节
console.log(ledgerSummary(await queue.inspect())); // 费用仍然未知
```

`step()` 每次最多执行一个提交/查询/下载效果。模块没有后台轮询或自动重试定时器；调用方决定调度节奏与退避，但不得绕过未知提交/421门。`timeoutMs` 是本地等待截止时间，**不代表请求已取消或服务未受理**。迟到回执仍会按原 attempt/taskId 消化。

## 持久化和重启

`MemoryStore` 只适合模拟；相同实例可供多个驱动共享 CAS。跨进程需要持久化存储。

```js
import { FileStore } from './src/file-store.mjs';
// 第一次部署时明确初始化一次，已有文件会 EEXIST，绝不覆盖。
const store = await FileStore.create('./state/queue.json');
// 刷新/重启时改用：
// const store = new FileStore('./state/queue.json');
// const queue = await RecoveryQueue.open({ store, adapter });
```

文件存储使用独占短锁、revision CAS、临时文件 fsync、原子 rename 和目录 fsync。初始化之后丢失/损坏文件会报错，不回退为空队列。提交前存储失败就不调用 adapter。恢复将 SUBMITTING→未知、QUERYING→查询待重试、DOWNLOADING→下载待重试；有 taskId 的不会回到 QUEUED。

文件锁竞争返回 StorageBusyError，本次操作不发送请求。若进程恰在文件 CAS 内被强杀，可能留下 `.lock` 目录；必须在确认所有旧写入者已停止后人工恢复锁，模块不自动删除或按超时抢锁。真实断电、网络文件系统与多主机锁没有验证。自定义存储也必须提供同等原子 CAS，不能替成普通 get/set。

## 操作接口

| API | 用途 |
| --- | --- |
| `RecoveryQueue.open({store, adapter})` | 校验持久化状态、转换恢复状态，不提交服务任务 |
| `enqueue(intentKey, snapshot)` | 固定一次意图及快照；相同键不同快照拒绝 |
| `step()` | 执行最多一个允许的服务效果，串行生成门受全局持久化状态控制 |
| `inspect()` | 返回深冻结的脱敏状态副本 |
| `refreshKnownTask(jobId)` | 只查询已知 taskId；完成后可补查费用，不重新下载/生成 |
| `bindKnownTaskId(jobId, taskId, evidence)` | 对未知提交人工绑定已核实 RH taskId；只保存证据哈希 |
| `trackExternalTask(taskId, evidence)` | 登记已知在途任务，等待 query 观察终态后释放421门 |
| `retryDownload(jobId)` | DOWNLOAD_RETRY→DOWNLOAD_READY；下一步只下载 |
| `cancelQueued(jobId)` | 只取消 QUEUED/明确421待排队任务，不宣称取消了远端任务 |
| `ledgerSummary(state)` | 分币种已知金额、未知 taskId 和冲突清单，无混币总和 |

未知提交没有“强制重发”或“清空当成功”接口。人工绑定的归属正确性须由操作人核实，模块只能验证格式与本地唯一性。仍找不到 taskId 时保留未知，不编造恢复成功。

## 文件

```text
src/recovery.mjs                    状态机、快照、CAS、去重账本
src/file-store.mjs                  Node 文件存储候选
test/mock-service.mjs               脚本化模拟，无网络与媒体
test/recovery.test.mjs              故障测试
examples/persisted.*.json           模拟实际产生的脱敏状态
examples/offline-demo.mjs           生成上述JSON的演练
STATE_MACHINE.md                   状态/事件/操作/字段表
ADAPTER_CONTRACT.md                 本地适配接口；不是RH真实协议声明
TESTS.md / UNVERIFIED.md            具体故障、证据与未验证边界
results/                           真实日志、退出码与演练摘要
source-materials/                  原附件相关材料和原许可证
MANIFEST.json / tools/verify.mjs    交付文件SHA256与校验
```

重跑测试/演练会更新日志和样例，因此先验原包哈希，再重跑。若要重打包，`python3 tools/package.py` 使用 Python 标准库生成独立 ZIP 和新清单；Python 只用于打包，不是模块或测试的运行依赖。

出处、附件事实与本次实现边界见 [SOURCES.md](SOURCES.md)。运行中的 provider任务/价格/模型身份/动态质量均没有在本次验证，具体见 [UNVERIFIED.md](UNVERIFIED.md)。
