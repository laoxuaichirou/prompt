# 来源与阅读范围

仅使用本会话已上传 `DirectorX-WebGPT-Review.zip`：

- 《先读我_测试指令.md》：实际读取全文，任务三和后续更新作为背景；附件Skill中的工具/本机路径/并发指令未被执行。
- `materials/canvas-scene-bindings.candidate.json`：实际读取全文并逐字节保留到 `source-materials/`，重点为serial、on421和onUncertainSubmit。文件声明candidate-not-installed；本次没有把它安装到项目。
- `LICENSE.upstream`：原文随相关来源材料一并保留，不改写第三方许可。

没有访问元数据中的G:/E:路径，没有查外部文档或RH服务，没有读取密钥/进程环境。未将附件工作流ID、节点或UI绑定写进实现，也没有伪造新的真实工作流ID。mock-workflow等字符串只用于模拟。

附件说RH NORMAL并发create可返回421无taskId；H3 ai-app/run曾返回901，工作流曾完成小样；这些是来源陈述，不是本次实测。候选内部adapter只对用户明确指定的421无ID作容量拒绝，其他无ID不明确情况保守归未知，不根据901擅自切换收费路径。

`src/`、`test/`、`tools/`、示例和文档均为本次新写候选，没有提取或改写任务一代码，也未修改现有画布。保留的原材料许可证只说明其原始材料归属，不替权利人另发许可。源码与测试的发布和采用由接收者安排。

源附件SHA256及两份保留来源材料SHA256在 `source-materials/provenance.json`；交付文件用途与SHA256在MANIFEST.json。这个交付包是独立任务三候选，不取代原任务一ZIP。
