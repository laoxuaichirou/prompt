// UI-independent, offline-tested candidate. No RH HTTP client is implemented.
import { createHash, randomUUID } from 'node:crypto';

export const STATES = Object.freeze([
  'QUEUED', 'SUBMITTING', 'SUBMISSION_UNKNOWN', 'WAITING_CAPACITY',
  'REMOTE_PENDING', 'REMOTE_RUNNING', 'QUERYING', 'QUERY_RETRY',
  'DOWNLOAD_READY', 'DOWNLOADING', 'DOWNLOAD_RETRY', 'COMPLETED',
  'REMOTE_FAILED', 'REMOTE_CANCELLED', 'LOCAL_CANCELLED',
]);
const ACTIVE = new Set(['SUBMITTING', 'SUBMISSION_UNKNOWN', 'REMOTE_PENDING', 'REMOTE_RUNNING', 'QUERYING', 'QUERY_RETRY']);
const TERMINAL = new Set(['SUCCEEDED', 'FAILED', 'CANCELLED']);
const CURRENCIES = new Set(['RH_COIN', 'CNY']);
const SECRET_KEY = /^(api[_-]?key|key|token|access[_-]?token|secret|password|authorization|cookie|credentials)$/i;
const clone = value => JSON.parse(JSON.stringify(value));
const own = (o, k) => Object.hasOwn(o, k);
const hash = x => createHash('sha256').update(typeof x === 'string' ? x : canonical(x)).digest('hex');
function ensure(ok, message) { if (!ok) throw new Error(message); }
function str(value, label) { ensure(typeof value === 'string' && value.trim().length > 0, `${label} must be nonempty string`); return value; }
function identifier(value, label) {
  str(value, label);
  ensure(/^[A-Za-z0-9._:-]{1,160}$/.test(value), `${label} must be an opaque ID, not a URL or credential`);
  ensure(!['__proto__', 'constructor', 'prototype'].includes(value), `${label}: reserved ID`);
  return value;
}
function sha(value) { ensure(typeof value === 'string' && /^[a-f0-9]{64}$/.test(value), 'expected lowercase SHA256'); return value; }
function json(value, label = 'parameters') {
  if (value === null || typeof value === 'boolean' || typeof value === 'string') return value;
  if (typeof value === 'number') { ensure(Number.isFinite(value), `${label}: non-finite number`); return value; }
  if (Array.isArray(value)) return value.map((v, i) => json(v, `${label}[${i}]`));
  ensure(value && Object.getPrototypeOf(value) === Object.prototype, `${label}: JSON object required`);
  const out = {};
  for (const key of Object.keys(value).sort()) {
    ensure(!SECRET_KEY.test(key), `credential field forbidden: ${label}.${key}`);
    ensure(!['__proto__', 'constructor', 'prototype'].includes(key), 'unsafe property');
    out[key] = json(value[key], `${label}.${key}`);
  }
  return out;
}
export function canonical(value) {
  if (Array.isArray(value)) return `[${value.map(canonical).join(',')}]`;
  if (value && typeof value === 'object') return `{${Object.keys(value).sort().map(k => `${JSON.stringify(k)}:${canonical(value[k])}`).join(',')}}`;
  return JSON.stringify(value);
}
export function snapshotOf(input) {
  ensure(input && Object.getPrototypeOf(input) === Object.prototype, 'snapshot object required');
  const allowed = new Set(['prompt', 'referenceImages', 'workflow', 'parameters']);
  ensure(Object.keys(input).every(k => allowed.has(k)), 'unknown snapshot field');
  const prompt = str(input.prompt, 'prompt');
  ensure(Array.isArray(input.referenceImages), 'ordered referenceImages array required');
  const referenceImages = input.referenceImages.map(r => {
    ensure(r && Object.keys(r).every(k => ['assetId', 'sha256'].includes(k)), 'reference only accepts assetId/sha256');
    return { assetId: identifier(r.assetId, 'reference assetId'), sha256: sha(r.sha256) };
  });
  const w = input.workflow;
  ensure(w && Object.keys(w).every(k => ['id', 'version', 'sha256'].includes(k)), 'workflow id/version/sha256 required');
  return { prompt, referenceImages, workflow: { id: identifier(w.id, 'workflow id'), version: str(w.version, 'workflow version'), sha256: sha(w.sha256) }, parameters: json(input.parameters ?? {}) };
}
function frozen(value) {
  if (value && typeof value === 'object') { Object.values(value).forEach(frozen); Object.freeze(value); }
  return value;
}

export function emptyState() { return { schema: 1, revision: 0, terminalEpoch: 0, jobs: [], externalTasks: [], ledger: {}, events: [], nextEvent: 1 }; }
function event(s, type, jobId, details = {}) {
  // Never persist raw service replies or exception messages (may contain keys/URLs).
  s.events.push({ sequence: s.nextEvent++, observedAt: new Date().toISOString(), type, jobId, ...details });
}
function amount(value) {
  if (value === null) return null;
  ensure(typeof value === 'string' && /^(0|[1-9]\d*)(\.\d{1,8})?$/.test(value), 'charge amount must be nonnegative decimal string or null');
  const [whole, fraction = ''] = value.split('.');
  const f = fraction.replace(/0+$/, ''); return whole + (f ? `.${f}` : '');
}
function chargeOf(charge) {
  if (charge === undefined || charge === null) return { amount: null, currency: null };
  ensure(charge && Object.keys(charge).every(k => ['amount', 'currency'].includes(k)), 'invalid charge fields');
  ensure(CURRENCIES.has(charge.currency), 'unsupported currency');
  return { amount: amount(charge.amount), currency: charge.currency };
}
function recordCharge(s, taskId, raw) {
  if (!own(s.ledger, taskId)) s.ledger[taskId] = { taskId, amount: null, currency: null, conflicts: [] };
  if (raw === undefined) return;
  const entry = s.ledger[taskId];
  let c;
  try { c = chargeOf(raw); }
  catch { event(s, 'INVALID_CHARGE_IGNORED', null, { taskId }); return; }
  // Unknown is never silently zeroed, and known values are never added twice.
  if (c.currency === null) return;
  if (entry.currency !== null && entry.currency !== c.currency || entry.amount !== null && c.amount !== null && entry.amount !== c.amount) {
    const conflict = { amount: c.amount, currency: c.currency };
    if (!entry.conflicts.some(x => canonical(x) === canonical(conflict))) entry.conflicts.push(conflict);
    event(s, 'CHARGE_CONFLICT', null, { taskId }); return;
  }
  entry.currency = c.currency;
  if (entry.amount === null && c.amount !== null) entry.amount = c.amount;
}
function artifactsOf(raw) {
  ensure(Array.isArray(raw) && raw.length > 0, 'success needs result artifact references');
  const seen = new Set();
  return raw.map(a => {
    ensure(a && Object.keys(a).every(k => ['artifactId', 'sha256', 'mediaType'].includes(k)), 'artifact fields not allowed');
    const artifactId = identifier(a.artifactId, 'artifactId');
    ensure(!seen.has(artifactId), 'duplicate artifact ID'); seen.add(artifactId);
    return { artifactId, sha256: sha(a.sha256), mediaType: str(a.mediaType, 'mediaType') };
  });
}
function find(s, id) { const j = s.jobs.find(x => x.id === id); ensure(j, 'job not found'); return j; }
function busy(s) { return s.jobs.some(j => ACTIVE.has(j.state)); }
function externalBusy(s) { return s.externalTasks.some(t => !TERMINAL.has(t.remoteStatus)); }
function taskTaken(s, taskId, except) {
  return s.jobs.some(j => j.id !== except && j.taskId === taskId) || s.externalTasks.some(t => t.taskId === taskId);
}

export function validateState(s) {
  ensure(s && s.schema === 1 && Number.isInteger(s.revision) && s.revision >= 0, 'invalid persistence version/revision');
  ensure(Array.isArray(s.jobs) && Array.isArray(s.externalTasks) && s.ledger && Array.isArray(s.events), 'invalid persistence structure');
  ensure(Number.isInteger(s.terminalEpoch) && s.terminalEpoch >= 0, 'invalid terminalEpoch');
  const ids = new Set(), intents = new Set(), taskIds = new Set();
  for (const j of s.jobs) {
    identifier(j.id, 'job id'); identifier(j.intentKey, 'intentKey');
    ensure(!ids.has(j.id) && !intents.has(j.intentKey), 'duplicate job/intent'); ids.add(j.id); intents.add(j.intentKey);
    ensure(STATES.includes(j.state), 'unknown persisted job state');
    const snapshot = snapshotOf(j.snapshot);
    ensure(hash(snapshot) === j.snapshotHash && canonical(snapshot) === canonical(j.snapshot), 'snapshot hash/schema mismatch');
    if (j.taskId !== null) { identifier(j.taskId, 'taskId'); ensure(!taskIds.has(j.taskId), 'duplicate persisted taskId'); taskIds.add(j.taskId); }
    if (['SUBMITTING', 'SUBMISSION_UNKNOWN', 'WAITING_CAPACITY', 'QUEUED', 'LOCAL_CANCELLED'].includes(j.state)) ensure(j.taskId === null, 'pre-ack state must not have taskId');
    else ensure(j.taskId !== null, 'acknowledged state needs taskId');
    ensure(Number.isInteger(j.submitAttempts) && j.submitAttempts >= 0, 'invalid submitAttempts');
    if (j.result !== null) {
      ensure(j.result.taskId === j.taskId && j.result.snapshotHash === j.snapshotHash, 'result provenance mismatch');
      artifactsOf(j.result.artifacts);
    }
  }
  for (const t of s.externalTasks) {
    identifier(t.taskId, 'external taskId'); ensure(!taskIds.has(t.taskId), 'duplicate external taskId'); taskIds.add(t.taskId);
    ensure(['PENDING', 'RUNNING', 'SUCCEEDED', 'FAILED', 'CANCELLED'].includes(t.remoteStatus), 'invalid external state');
  }
  for (const [id, entry] of Object.entries(s.ledger)) {
    ensure(id === entry.taskId && taskIds.has(id), 'ledger not bound to a known taskId');
    ensure(entry.currency === null || CURRENCIES.has(entry.currency), 'invalid ledger currency');
    ensure(amount(entry.amount) === entry.amount, 'invalid ledger amount');
    ensure(entry.amount === null || entry.currency !== null, 'known amount must have currency');
  }
  return s;
}

export class MemoryStore {
  #state;
  constructor(state = emptyState()) { this.#state = clone(state); }
  async read() { return clone(this.#state); }
  async compareAndSwap(revision, state) {
    if (this.#state.revision !== revision) return false;
    const next = clone(state); next.revision = revision + 1; validateState(next); this.#state = next; return true;
  }
}
export class TimeoutError extends Error { constructor() { super('operation deadline elapsed'); this.name = 'TimeoutError'; } }
export async function deadline(promise, milliseconds) {
  let timer;
  try { return await Promise.race([promise, new Promise((_, reject) => { timer = setTimeout(() => reject(new TimeoutError()), milliseconds); })]); }
  finally { clearTimeout(timer); }
}

export class RecoveryQueue {
  #store; #adapter; #deadline; #timeout; #tail = Promise.resolve(); #newId; #now;
  constructor({ store, adapter, withDeadline = deadline, timeoutMs = 30_000, newId = randomUUID, now = () => new Date().toISOString() }) {
    ensure(store?.read && store?.compareAndSwap, 'CAS store required');
    ensure(adapter?.submit && adapter?.query && adapter?.download, 'adapter submit/query/download required');
    ensure(Number.isFinite(timeoutMs) && timeoutMs > 0, 'positive timeout required');
    this.#store = store; this.#adapter = adapter; this.#deadline = withDeadline; this.#timeout = timeoutMs; this.#newId = newId; this.#now = now;
  }
  static async open(options) {
    const q = new RecoveryQueue(options);
    await q.#edit(s => {
      for (const j of s.jobs) {
        if (j.state === 'SUBMITTING') { j.state = 'SUBMISSION_UNKNOWN'; event(s, 'RESTORED_UNACKNOWLEDGED_SUBMIT', j.id); }
        if (j.state === 'QUERYING') { j.state = 'QUERY_RETRY'; event(s, 'RESTORED_QUERY', j.id); }
        if (j.state === 'DOWNLOADING') { j.state = 'DOWNLOAD_RETRY'; event(s, 'RESTORED_DOWNLOAD', j.id); }
      }
    });
    return q;
  }
  async #edit(mutate) {
    for (let attempt = 0; attempt < 50; attempt++) {
      const s = validateState(await this.#store.read());
      const result = mutate(s);
      validateState(s);
      if (await this.#store.compareAndSwap(s.revision, s)) return clone(result ?? null);
    }
    throw new Error('storage contention; no side effect was authorized');
  }
  async inspect() { return frozen(clone(validateState(await this.#store.read()))); }
  async enqueue(intentKey, input) {
    identifier(intentKey, 'intentKey'); const snapshot = snapshotOf(input), snapshotHash = hash(snapshot);
    // IDs and timestamp are captured once, not re-created during CAS retries.
    const id = `job:${this.#newId()}`, createdAt = this.#now();
    return this.#edit(s => {
      const existing = s.jobs.find(j => j.intentKey === intentKey);
      if (existing) { ensure(existing.snapshotHash === snapshotHash, 'intent conflict: edited input needs a NEW intentKey'); return existing; }
      const j = { id, intentKey, snapshot, snapshotHash, createdAt, state: 'QUEUED', taskId: null,
        attemptId: null, submitAttempts: 0, pollAttempts: 0, downloadAttempts: 0, lastRemoteStatus: null,
        waitAfterEpoch: null, result: null, downloadReceipt: null, issues: [] };
      s.jobs.push(j); event(s, 'ENQUEUED', id, { snapshotHash }); return j;
    });
  }
  async cancelQueued(id) {
    return this.#edit(s => { const j = find(s, id); ensure(['QUEUED', 'WAITING_CAPACITY'].includes(j.state), 'only never-accepted queued jobs can be cancelled'); j.state = 'LOCAL_CANCELLED'; event(s, 'CANCELLED_BEFORE_ACCEPTANCE', id); return j; });
  }
  async bindKnownTaskId(id, taskId, evidence) {
    identifier(taskId, 'taskId'); str(evidence, 'manual evidence');
    return this.#edit(s => {
      const j = find(s, id); ensure(j.state === 'SUBMISSION_UNKNOWN', 'manual bind only for unknown submission');
      ensure(!taskTaken(s, taskId, id), 'taskId already tracked');
      j.taskId = taskId; j.state = 'REMOTE_PENDING'; recordCharge(s, taskId);
      event(s, 'MANUAL_TASK_ID_BOUND', id, { taskId, evidenceHash: hash(evidence) }); return j;
    });
  }
  async trackExternalTask(taskId, evidence) {
    identifier(taskId, 'taskId'); str(evidence, 'external evidence');
    return this.#edit(s => {
      ensure(!s.jobs.some(j => j.taskId === taskId), 'taskId already belongs to a job');
      if (!s.externalTasks.some(t => t.taskId === taskId)) {
        s.externalTasks.push({ taskId, remoteStatus: 'RUNNING', evidenceHash: hash(evidence), queryAttempts: 0 });
        recordCharge(s, taskId); event(s, 'EXTERNAL_TASK_TRACKED', null, { taskId });
      }
    });
  }
  async retryDownload(id) {
    return this.#edit(s => { const j = find(s, id); ensure(j.state === 'DOWNLOAD_RETRY', 'download not awaiting manual retry'); j.state = 'DOWNLOAD_READY'; event(s, 'DOWNLOAD_RETRY_REQUESTED', id); });
  }
  async #submissionReply(id, attemptId, reply) {
    return this.#edit(s => {
      const j = find(s, id);
      if (j.attemptId !== attemptId || !['SUBMITTING', 'SUBMISSION_UNKNOWN'].includes(j.state)) return;
      if (typeof reply?.taskId === 'string' && reply.taskId.trim()) {
        try { identifier(reply.taskId, 'taskId'); ensure(!taskTaken(s, reply.taskId, id), 'duplicate taskId'); }
        catch { j.state = 'SUBMISSION_UNKNOWN'; event(s, 'INVALID_OR_DUPLICATE_TASK_ID', id); return; }
        j.taskId = reply.taskId; j.state = 'REMOTE_PENDING'; recordCharge(s, j.taskId, reply.charge);
        event(s, 'SUBMIT_ACKNOWLEDGED', id, { taskId: j.taskId });
      } else if (reply?.code === 421 && (reply.taskId === null || reply.taskId === undefined)) {
        j.state = 'WAITING_CAPACITY'; j.waitAfterEpoch = s.terminalEpoch;
        event(s, 'EXPLICIT_421_NO_TASK_ID', id, { afterEpoch: s.terminalEpoch });
      } else { j.state = 'SUBMISSION_UNKNOWN'; event(s, 'SUBMIT_REPLY_WITHOUT_USABLE_ID', id); }
    });
  }
  async #unknownSubmission(id, attemptId) {
    await this.#edit(s => { const j = find(s, id); if (j.state === 'SUBMITTING' && j.attemptId === attemptId) { j.state = 'SUBMISSION_UNKNOWN'; event(s, 'SUBMIT_OUTCOME_UNKNOWN', id); } });
  }
  async #queryReply(id, taskId, reply, external = false) {
    return this.#edit(s => {
      const j = external ? s.externalTasks.find(t => t.taskId === taskId) : find(s, id);
      if (!j || j.taskId !== taskId) return;
      let status = reply?.status;
      if (!['PENDING', 'RUNNING', 'SUCCEEDED', 'FAILED', 'CANCELLED'].includes(status)) {
        if (!external && !TERMINAL.has(j.lastRemoteStatus)) j.state = 'QUERY_RETRY';
        event(s, 'UNRECOGNIZED_QUERY_REPLY', id, { taskId }); return;
      }
      recordCharge(s, taskId, reply.charge);
      const previous = external ? j.remoteStatus : j.lastRemoteStatus;
      if (TERMINAL.has(previous)) {
        // A duplicate or stale poll can update an unknown charge, not regress or download again.
        if (TERMINAL.has(status) && previous !== status) event(s, 'CONFLICTING_TERMINAL_REPLY_IGNORED', id, { taskId });
        if (!external && status === 'SUCCEEDED' && j.result) {
          try { if (canonical(artifactsOf(reply.artifacts)) !== canonical(j.result.artifacts)) event(s, 'CONFLICTING_RESULT_IGNORED', id, { taskId }); }
          catch { event(s, 'INVALID_DUPLICATE_RESULT_IGNORED', id, { taskId }); }
        }
        return;
      }
      if (status === 'PENDING' && previous === 'RUNNING') status = 'RUNNING';
      // Success without safe artifact IDs is not treated as failure or resubmitted.
      let artifacts;
      if (!external && status === 'SUCCEEDED') {
        try { artifacts = artifactsOf(reply.artifacts); }
        catch { j.state = 'QUERY_RETRY'; event(s, 'SUCCESS_WITH_UNUSABLE_RESULTS', id, { taskId }); return; }
      }
      if (TERMINAL.has(status)) s.terminalEpoch++;
      if (external) { j.remoteStatus = status; event(s, 'EXTERNAL_QUERY_OBSERVED', null, { taskId, status }); return; }
      j.lastRemoteStatus = status;
      if (status === 'SUCCEEDED') {
        j.result = { taskId, snapshotHash: j.snapshotHash, artifacts, receivedAt: this.#now() };
        j.state = 'DOWNLOAD_READY';
      } else if (status === 'FAILED') j.state = 'REMOTE_FAILED';
      else if (status === 'CANCELLED') j.state = 'REMOTE_CANCELLED';
      else j.state = status === 'RUNNING' ? 'REMOTE_RUNNING' : 'REMOTE_PENDING';
      event(s, 'REMOTE_STATUS_OBSERVED', id, { taskId, status });
    });
  }
  async #query(id, taskId, external = false) {
    // Query is a safe read; a late success is consumed even after a deadline.
    const request = Promise.resolve().then(() => this.#adapter.query(taskId));
    const applied = request.then(reply => this.#queryReply(id, taskId, reply, external));
    try { await this.#deadline(applied, this.#timeout, 'query'); }
    catch {
      await this.#edit(s => {
        const j = external ? null : find(s, id);
        if (j && j.taskId === taskId && !TERMINAL.has(j.lastRemoteStatus)) j.state = 'QUERY_RETRY';
        event(s, 'QUERY_TEMPORARILY_UNAVAILABLE', id, { taskId });
      });
    }
  }
  async refreshKnownTask(id) {
    const s = await this.inspect(), j = find(s, id); ensure(j.taskId, 'cannot query without known taskId');
    await this.#query(id, j.taskId); return this.inspect();
  }
  async #download(id, taskId, result, downloadAttempt) {
    // Adapter download must address existing artifacts; never generates new media.
    const applied = Promise.resolve().then(() => this.#adapter.download(frozen(clone(result)))).then(receipt => this.#edit(s => {
      const j = find(s, id);
      if (j.taskId !== taskId || j.downloadAttempts !== downloadAttempt || !['DOWNLOADING', 'DOWNLOAD_RETRY'].includes(j.state)) return;
      ensure(receipt && Array.isArray(receipt.files), 'download receipt missing files');
      ensure(receipt.files.length === result.artifacts.length, 'download receipt incomplete');
      const files = receipt.files.map((file, i) => {
        const artifact = result.artifacts[i];
        ensure(file.artifactId === artifact.artifactId && file.sha256 === artifact.sha256, 'download hash/ordered artifact mismatch');
        const storageKey = str(file.storageKey, 'storageKey');
        ensure(/^[A-Za-z0-9_./-]+$/.test(storageKey) && !storageKey.startsWith('/') && !storageKey.split('/').includes('..'), 'storageKey must be a safe relative logical key');
        return { artifactId: file.artifactId, sha256: file.sha256, storageKey };
      });
      j.downloadReceipt = { files }; j.state = 'COMPLETED'; event(s, 'DOWNLOAD_COMPLETED', id, { taskId });
    }));
    try { await this.#deadline(applied, this.#timeout, 'download'); }
    catch {
      await this.#edit(s => { const j = find(s, id); if (j.state === 'DOWNLOADING' && j.downloadAttempts === downloadAttempt) j.state = 'DOWNLOAD_RETRY'; event(s, 'DOWNLOAD_TEMPORARILY_UNAVAILABLE', id, { taskId }); });
    }
  }
  step() {
    const run = this.#tail.then(() => this.#step());
    this.#tail = run.catch(() => {}); return run;
  }
  async #step() {
    const attemptId = `attempt:${this.#newId()}`;
    const effect = await this.#edit(s => {
      // A known remote job must be queried until terminal. A missing ID freezes submission.
      const active = s.jobs.find(j => ['REMOTE_PENDING', 'REMOTE_RUNNING', 'QUERY_RETRY'].includes(j.state));
      if (active) { active.state = 'QUERYING'; active.pollAttempts++; event(s, 'QUERY_STARTED', active.id, { taskId: active.taskId }); return { type: 'query', id: active.id, taskId: active.taskId }; }
      const ext = s.externalTasks.find(t => !TERMINAL.has(t.remoteStatus));
      if (ext) { ext.queryAttempts++; return { type: 'queryExternal', taskId: ext.taskId }; }
      const download = s.jobs.find(j => j.state === 'DOWNLOAD_READY');
      if (download) { download.state = 'DOWNLOADING'; download.downloadAttempts++; event(s, 'DOWNLOAD_STARTED', download.id, { taskId: download.taskId }); return { type: 'download', id: download.id, taskId: download.taskId, result: download.result, downloadAttempt: download.downloadAttempts }; }
      if (busy(s) || externalBusy(s)) return null;
      const head = s.jobs.find(j => ['QUEUED', 'WAITING_CAPACITY'].includes(j.state));
      if (!head) return null;
      if (head.state === 'WAITING_CAPACITY') {
        if (!(s.terminalEpoch > head.waitAfterEpoch)) return null;
        event(s, 'CAPACITY_TERMINAL_EVIDENCE', head.id, { epoch: s.terminalEpoch });
      }
      head.state = 'SUBMITTING'; head.attemptId = attemptId; head.submitAttempts++;
      event(s, 'SUBMIT_INTENT_DURABLE', head.id, { attemptId, snapshotHash: head.snapshotHash });
      return { type: 'submit', id: head.id, attemptId, snapshot: head.snapshot };
    });
    // No provider operation happens before the CAS commit succeeds.
    if (!effect) return this.inspect();
    if (effect.type === 'submit') {
      const applied = Promise.resolve().then(() => this.#adapter.submit(frozen(clone(effect.snapshot)))).then(reply => this.#submissionReply(effect.id, effect.attemptId, reply));
      try { await this.#deadline(applied, this.#timeout, 'submit'); }
      catch { await this.#unknownSubmission(effect.id, effect.attemptId); }
    } else if (effect.type === 'query' || effect.type === 'queryExternal') {
      await this.#query(effect.id ?? null, effect.taskId, effect.type === 'queryExternal');
    } else await this.#download(effect.id, effect.taskId, effect.result, effect.downloadAttempt);
    return this.inspect();
  }
}

function addDecimal(a, b) {
  const [aw, af = ''] = a.split('.'), [bw, bf = ''] = b.split('.'); const digits = Math.max(af.length, bf.length);
  const sum = BigInt(aw + af.padEnd(digits, '0')) + BigInt(bw + bf.padEnd(digits, '0'));
  const raw = sum.toString().padStart(digits + 1, '0');
  return amount(digits ? raw.slice(0, -digits) + '.' + raw.slice(-digits) : raw);
}
export function ledgerSummary(s) {
  validateState(s);
  const totals = Object.fromEntries([...CURRENCIES].map(c => [c, { knownAmount: '0', unknownTaskIds: [], conflictTaskIds: [] }]));
  const unclassifiedTaskIds = [];
  for (const e of Object.values(s.ledger)) {
    if (e.currency === null) { unclassifiedTaskIds.push(e.taskId); continue; }
    if (e.amount === null) totals[e.currency].unknownTaskIds.push(e.taskId);
    else totals[e.currency].knownAmount = addDecimal(totals[e.currency].knownAmount, e.amount);
    if (e.conflicts.length) totals[e.currency].conflictTaskIds.push(e.taskId);
  }
  return { totals, unclassifiedTaskIds, isFullyReconciled: unclassifiedTaskIds.length === 0 && Object.values(totals).every(x => !x.unknownTaskIds.length && !x.conflictTaskIds.length) };
}
