// Node filesystem persistence. The compare-and-swap contract is part of safety.
import { mkdir, readFile, open, rename, unlink, rmdir } from 'node:fs/promises';
import { dirname, resolve } from 'node:path';
import { randomUUID } from 'node:crypto';
import { emptyState, validateState } from './recovery.mjs';

export class StorageBusyError extends Error {
  constructor() { super('store lock exists; do not remove unless all old writers are stopped'); this.name = 'StorageBusyError'; }
}
export class FileStore {
  constructor(path) { this.path = resolve(path); this.lockPath = `${this.path}.lock`; }
  static async create(path) {
    const store = new FileStore(path), dir = dirname(store.path);
    await mkdir(dir, { recursive: true });
    // Explicit one-time initialization; refusing EEXIST protects existing work.
    const file = await open(store.path, 'wx', 0o600);
    try { await file.writeFile(JSON.stringify(emptyState(), null, 2) + '\n'); await file.sync(); }
    finally { await file.close(); }
    const directory = await open(dir, 'r');
    try { await directory.sync(); } finally { await directory.close(); }
    return store;
  }
  async read() {
    const raw = await readFile(this.path, 'utf8');
    // Malformed/corrupt state is an error, NEVER an empty/new queue.
    return validateState(JSON.parse(raw));
  }
  async compareAndSwap(revision, state) {
    const dir = dirname(this.path);
    await mkdir(dir, { recursive: true });
    try { await mkdir(this.lockPath, { mode: 0o700 }); }
    catch (e) { if (e.code === 'EEXIST') throw new StorageBusyError(); throw e; }
    const temporary = `${this.path}.${randomUUID()}.tmp`;
    let file;
    try {
      const current = await this.read();
      if (current.revision !== revision) return false;
      const next = structuredClone(state); next.revision = revision + 1; validateState(next);
      file = await open(temporary, 'wx', 0o600);
      await file.writeFile(JSON.stringify(next, null, 2) + '\n', 'utf8');
      await file.sync(); await file.close(); file = null;
      await rename(temporary, this.path);
      const directory = await open(dir, 'r');
      try { await directory.sync(); } finally { await directory.close(); }
      return true;
    } finally {
      if (file) await file.close();
      await unlink(temporary).catch(e => { if (e.code !== 'ENOENT') throw e; });
      await rmdir(this.lockPath);
    }
  }
}
