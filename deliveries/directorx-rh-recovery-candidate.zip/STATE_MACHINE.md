# 状态、事件、允许操作与持久化

状态名是候选模块的本地语义，不是 RH API 枚举。中文用于解释，JSON 持久化英文常量。只有 mock 使用下面 ADAPTER_CONTRACT 的归一化回执。

## 状态转换表

| 当前状态 | 事件/条件 | 下一状态 | 允许的服务操作 | 关键持久化变化 |
| --- | --- | --- | --- | --- |
| 无 | enqueue 新 intentKey | QUEUED | 无 | id、intentKey、完整snapshot、snapshotHash、createdAt |
| 任意已有任务 | 同 key 同 snapshot 重复 enqueue | 原状态 | 无 | 不新建、不清空旧任务 |
| 任意已有任务 | 同 key 输入编辑 | 抛 intent conflict，原状态 | 无 | 旧快照不变；必须用新 key 新建 |
| QUEUED | FIFO 到头，未有远端活跃/未知任务 | SUBMITTING | CAS提交成功后才能 submit | attemptId、submitAttempts+1、SUBMIT_INTENT_DURABLE |
| SUBMITTING | 获得有效且唯一 taskId | REMOTE_PENDING | 后续只 query(taskId) | taskId、未知费用记录、ack事件 |
| SUBMITTING | 超时、异常、无有效 taskId 的不可分类回执 | SUBMISSION_UNKNOWN | 禁止 submit；不得按本地ID query | 保留attemptId/快照；记录未知事件 |
| SUBMITTING | 重启恢复，仅有持久化意图 | SUBMISSION_UNKNOWN | 同上 | 不能区分发送前/发送后崩溃，不重放意图 |
| SUBMISSION_UNKNOWN | 同attempt的迟到有效回执 | REMOTE_PENDING | query(taskId) | 绑定原任务，不新建/重提 |
| SUBMISSION_UNKNOWN | 人工提供已核实taskId | REMOTE_PENDING | query(taskId) | taskId、evidenceHash；不保存原始证据文字 |
| SUBMITTING/未知 | 明确 code=421，taskId缺失/null | WAITING_CAPACITY | 禁止盲目重提 | FIFO位置不变，waitAfterEpoch=当前terminalEpoch |
| WAITING_CAPACITY | 未有之后的新终态证据 | 原状态 | 有已知在途ID时只查询它 | 不按timer或本地requestId猜任务 |
| WAITING_CAPACITY | 观察到后续终态，且所有本地已知远端活跃项已释放 | SUBMITTING | 下一step可重新尝试submit | 新attemptId，submitAttempts+1；只对明确未受理421允许 |
| REMOTE_PENDING/REMOTE_RUNNING/QUERY_RETRY | step | QUERYING | query原taskId | pollAttempts+1、查询事件 |
| QUERYING | PENDING/RUNNING | REMOTE_PENDING/REMOTE_RUNNING | 之后可继续query | lastRemoteStatus；RUNNING不被迟到PENDING降级 |
| QUERYING | 超时、暂时异常或未知查询状态 | QUERY_RETRY | 之后重查同taskId | taskId/快照不变，不回QUEUED |
| QUERYING | 刷新/重启 | QUERY_RETRY | 同上 | 不假定上次query失败或没发送；只读可再查 |
| query中的任何已知任务 | 首次有效SUCCEEDED及结果引用 | DOWNLOAD_READY | download已有结果 | result(taskId/snapshotHash/artifacts/时间)，terminalEpoch+1 |
| query中的任何已知任务 | 首次FAILED/CANCELLED | REMOTE_FAILED/REMOTE_CANCELLED | 无自动重生成 | 记录终态、费用未知也保留，释放生成槽 |
| DOWNLOAD_READY | step | DOWNLOADING | download结果引用 | downloadAttempts+1；不submit |
| DOWNLOADING | 完整有序回执且哈希与结果引用一致 | COMPLETED | 无自动操作 | downloadReceipt，仅相对逻辑storageKey |
| DOWNLOADING | 下载超时、错误、不完整或哈希不符 | DOWNLOAD_RETRY | 等显式重试下载 | result与taskId保留；不query生成新任务 |
| DOWNLOADING | 重启恢复 | DOWNLOAD_RETRY | 同上 | 不假定文件已完整落地 |
| DOWNLOAD_RETRY | retryDownload | DOWNLOAD_READY | 下一step只download | 原结果不变 |
| DOWNLOADING/下载待重试 | 本次下载迟到有效回执、尚未开始更新attempt | COMPLETED | 无 | 校验同downloadAttempt；旧attempt不可覆盖新回执 |
| 远端终态后各下载状态/COMPLETED/FAILED/CANCELLED | 重复或迟到query | 保持现有状态 | 可按同taskId补查询费用 | 不重复terminalEpoch、不覆盖结果、不再下载；冲突记事件 |
| QUEUED/WAITING_CAPACITY | cancelQueued | LOCAL_CANCELLED | 无 | 只取消本地未受理工作；不宣称取消远端任务 |
| 未知/已受理/下载/完成等状态 | 取消或重新生成原任务 | 拒绝/无接口 | 无 | 需要新意图时另建任务，原任务不覆盖 |

查询结果已表明成功但缺少安全可用结果引用时，保持 QUERY_RETRY，继续查同 taskId，不把这种失败当作重新生成的理由。有效 taskId 比421代码优先：421带ID时绑定并查询，避免拿着已受理ID仍重复发起生成。

## 串行队列及容量证据

按入队顺序选择 QUEUED/WAITING_CAPACITY 头部；后面的任务不能绕过421等待头。SUBMITTING、SUBMISSION_UNKNOWN、已知远端pending/running/query-retry/querying 都占据生成门。

已知的 externalTasks 也由 taskId 查询。只有**首次观察到** SUCCEEDED/FAILED/CANCELLED 才增加 terminalEpoch。421记录其发生时的epoch，后续必须看到更大epoch且没有已知远端活跃项才重试。已有的旧终态或重复成功不会反复释放421重试。只看到421、完全不知道谁在运行时，模块不能找出RH任务，因此保持等待，允许人工登记已核实ID。

DOWNLOAD_RETRY不占RH生成槽；可保留其失败下载并开始**其他独立新意图**，不会重新生成该失败下载的原任务。

## 持久化字段

| 字段 | 目的与规则 |
| --- | --- |
| schema/revision | schema=1，revision用于原子CAS；未知schema或损坏数据报错，不当空队列 |
| terminalEpoch | 已观察远端终态的单调计数，用于421门，不是服务端队列容量 |
| jobs[].id / intentKey | 本地任务与稳定用户意图；不传作RH幂等键，不拿来查询RH |
| snapshot.prompt | 原提示词全文固定；调用者不得放密钥，模块不接收凭证字段 |
| snapshot.referenceImages | 有序assetId/SHA256列表；不保存带鉴权参数URL或临时地址 |
| snapshot.workflow | id/version/SHA256；本包用mock标识，不编造真实工作流版本 |
| snapshot.parameters | JSON参数深拷贝；拒绝非有限数、非JSON值及凭证命名字段 |
| snapshotHash | 规范化JSON的SHA256，数组保持原顺序；恢复时重新校验，篡改即拒绝 |
| attemptId/submitAttempts | 原提交尝试绑定，超时后也保留；421后新尝试用新ID |
| taskId | 收到或人工核实的远端ID；本地唯一；无ID不query |
| state/lastRemoteStatus | 操作状态与已观察远端状态分开；下载失败不能丢成功事实 |
| pollAttempts/downloadAttempts | 记录step驱动的查询/下载次数；手工refreshKnownTask额外查询记录事件，不计入step轮询计数 |
| waitAfterEpoch | 等待后续终态，而不是使用未经证实的秒数退避当容量证据 |
| result | taskId、snapshotHash、稳定artifactId及结果哈希、mediaType、接收时间；不存生URL |
| downloadReceipt | 与结果逐项匹配的artifactId/hash/相对逻辑storageKey；不是生成成功证据的替代品 |
| ledger[taskId] | 每个已知taskId唯一条目：currency、amount(null或十进制字符串)、conflicts |
| events | sequence、observedAt、type、jobId、taskId/attemptId/hash等白名单信息；不保存raw response、异常消息或证据原文 |
| externalTasks | 人工已知在途taskId、remoteStatus、证据哈希；不以本地ID推断 |

事件时间为本机观察时间，不证明服务端接收或扣费时刻。示例中的MOCK taskId和哈希不对应任何真实媒体或RH任务。

## 费用与结果归属

取得taskId时即建立一条未知费用记录。重复query收费回执只补全未知值或与已知值核对，不把两次观察相加。null→已知可以补全，已知→null不会抹掉已知；不同金额或币种的冲突留档，首次已知值保留并标为未完全对账。

金额用十进制字符串和BigInt加总，避免浮点加法误差。ledgerSummary按 RH_COIN/CNY分别返回 knownAmount、unknownTaskIds、conflictTaskIds，币种都未知的ID另列unclassifiedTaskIds。knownAmount='0'仅表示当前已知部分为零；存在未知/冲突时isFullyReconciled=false，不能把这个部分和当全部费用。

结果引用绑定原taskId和snapshotHash，第一次安全成功结果固定；重复成功不会换另一套结果。下载回执还须匹配每个有序artifactId/hash；真正文件字节校验、临时URL刷新和落地事务应由将来的下载适配器实现，本次只验证回执契约。
