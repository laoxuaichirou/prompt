// Generates redacted JSON state samples ONLY, no image/audio/video bytes.
import { mkdir, writeFile } from 'node:fs/promises';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { RecoveryQueue, MemoryStore, ledgerSummary } from '../src/recovery.mjs';
import { MockService, never, timeout, success, receipt } from '../test/mock-service.mjs';
import { spec } from '../test/fixtures.mjs';
const out = resolve(process.argv[2] ?? dirname(fileURLToPath(import.meta.url)));
await mkdir(out, { recursive: true });
const save = async (name, s) => writeFile(join(out, name), JSON.stringify(s, null, 2) + '\n');
function options(store, adapter) { let n = 0; return { store, adapter, timeoutMs: 10, newId: () => `mock-${++n}`, now: () => '2026-10-22T00:00:00.000Z' }; }

const unknownService = new MockService({ submissions: [never] }), unknownStore = new MemoryStore();
const unknown = await RecoveryQueue.open(options(unknownStore, unknownService));
await unknown.enqueue('mock-intent-unknown', spec()); await unknown.step();
await save('persisted.submission-unknown.json', await unknown.inspect());

const waitingService = new MockService({ submissions: [{ code: 421, taskId: null }] }), waitingStore = new MemoryStore();
const waiting = await RecoveryQueue.open(options(waitingStore, waitingService));
await waiting.enqueue('mock-intent-capacity', spec()); await waiting.step();
await waiting.trackExternalTask('mock-existing-task', 'MOCK console evidence; no actual RH task exists');
await save('persisted.waiting-capacity.json', await waiting.inspect());

const downloadService = new MockService({ submissions: [{ taskId: 'mock-rh-result' }], queries: { 'mock-rh-result': [success('mock-output', { currency: 'RH_COIN', amount: null }), success('mock-output', { currency: 'RH_COIN', amount: '98' })] }, downloads: [timeout, receipt] });
const downloadStore = new MemoryStore(), download = await RecoveryQueue.open(options(downloadStore, downloadService));
const j = await download.enqueue('mock-intent-download', spec());
await download.step(); await download.step(); await download.step();
await save('persisted.download-retry.json', await download.inspect());
const restored = await RecoveryQueue.open({ store: downloadStore, adapter: downloadService });
await restored.retryDownload(j.id); await restored.step(); await restored.refreshKnownTask(j.id);
await save('persisted.completed.json', await restored.inspect());
await save('ledger-summary.completed.json', ledgerSummary(await restored.inspect()));
const summary = { scope: 'MOCK ONLY: samples are simulation output, not RH receipts or generated media',
  realServiceCalls: 0, mediaGenerated: false,
  unknownSubmission: { state: (await unknown.inspect()).jobs[0].state, mockSubmitCalls: unknownService.calls.submit.length },
  explicit421: { state: (await waiting.inspect()).jobs[0].state, mockSubmitCalls: waitingService.calls.submit.length },
  downloadRecovery: { state: (await restored.inspect()).jobs[0].state, mockSubmitCalls: downloadService.calls.submit.length, mockQueryCalls: downloadService.calls.query.length, mockDownloadCalls: downloadService.calls.download.length } };
await save('demo-summary.json', summary);
console.log(JSON.stringify(summary, null, 2));
