import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, rm, writeFile, readFile, mkdir } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { RecoveryQueue, MemoryStore, ledgerSummary, validateState, snapshotOf } from '../src/recovery.mjs';
import { FileStore, StorageBusyError } from '../src/file-store.mjs';
import { MockService, deferred, never, timeout, success, receipt } from './mock-service.mjs';
import { spec } from './fixtures.mjs';

const turn = () => new Promise(resolve => setImmediate(resolve));
async function setup(adapter, store = new MemoryStore(), extra = {}) {
  let n = 0;
  const queue = await RecoveryQueue.open({ store, adapter, timeoutMs: 15, newId: () => `test-${++n}`, now: () => '2026-10-22T00:00:00.000Z', ...extra });
  return { queue, store };
}
const job = async (q, id) => (await q.inspect()).jobs.find(j => j.id === id);

test('F01 duplicate clicks and competing drivers never submit the same intent twice', async () => {
  const mock = new MockService({ submissions: [{ taskId: 'rh-click' }], queries: { 'rh-click': Array(10).fill({ status: 'RUNNING' }) } });
  const { queue, store } = await setup(mock);
  const clicks = await Promise.all(Array.from({ length: 8 }, () => queue.enqueue('click-1', spec())));
  assert.equal(new Set(clicks.map(x => x.id)).size, 1);
  const other = await RecoveryQueue.open({ store, adapter: mock, timeoutMs: 15 });
  await Promise.all([queue.step(), other.step(), queue.step(), other.step()]);
  assert.equal(mock.calls.submit.length, 1);
  assert.equal((await queue.inspect()).jobs.length, 1);
  assert.equal((await job(queue, clicks[0].id)).taskId, 'rh-click');
});

test('F02 submit deadline without taskId freezes all automatic submissions across restart', async () => {
  const mock = new MockService({ submissions: [never, { taskId: 'must-not-submit' }] });
  const { queue, store } = await setup(mock);
  const a = await queue.enqueue('timeout-a', spec()); await queue.enqueue('timeout-b', spec());
  await queue.step();
  assert.equal((await job(queue, a.id)).state, 'SUBMISSION_UNKNOWN');
  const restored = await RecoveryQueue.open({ store, adapter: mock, timeoutMs: 15 });
  for (let i = 0; i < 4; i++) await restored.step();
  assert.equal(mock.calls.submit.length, 1); assert.deepEqual(mock.calls.query, []);
  await assert.rejects(() => restored.refreshKnownTask(a.id), /known taskId/);
  await assert.rejects(() => restored.cancelQueued(a.id), /only never-accepted/);
  assert.equal((await job(restored, a.id)).submitAttempts, 1);
});

test('F03 late acknowledgement or explicit manual taskId reconciliation recovers the original request only', async () => {
  const pending = deferred();
  const mock = new MockService({ submissions: [() => pending.promise], queries: { 'rh-late': [success('late')] } });
  const { queue } = await setup(mock); const a = await queue.enqueue('late-ack', spec());
  await queue.step(); assert.equal((await job(queue, a.id)).state, 'SUBMISSION_UNKNOWN');
  pending.resolve({ taskId: 'rh-late' }); await turn();
  assert.equal((await job(queue, a.id)).taskId, 'rh-late');
  await queue.step(); await queue.step();
  assert.equal((await job(queue, a.id)).state, 'COMPLETED'); assert.equal(mock.calls.submit.length, 1);

  const manualMock = new MockService({ submissions: [never], queries: { 'rh-manual': [{ status: 'RUNNING' }] } });
  const m = await setup(manualMock); const b = await m.queue.enqueue('manual', spec()); await m.queue.step();
  await m.queue.bindKnownTaskId(b.id, 'rh-manual', 'MOCK operator matched a provider console receipt');
  await m.queue.step(); assert.deepEqual(manualMock.calls.query, ['rh-manual']); assert.equal(manualMock.calls.submit.length, 1);
  assert.ok(!(JSON.stringify(await m.queue.inspect())).includes('operator matched'));
});

test('F04 process loss after durable submit-intent, before HTTP, fails closed rather than replaying the intent', async () => {
  const mock = new MockService(); const memory = new MemoryStore(); let loseProcess = false;
  const store = { read: () => memory.read(), compareAndSwap: async (v, s) => {
    const saved = await memory.compareAndSwap(v, s);
    if (saved && loseProcess && s.jobs.some(j => j.state === 'SUBMITTING')) throw new Error('SIMULATED_PROCESS_LOSS_AFTER_COMMIT');
    return saved;
  } };
  const { queue } = await setup(mock, store); const a = await queue.enqueue('crash-window', spec()); loseProcess = true;
  await assert.rejects(() => queue.step(), /SIMULATED_PROCESS_LOSS_AFTER_COMMIT/);
  assert.equal(mock.calls.submit.length, 0);
  const durable = await memory.read(); assert.equal(durable.jobs[0].state, 'SUBMITTING');
  // Fault-injected process boundary, not an actual OS kill. Intent is on disk
  // but its caller never returned; the new process cannot replay it safely.
  const afterCrash = new MemoryStore(durable), freshMock = new MockService();
  const resumed = await RecoveryQueue.open({ store: afterCrash, adapter: freshMock });
  await resumed.step(); assert.equal((await job(resumed, a.id)).state, 'SUBMISSION_UNKNOWN');
  assert.equal(freshMock.calls.submit.length, 0);
});

test('F05 acknowledged task survives real filesystem reload and queries the same taskId', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'rh-restart-'));
  try {
    const path = join(dir, 'state.json');
    const first = new MockService({ submissions: [{ taskId: 'rh-persist' }] });
    const a = await setup(first, await FileStore.create(path)); const j = await a.queue.enqueue('persist', spec()); await a.queue.step();
    await assert.rejects(() => FileStore.create(path), { code: 'EEXIST' });
    const fresh = new MockService({ queries: { 'rh-persist': [success('persisted', { currency: 'RH_COIN', amount: '98' })] } });
    const q = await RecoveryQueue.open({ store: new FileStore(path), adapter: fresh });
    await q.step(); await q.step();
    assert.equal((await job(q, j.id)).state, 'COMPLETED'); assert.deepEqual(fresh.calls.query, ['rh-persist']);
    assert.equal(fresh.calls.submit.length, 0); assert.equal(JSON.parse(await readFile(path)).ledger['rh-persist'].amount, '98');
  } finally { await rm(dir, { recursive: true, force: true }); }
});

test('F06 explicit 421 retains FIFO work; no taskId means no blind retry; retry only after observed terminal evidence', async () => {
  const mock = new MockService({ submissions: [{ code: 421, taskId: null }, { taskId: 'rh-after-capacity' }], queries: { 'rh-external': [{ status: 'RUNNING' }, { status: 'FAILED' }] } });
  const { queue } = await setup(mock); const a = await queue.enqueue('capacity-a', spec()); await queue.enqueue('capacity-b', spec());
  await queue.step(); assert.equal((await job(queue, a.id)).state, 'WAITING_CAPACITY');
  await queue.enqueue('capacity-a', spec()); for (let i = 0; i < 3; i++) await queue.step();
  assert.equal(mock.calls.submit.length, 1); // No ID to query yet: remain waiting.
  await queue.trackExternalTask('rh-external', 'MOCK existing running task ID from operator');
  await queue.step(); assert.equal(mock.calls.submit.length, 1);
  await queue.step(); assert.equal(mock.calls.submit.length, 1); // Terminal observed, no same-tick submit.
  await queue.step(); assert.equal(mock.calls.submit.length, 2);
  assert.equal((await job(queue, a.id)).taskId, 'rh-after-capacity');
  assert.equal((await queue.inspect()).jobs[1].state, 'QUEUED');
});

test('F07 a reply that includes a usable taskId is reconciled even when its code is 421', async () => {
  const mock = new MockService({ submissions: [{ code: 421, taskId: 'rh-id-wins' }], queries: { 'rh-id-wins': [{ status: 'RUNNING' }] } });
  const { queue } = await setup(mock); const a = await queue.enqueue('id-wins', spec());
  await queue.step(); await queue.step();
  assert.equal((await job(queue, a.id)).state, 'REMOTE_RUNNING'); assert.equal(mock.calls.submit.length, 1);
});

test('F08 query timeout is retryable read, retains taskId and never resubmits', async () => {
  const mock = new MockService({ submissions: [{ taskId: 'rh-poll' }], queries: { 'rh-poll': [timeout, success('poll')] } });
  const { queue } = await setup(mock); const a = await queue.enqueue('poll', spec());
  await queue.step(); await queue.step(); assert.equal((await job(queue, a.id)).state, 'QUERY_RETRY');
  await queue.step(); await queue.step();
  assert.deepEqual(mock.calls.query, ['rh-poll', 'rh-poll']); assert.equal(mock.calls.submit.length, 1);
  assert.equal((await job(queue, a.id)).state, 'COMPLETED');
});

test('F09 duplicate/stale success cannot double-record fees, overwrite provenance, regress completion or redownload', async () => {
  const good = success('stable', { currency: 'RH_COIN', amount: '26.00' });
  const mock = new MockService({ submissions: [{ taskId: 'rh-duplicate' }], queries: { 'rh-duplicate': [good, good, { status: 'RUNNING' }, success('wrong-result', { currency: 'RH_COIN', amount: '26' })] } });
  const { queue } = await setup(mock); const a = await queue.enqueue('duplicate', spec()); await queue.step(); await queue.step(); await queue.step();
  await queue.refreshKnownTask(a.id); await queue.refreshKnownTask(a.id); await queue.refreshKnownTask(a.id);
  const s = await queue.inspect(), j = s.jobs[0];
  assert.equal(j.state, 'COMPLETED'); assert.equal(j.result.artifacts[0].artifactId, 'stable');
  assert.equal(mock.calls.download.length, 1); assert.equal(mock.calls.submit.length, 1);
  assert.equal(Object.keys(s.ledger).length, 1); assert.equal(ledgerSummary(s).totals.RH_COIN.knownAmount, '26');
  assert.ok(s.events.some(e => e.type === 'CONFLICTING_RESULT_IGNORED'));
});

test('F10 generation success with failed download retries artifacts only, including after restart', async () => {
  const mock = new MockService({ submissions: [{ taskId: 'rh-download' }], queries: { 'rh-download': [success('download')] }, downloads: [timeout, receipt] });
  const { queue, store } = await setup(mock); const a = await queue.enqueue('download', spec());
  await queue.step(); await queue.step(); await queue.step();
  const before = await job(queue, a.id); assert.equal(before.state, 'DOWNLOAD_RETRY');
  const q = await RecoveryQueue.open({ store, adapter: mock }); await q.step();
  assert.equal(mock.calls.download.length, 1); // Explicit retry, not an automatic regeneration/download loop.
  await q.retryDownload(a.id); await q.step();
  const after = await job(q, a.id);
  assert.equal(after.state, 'COMPLETED'); assert.deepEqual(after.result, before.result);
  assert.equal(mock.calls.submit.length, 1); assert.equal(mock.calls.query.length, 1); assert.equal(mock.calls.download.length, 2);
});

test('F11 refreshed in-flight query/download states resume their own safe operation, never submit', async () => {
  const mock = new MockService({ submissions: [{ taskId: 'rh-mid-query' }], queries: { 'rh-mid-query': [never] } });
  const a = await setup(mock); const j = await a.queue.enqueue('mid-query', spec()); await a.queue.step();
  const inQuery = a.queue.step(); await turn(); const queryState = await a.store.read(); assert.equal(queryState.jobs[0].state, 'QUERYING');
  const service = new MockService({ queries: { 'rh-mid-query': [success('mid-query')] }, downloads: [never] });
  const b = await setup(service, new MemoryStore(queryState)); await b.queue.step();
  const inDownload = b.queue.step(); await turn(); const downloadState = await b.store.read(); assert.equal(downloadState.jobs[0].state, 'DOWNLOADING');
  const third = new MockService(); const c = await setup(third, new MemoryStore(downloadState));
  assert.equal((await job(c.queue, j.id)).state, 'DOWNLOAD_RETRY'); await c.queue.retryDownload(j.id); await c.queue.step();
  assert.equal((await job(c.queue, j.id)).state, 'COMPLETED'); assert.equal(third.calls.submit.length, 0); assert.equal(third.calls.query.length, 0);
  await inQuery; await inDownload;
});

test('F12 edits, reordered references, changed hashes or workflow versions create new immutable tasks', async () => {
  const mock = new MockService({ submissions: [{ taskId: 'rh-snapshot' }] }); const { queue } = await setup(mock);
  const input = spec(), first = await queue.enqueue('original-intent', input);
  input.prompt = 'changed outside'; input.referenceImages.reverse(); input.referenceImages[0].sha256 = 'f'.repeat(64); input.workflow.version = 'mutated';
  const reordered = [...spec().referenceImages].reverse(); reordered[0].sha256 = 'f'.repeat(64);
  const edited = spec({ prompt: 'new prompt', referenceImages: reordered, workflow: { ...spec().workflow, version: 'mock-v2', sha256: 'e'.repeat(64) } });
  await assert.rejects(() => queue.enqueue('original-intent', edited), /NEW intentKey/);
  const second = await queue.enqueue('edited-intent', edited); await queue.step();
  assert.notEqual(first.snapshotHash, second.snapshotHash);
  assert.deepEqual(mock.calls.submit[0], spec());
  const s = await queue.inspect(); assert.equal(s.jobs.length, 2); assert.deepEqual(s.jobs[0].snapshot, spec());
  assert.throws(() => { s.jobs[0].snapshot.referenceImages.reverse(); }, TypeError);
  const tampered = structuredClone(s); tampered.jobs[0].snapshot.workflow.version = 'altered-on-disk';
  await assert.rejects(() => RecoveryQueue.open({ store: new MemoryStore(tampered), adapter: mock }), /hash\/schema mismatch/);
});

test('F13 cost unknown is not zero; repeated charges reconcile once per taskId and currencies never mix', async () => {
  const mock = new MockService({ submissions: [{ taskId: 'fee-rh' }, { taskId: 'fee-cny' }, { taskId: 'fee-unknown' }], queries: {
    'fee-rh': [success('rh', { currency: 'RH_COIN', amount: null }), success('rh', { currency: 'RH_COIN', amount: '98' }), success('rh', { currency: 'RH_COIN', amount: '98.0' }), success('rh', { currency: 'RH_COIN', amount: '99' })],
    'fee-cny': [success('cny', { currency: 'CNY', amount: '0.10' })], 'fee-unknown': [success('unknown', { currency: 'RH_COIN', amount: null })],
  } });
  const { queue } = await setup(mock); const a = await queue.enqueue('fee-a', spec()); await queue.enqueue('fee-b', spec()); await queue.enqueue('fee-c', spec());
  await queue.step(); await queue.step(); await queue.step();
  let s = await queue.inspect(); assert.equal(s.ledger['fee-rh'].amount, null);
  let totals = ledgerSummary(s); assert.deepEqual(totals.totals.RH_COIN.unknownTaskIds, ['fee-rh']); assert.equal(totals.isFullyReconciled, false);
  await queue.refreshKnownTask(a.id); await queue.refreshKnownTask(a.id); await queue.refreshKnownTask(a.id);
  for (let i = 0; i < 6; i++) await queue.step();
  s = await queue.inspect(); totals = ledgerSummary(s);
  assert.equal(Object.keys(s.ledger).length, 3); assert.equal(totals.totals.RH_COIN.knownAmount, '98'); assert.equal(totals.totals.CNY.knownAmount, '0.1');
  assert.deepEqual(totals.totals.RH_COIN.unknownTaskIds, ['fee-unknown']); assert.deepEqual(totals.totals.RH_COIN.conflictTaskIds, ['fee-rh']);
  assert.ok(!('grandTotal' in totals)); assert.equal(totals.isFullyReconciled, false);
});

test('F14 storage failure before side effect and corrupt state never fall back to a fresh queue', async () => {
  const mock = new MockService({ submissions: [{ taskId: 'must-not-submit' }] });
  const memory = new MemoryStore(); let fail = false;
  const store = { read: () => memory.read(), compareAndSwap: (v, s) => { if (fail) throw new Error('disk unavailable'); return memory.compareAndSwap(v, s); } };
  const { queue } = await setup(mock, store); await queue.enqueue('disk-error', spec()); fail = true;
  await assert.rejects(() => queue.step(), /disk unavailable/); assert.equal(mock.calls.submit.length, 0);
  const dir = await mkdtemp(join(tmpdir(), 'rh-corrupt-'));
  try {
    const path = join(dir, 'state.json');
    await assert.rejects(() => RecoveryQueue.open({ store: new FileStore(path), adapter: mock }), { code: 'ENOENT' });
    await writeFile(path, '{broken');
    await assert.rejects(() => RecoveryQueue.open({ store: new FileStore(path), adapter: mock }), SyntaxError);
    await writeFile(path, JSON.stringify(await memory.read())); await mkdir(path + '.lock');
    await assert.rejects(() => RecoveryQueue.open({ store: new FileStore(path), adapter: mock }), StorageBusyError);
    assert.equal(mock.calls.submit.length, 0);
  } finally { await rm(dir, { recursive: true, force: true }); }
});

test('F15 remote terminal failure frees the queue but never retries the failed generation', async () => {
  const mock = new MockService({ submissions: [{ taskId: 'rh-failed' }, { taskId: 'rh-next' }], queries: { 'rh-failed': [{ status: 'FAILED', charge: { currency: 'RH_COIN', amount: null } }] } });
  const { queue } = await setup(mock); const a = await queue.enqueue('failed', spec()); const b = await queue.enqueue('next', spec());
  await queue.step(); await queue.step(); await queue.step();
  assert.equal((await job(queue, a.id)).state, 'REMOTE_FAILED'); assert.equal((await job(queue, b.id)).taskId, 'rh-next');
  assert.equal(mock.calls.submit.length, 2); assert.equal(mock.calls.download.length, 0);
});

test('F16 malformed/901 reply without taskId and duplicate taskId fail closed; credential fields are rejected', async () => {
  const mock = new MockService({ submissions: [{ code: 901, taskId: null }] }); const { queue } = await setup(mock);
  const a = await queue.enqueue('unsupported', spec()); await queue.step(); await queue.step();
  assert.equal((await job(queue, a.id)).state, 'SUBMISSION_UNKNOWN'); assert.equal(mock.calls.submit.length, 1);
  assert.throws(() => snapshotOf(spec({ apiKey: 'MOCK-NOT-A-KEY' })), /unknown snapshot/);
  assert.throws(() => snapshotOf(spec({ parameters: { token: 'MOCK-NOT-A-KEY' } })), /credential field/);
  assert.throws(() => snapshotOf(spec({ referenceImages: [{ assetId: 'https://example.invalid/signed?token=redacted', sha256: 'b'.repeat(64) }] })), /opaque ID/);
  assert.throws(() => snapshotOf(spec({ parameters: { steps: NaN } })), /non-finite/);

  const reused = new MockService({ submissions: [{ taskId: 'reused-id' }, { taskId: 'reused-id' }], queries: { 'reused-id': [{ status: 'FAILED' }] } });
  const r = await setup(reused); await r.queue.enqueue('reuse-a', spec()); const b = await r.queue.enqueue('reuse-b', spec());
  await r.queue.step(); await r.queue.step(); await r.queue.step();
  assert.equal((await job(r.queue, b.id)).state, 'SUBMISSION_UNKNOWN'); assert.equal(Object.keys((await r.queue.inspect()).ledger).length, 1);
});

test('F17 wrong download receipt hash keeps the original result for retry without generation', async () => {
  const mock = new MockService({ submissions: [{ taskId: 'rh-corrupt-download' }], queries: { 'rh-corrupt-download': [success('original')] },
    downloads: [r => ({ files: [{ artifactId: r.artifacts[0].artifactId, sha256: 'f'.repeat(64), storageKey: 'mock/bad' }] }), receipt] });
  const { queue } = await setup(mock); const a = await queue.enqueue('bad-download', spec());
  await queue.step(); await queue.step(); await queue.step(); assert.equal((await job(queue, a.id)).state, 'DOWNLOAD_RETRY');
  await queue.retryDownload(a.id); await queue.step(); assert.equal((await job(queue, a.id)).state, 'COMPLETED');
  assert.equal(mock.calls.submit.length, 1); assert.equal(mock.calls.query.length, 1);
});

test('F18 late poll success after timeout is accepted once and stale pending cannot regress running', async () => {
  const pending = deferred(); const mock = new MockService({ submissions: [{ taskId: 'rh-late-poll' }], queries: { 'rh-late-poll': [() => pending.promise, { status: 'PENDING' }, success('late-poll')] } });
  const { queue } = await setup(mock); const a = await queue.enqueue('late-poll', spec()); await queue.step(); await queue.step();
  assert.equal((await job(queue, a.id)).state, 'QUERY_RETRY');
  pending.resolve({ status: 'RUNNING' }); await turn();
  await queue.step(); assert.equal((await job(queue, a.id)).lastRemoteStatus, 'RUNNING');
  await queue.step(); await queue.step();
  assert.equal((await job(queue, a.id)).state, 'COMPLETED'); assert.equal(mock.calls.submit.length, 1); assert.equal(mock.calls.download.length, 1);
});

test('F19 late download receipt from an old attempt cannot replace a newer completed receipt', async () => {
  const old = deferred(); const mock = new MockService({ submissions: [{ taskId: 'rh-late-file' }], queries: { 'rh-late-file': [success('file')] },
    downloads: [() => old.promise, r => ({ files: [{ ...receipt(r).files[0], storageKey: 'mock-downloads/newer-attempt' }] })] });
  const { queue } = await setup(mock); const a = await queue.enqueue('late-file', spec());
  await queue.step(); await queue.step(); await queue.step(); assert.equal((await job(queue, a.id)).state, 'DOWNLOAD_RETRY');
  await queue.retryDownload(a.id); await queue.step();
  old.resolve({ files: [{ ...receipt(mock.calls.download[0]).files[0], storageKey: 'mock-downloads/old-attempt' }] }); await turn();
  assert.equal((await job(queue, a.id)).downloadReceipt.files[0].storageKey, 'mock-downloads/newer-attempt');
  assert.equal(mock.calls.submit.length, 1); assert.equal(mock.calls.query.length, 1);
});
