export function spec(overrides = {}) {
  return { prompt: 'MOCK ONLY: hold the reference order; no media generation.',
    referenceImages: [{ assetId: 'mock-environment', sha256: 'b'.repeat(64) }, { assetId: 'mock-character', sha256: 'c'.repeat(64) }],
    workflow: { id: 'mock-workflow', version: 'mock-v1', sha256: 'd'.repeat(64) },
    parameters: { seed: 1234, steps: 20, durationSeconds: 5 }, ...overrides };
}
