# 本地适配契约（不是RH线上协议）

模块仅接受一个服务对象 `{ submit, query, download }`。本包唯一实现为 test/mock-service.mjs，直接返回脚本化数据，无网络、鉴权、模型或媒体。下面形状都是**候选内部协议**，不能照抄当 RH HTTP 字段。

## submit(snapshot)

输入为深冻结快照，不传 local intentKey、attemptId 或服务器幂等键。一次调用必须最多对应一次网络发送；未来适配层及其HTTP库不得自行重试submit，也不能在异常时改用其他生成端点。

```js
{ taskId: 'mock-task-1' }                    // 已受理，后续查原ID
{ code: 421, taskId: null }                 // 本附件明确未受理的容量拒绝
{ code: 901, taskId: null }                 // 本候选保守归未知，不自动改路由重发
```

抛错、超时、无有效ID且非明确421均按未知处理。超时不代表服务没收到，abort也不能证明没生成。迟到有效ID可绑定同attempt；否则只能人工提供已核实的远端ID，不提供“按本地ID查RH”的能力。

## query(taskId)

```js
{ status: 'PENDING' }
{ status: 'RUNNING' }
{ status: 'FAILED', charge: { currency: 'RH_COIN', amount: null } }
{
  status: 'SUCCEEDED',
  artifacts: [{
    artifactId: 'mock-output-1',
    sha256: 'a'.repeat(64),
    mediaType: 'application/x-mock-result',
  }],
  charge: { currency: 'RH_COIN', amount: '98' },
}
```

只接受 PENDING/RUNNING/SUCCEEDED/FAILED/CANCELLED。适配层负责将真实状态映射到这些值，并保证结果属于查询的taskId。读失败可再读；状态未知不能当FAILED而重生成。媒体类型示例明确为mock回执，不代表生成了任何文件。

RH是否给出输出SHA256/稳定结果ID/收费字段未知。本模块使用它们作为内部契约，未来适配器必须核实来源并自行得到可靠哈希（必要时下载后计算）、定义稳定结果标识；不得编造服务端已提供它们。若无法给出结果引用，候选会保留同ID查询待重试，不生成替代任务。

## download(result)

输入是持久化的原taskId、snapshotHash、artifacts。未来适配器可按已有taskId安全刷新下载地址，但不得调用生成接口。输出只含白名单回执：

```js
{ files: [{
  artifactId: 'mock-output-1',
  sha256: 'a'.repeat(64),
  storageKey: 'mock-downloads/mock-task-1/mock-output-1',
}] }
```

本包mock只构造这份JSON，**不写媒体字节**。候选核对顺序、ID和声明哈希；实际内容哈希、下载中断续传、文件存在性、原子落地与URL过期刷新未实现。失败留在DOWNLOAD_RETRY，显式重试只下载原结果。

## 存储与驱动

store.read返回独立快照，store.compareAndSwap(expectedRevision,next)必须原子地校验旧revision并保存整个新状态，同时把revision加一；失败返回false或抛错，不能部分成功后又当作可以重放提交。所有服务效果均在成功CAS后执行。存储错误时停止效果；即使提交意图已落盘而调用没发生，重启仍保持未知。

MemoryStore在同一JS进程中提供CAS；FileStore对同一台机器的同一路径使用独占短锁/rename/fsync。锁忙时抛StorageBusyError，不自动抢锁。多机器、数据库/浏览器存储需单独实现等价CAS及持久化保障，不提供通用分布式锁或自动选主承诺。

调用方决定step频率，查询可做退避。别对提交错误套全局HTTP重试，别删除本地状态“解决”未知。浏览器关闭后Promise不会存活；新实例由持久化状态恢复，不依赖旧Promise继续执行。
