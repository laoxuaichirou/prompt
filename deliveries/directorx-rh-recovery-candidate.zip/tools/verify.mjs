#!/usr/bin/env node
import { readFileSync, readdirSync } from 'node:fs';
import { dirname, join, relative, resolve, sep } from 'node:path';
import { fileURLToPath } from 'node:url';
import { createHash } from 'node:crypto';
const base = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const manifest = JSON.parse(readFileSync(join(base, 'MANIFEST.json'), 'utf8'));
function walk(path) { return readdirSync(path, { withFileTypes: true }).flatMap(e => e.isDirectory() ? walk(join(path, e.name)) : [join(path, e.name)]); }
const actual = walk(base).map(p => relative(base, p).split(sep).join('/')).filter(p => p !== 'MANIFEST.json').sort();
const expected = manifest.files.map(x => x.path).sort();
if (JSON.stringify(actual) !== JSON.stringify(expected)) throw new Error('manifest file list differs from actual package');
for (const x of manifest.files) {
  const path = resolve(base, x.path);
  if (!path.startsWith(base + sep)) throw new Error('manifest path outside package');
  const data = readFileSync(path);
  if (data.length !== x.bytes || createHash('sha256').update(data).digest('hex') !== x.sha256) throw new Error('hash/size mismatch: ' + x.path);
}
console.log(`PASS: ${actual.length} files verified; manifest excludes its own checksum.`);
