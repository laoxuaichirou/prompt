#!/usr/bin/env python3
"""Optional offline packaging tool, not a runtime dependency of the JS module."""
from pathlib import Path
import hashlib,json,zipfile
B=Path(__file__).resolve().parents[1]
def purpose(path):
    p=str(path)
    if p.startswith('src/'):return '新写零依赖JavaScript候选模块或文件存储'
    if p.startswith('test/'):return '仅脚本化模拟服务和具体故障测试，不访问网络或生成媒体'
    if p.startswith('results/'):return '真实运行日志、退出码或演练结果'
    if p.startswith('examples/'):return '演练脚本或模拟产生的脱敏持久化JSON；非RH真实任务'
    if p.startswith('source-materials/'):return '原上传材料、原许可证或来源哈希；不是已安装配置'
    if p.startswith('tools/'):return '本地检查、测试日志保存或打包工具'
    return '独立交付的用途、状态契约、故障证据、适配边界或未验证说明'
files=[]
for p in sorted(B.rglob('*')):
    if not p.is_file() or p.name=='MANIFEST.json':continue
    assert '__pycache__' not in p.parts and p.suffix!='.pyc','remove generated Python cache before packaging'
    raw=p.read_bytes();rel=p.relative_to(B)
    files.append({'path':str(rel),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'purpose':purpose(rel)})
(B/'MANIFEST.json').write_text(json.dumps({'schema':1,'scope':'Independent task-three recovery candidate; mock only; not integrated',
    'selfHash':'MANIFEST.json excludes itself to avoid a circular checksum; every other ZIP entry is listed', 'files':files},ensure_ascii=False,indent=2)+'\n')
out=B.parent/'directorx-rh-recovery-candidate.zip'
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for f in files:z.write(B/f['path'],f['path'])
    z.write(B/'MANIFEST.json','MANIFEST.json')
with zipfile.ZipFile(out) as z:
    assert z.testzip() is None
    assert set(z.namelist())=={f['path'] for f in files}|{'MANIFEST.json'}
    for f in files:assert hashlib.sha256(z.read(f['path'])).hexdigest()==f['sha256']
print(json.dumps({'zip':str(out),'bytes':out.stat().st_size,'entries':len(files)+1,'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'integrity':'PASS'}))
