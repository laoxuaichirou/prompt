#!/usr/bin/env node
import { spawnSync } from 'node:child_process';
import { mkdirSync, writeFileSync } from 'node:fs';
import { dirname, resolve, join } from 'node:path';
import { fileURLToPath } from 'node:url';
const base = resolve(dirname(fileURLToPath(import.meta.url)), '..'), out = join(base, 'results');
mkdirSync(out, { recursive: true });
const r = spawnSync(process.execPath, ['examples/offline-demo.mjs'], { cwd: base, encoding: 'utf8', timeout: 60_000 });
writeFileSync(join(out, 'demo.stdout.log'), r.stdout ?? '');
writeFileSync(join(out, 'demo.stderr.log'), r.stderr ?? '');
writeFileSync(join(out, 'demo-run.json'), JSON.stringify({ command: ['node', 'examples/offline-demo.mjs'], node: process.version, completedAtUTC: new Date().toISOString(), exitCode: r.status, signal: r.signal, realServiceCalls: 0, mediaGenerated: false }, null, 2) + '\n');
process.stdout.write(r.stdout ?? ''); process.stderr.write(r.stderr ?? ''); process.exitCode = r.status ?? 1;
