#!/usr/bin/env node
import { spawnSync } from 'node:child_process';
import { mkdirSync, writeFileSync } from 'node:fs';
import { dirname, resolve, join } from 'node:path';
import { fileURLToPath } from 'node:url';
const base = resolve(dirname(fileURLToPath(import.meta.url)), '..'), out = join(base, 'results');
mkdirSync(out, { recursive: true });
const command = ['--test', '--test-reporter=tap', 'test/recovery.test.mjs'];
const startedAt = new Date().toISOString();
const r = spawnSync(process.execPath, command, { cwd: base, encoding: 'utf8', timeout: 60_000 });
writeFileSync(join(out, 'test-results.tap'), r.stdout ?? '');
writeFileSync(join(out, 'test-results.stderr.log'), r.stderr ?? '');
const count = label => Number((r.stdout ?? '').match(new RegExp(`^# ${label} (\\d+)$`, 'm'))?.[1] ?? -1);
const names = [...(r.stdout ?? '').matchAll(/^# Subtest: (F\d+) (.+)$/gm)].map(m => ({ id: m[1], fault: m[2] }));
const summary = { startedAtUTC: startedAt, completedAtUTC: new Date().toISOString(), node: process.version, platform: process.platform,
  command: ['node', ...command], exitCode: r.status, signal: r.signal, runnerError: r.error?.code ?? null,
  tests: count('tests'), passed: count('pass'), failed: count('fail'), cancelled: count('cancelled'), skipped: count('skipped'), todo: count('todo'),
  scenarios: names, execution: 'real Node test execution against scripted mock service; no HTTP adapter implemented',
  realServiceCalls: 0, keysAccepted: false, mediaGenerated: false, projectIntegrated: false };
writeFileSync(join(out, 'summary.json'), JSON.stringify(summary, null, 2) + '\n');
process.stdout.write(r.stdout ?? ''); process.stderr.write(r.stderr ?? '');
if (r.status !== 0 || summary.tests <= 0 || summary.failed !== 0 || summary.cancelled !== 0 || summary.skipped !== 0 || summary.todo !== 0) process.exitCode = r.status || 1;
