#!/usr/bin/env python3
"""Create MANIFEST and a real ZIP from this delivery directory, offline."""
from pathlib import Path
import hashlib, json, zipfile
B=Path(__file__).resolve().parents[1]
def purpose(rel):
    s=str(rel)
    if s.startswith('upstream/skills/'):return '上传原始Skill/参考/示例/脚本，字节保留，用于复现与对照'
    if s.startswith('candidate-skills/'):return '同结构审查候选；相对原版的修改见patches，其余保留'
    if s.startswith('patches/'):return '针对上传原文件的unified diff，实际应用后与候选字节一致'
    if s.startswith('tests/results/'):return '本次实际运行的退出码、标准输出/错误或结构化检查结果'
    if s.startswith('tests/repro/'):return '完整可解析的缺陷触发输入，配合regression脚本复现'
    if s.startswith('tests/'):return '离线复现、检查、来源清单或打包/校验工具'
    if s.startswith('fixtures/watch-shop/original-format/'):return '原版字段与枚举的完整压力对照；outline/storyboard预期不兼容'
    if s.startswith('fixtures/watch-shop/h3/'):return '已执行export产生的提示词和缺图清单；不含图像或视频'
    if s.startswith('fixtures/watch-shop/reports/'):return '候选render实际输出，文本评审，不是媒体质量报告'
    if s.startswith('fixtures/watch-shop/'):return '短篇制作候选、源文、五JSON、镜头表、身份或任务时间线'
    if s.startswith('prompts/'):return '可复用离线审查/局部返修任务指令'
    if s.startswith('upstream/'):return '附件指令及出处元数据，作为审查材料保留'
    return {'README.md':'GitHub可用的用途、操作、结果、局限和兼容性说明','audit.md':'10项有源码证据的交接审查和最小修复报告',
            'READING_INVENTORY.md':'逐文件实际阅读范围、未通读及未使用说明','UNVERIFIED.md':'未执行和不能由本次检查证明的项目',
            'LICENSE.upstream':'上传的原始许可证，保持原文','SOURCES.md':'唯一来源、许可保留及本次修改范围说明'}.get(s,'交付说明')

def package():
    files=[]
    for p in sorted(B.rglob('*')):
        if not p.is_file() or p.name=='MANIFEST.json' or '__pycache__' in p.parts or p.suffix=='.pyc':continue
        rel=p.relative_to(B);raw=p.read_bytes()
        files.append({'path':str(rel),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'purpose':purpose(rel)})
    manifest={'formatVersion':1,'scope':'offline task-one review candidate; no media generation',
              'selfHash':'MANIFEST.json intentionally omitted to avoid a self-referential checksum; all other archive files are listed',
              'files':files}
    (B/'MANIFEST.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
    dest=B.parent/'directorx-web-review-delivery.zip'
    with zipfile.ZipFile(dest,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for x in files:z.write(B/x['path'],x['path'])
        z.write(B/'MANIFEST.json','MANIFEST.json')
    with zipfile.ZipFile(dest) as z:
        assert z.testzip() is None
        assert set(z.namelist())=={x['path'] for x in files}|{'MANIFEST.json'}
        for x in files:assert hashlib.sha256(z.read(x['path'])).hexdigest()==x['sha256'],x['path']
    print(json.dumps({'zip':str(dest),'bytes':dest.stat().st_size,'files':len(files)+1,'sha256':hashlib.sha256(dest.read_bytes()).hexdigest(),'integrity':'PASS'},ensure_ascii=False))
    return dest
if __name__=='__main__':package()
