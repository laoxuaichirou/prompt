#!/usr/bin/env python3
"""Independent offline cross-file checks. Not a replacement for Node validators."""
from pathlib import Path
import json, csv, copy, math, sys

BASE=Path(__file__).resolve().parents[1]
DEFAULT=BASE/'fixtures/watch-shop'

def check_fixture(folder=DEFAULT, documents=None):
    d=documents or {n:json.loads((folder/(n+'.json')).read_text()) for n in ['outline','cast','art','script','storyboard','identity-map','timeline','production']}
    o,c,a,s,b,m,t,p=[d[n] for n in ['outline','cast','art','script','storyboard','identity-map','timeline','production']]
    checks=[]
    def ok(condition,label):
        if not condition: raise AssertionError(label)
        checks.append(label)
    def typ(x,expected,label):
        ok(type(x) is expected,label+' type')
    def text(x,label):
        typ(x,str,label);ok(bool(x.strip()),label+' nonempty')
    def number(x,label):
        ok(type(x) in (int,float) and math.isfinite(x),label+' finite number')
    for n in ['outline','cast','art','script','storyboard']:
        typ(d[n],dict,n);text(d[n]['source'],n+'.source');ok(d[n]['source']==o['source'],n+' source consistent')
    source=(folder/'source.txt').read_text()
    chars={x['id']:x for x in o['characters']};scenes={x['id']:x for x in o['scenes']};props={x['id']:x for x in a['props']};ascenes={x['id']:x for x in a['scenes']}
    for items,key,prefix in [(o['characters'],'id','C'),(o['scenes'],'id','S'),(o['beats'],'id','B'),(a['scenes'],'id','S'),(a['props'],'id','P')]:
        ids=[x[key] for x in items];ok(len(ids)==len(set(ids)),prefix+' unique IDs')
        for ident in ids:
            ok(isinstance(ident,str) and ident.startswith(prefix) and ident[1:].isdigit() and len(ident)>=3,prefix+' ID format')
    ok(len(o['episodes'])==o['params']['episodes']==1,'exactly one episode');ok(o['params']['minutesPerEpisode']==1,'one minute')
    typ(o['params']['episodes'],int,'episodes');number(o['params']['minutesPerEpisode'],'minutes')
    for x in o['characters']:
        for k in ['name','role','tier']:text(x[k],'outline.character.'+k)
        ok(x['tier'] in ['lead','support','functional'],'tier enum');typ(x['from'],list,'from')
    for x in o['scenes']:typ(x['primary'],bool,'outline.primary')
    for x in o['episodes']:
        typ(x['ep'],int,'outline.ep');typ(x['sceneIds'],list,'sceneIds');typ(x['characterIds'],list,'characterIds');typ(x['warnings'],list,'warnings')
        ok(set(x['sceneIds'])<=set(scenes),'outline scene refs');ok(set(x['characterIds'])<=set(chars),'outline character refs')
    for x in o['adaptation']['keep']:ok(x['evidence'] in source,'outline evidence literal source')
    names=[x['name'] for x in c['characters']]
    ok(len(names)==len(set(names)),'cast names unique')
    ok(set(m['characters'])==set(chars),'identity-map exactly covers outline C IDs')
    ok(set(m['characters'].values())==set(names),'identity-map exactly covers cast names')
    ok(all(chars[k]['name']==v for k,v in m['characters'].items()),'identity-map agrees with outline names')
    ok(len(m['characters'].values())==len(set(m['characters'].values())),'identity-map one to one')
    ok(m['voices']['VO']['identity']=='unknown' and m['voices']['VO']['visible'] is False,'VO identity unknown and invisible')
    for x in c['characters']:
        for k in ['name','oneLiner']:text(x[k],'cast.'+k)
        for k in ['aliases']:typ(x[k],list,'cast.'+k)
        ok(x['importance'] in ['protagonist','major','supporting','minor'],'importance enum')
        for k in ['gender','ageRange','identity','appearance','temperament','motivation','arc']:text(x['persona'][k],'persona.'+k)
        for k in ['personality','relationships','evidence']:typ(x['persona'][k],list,'persona.'+k)
        for q in x['persona']['evidence']:text(q,'evidence');ok(q in source,'cast quote literal source')
        for r in x['persona']['relationships']:ok(r['name'] in names,'relationship target known')
        for k in ['style','prompt','negativePrompt','sheet','promptLocal']:text(x['image'][k],'image.'+k)
        typ(x['image']['tags'],list,'tags')
        for k in ['timbre','pitch','pace','accent','emotion','referenceHint','prompt','promptLocal']:text(x['voice'][k],'voice.'+k)
    ok(set(scenes)==set(ascenes),'outline and art physical scenes agree')
    for x in a['scenes']:
        typ(x['primary'],bool,'art.primary');ok(x['name']==scenes[x['id']]['name'],'scene name stable')
        ok(3<=len(x['anchors'])<=5,'scene anchor count')
        for l in x['lighting']:text(l['state'],'lighting.state');text(l['prompt'],'lighting.prompt')
    for x in a['props']:
        ok(x['scale'] in ['手持级','桌面级','家具级'],'prop scale enum')
        ok(set(x['carriedBy'])<=set(names),'carriedBy maps to cast')
        ok(set(x['relatedScenes'])<=set(scenes),'prop scene refs')
        ok(3<=len(x['anchors'])<=5,'prop anchor count');ok(len(x['states'])>0,'prop states present')
        for st in x['states']:text(st['state'],'prop.state');text(st['prompt'],'prop.prompt')
    ok(c['style']==a['style']==b['style']=='photorealistic','explicit consistent candidate photo style')
    ok(p['aspectRatio']=='9:16','production aspect is 9:16')
    for k in ['charsPerSecond','actionSeconds','tolerance','maxLineChars']:
        number(s['params'][k],'script.params.'+k)
    ep=s['episodes'][0];ok(ep['ep']==1 and ep['targetSeconds']==60,'script target matches outline')
    ok(set(ep['beatsClaimed'])=={x['type'] for x in o['beats']},'exact claimed outline beats')
    hb=ep['hookBeat'];ok(len(hb)==2 and all(type(v) is int and v>=1 for v in hb),'hookBeat shape')
    ok(sum(len(sc['flow']) for sc in ep['scenes'][:hb[0]-1])+hb[1]<=3,'hook within first three beats')
    lines=[];action_count=0
    for sc in ep['scenes']:
        ok(sc['sceneId'] in ascenes,'script scene registered');typ(sc['characters'],list,'script.characters');typ(sc['props'],list,'script.props');typ(sc['flow'],list,'flow')
        ok(set(sc['characters'])<=set(chars),'script character refs');ok(set(sc['props'])<=set(props),'script prop refs')
        ok(sc['lighting'] in {l['state'] for l in ascenes[sc['sceneId']]['lighting']},'script lighting state registered')
        for beat in sc['flow']:
            ok(('action' in beat)^('line' in beat),'exclusive beat type')
            if 'action' in beat:text(beat['action'],'action');action_count+=1
            else:
                text(beat['line'],'line');ok(beat['speaker'] in sc['characters']+['VO'],'speaker membership')
                ok(len(''.join(beat['line'].split()))<=35,'line <=35');lines.append(beat['line'])
    ok(lines==['刚才送错了包裹，要取回怀表。','小禾，是我。'],'no invented dialogue')
    ok('身份未知' in ep['scenes'][1]['flow'][1]['delivery'],'unknown source delivery explicit')
    cut_count=0;total=0;actual_claims={i:[] for i in range(1,len(ep['scenes'])+1)};dialogue_seconds=0;action_seconds=0
    time_map={x['shot']:x for x in t['shots']}
    for seg_index,seg in enumerate(b['episodes'][0]['segments'],1):
        ok(seg['id']==f'E01-{seg_index:02d}','segment consecutive ID');typ(seg['sceneIndex'],int,'sceneIndex');sc=ep['scenes'][seg['sceneIndex']-1]
        seg_total=0
        for ci,cut in enumerate(seg['cuts'],1):
            cut_count+=1;number(cut['seconds'],'seconds');ok(2<=cut['seconds']<=8,'candidate cut interval')
            ok(len(cut['characters'])==len(set(cut['characters']))<=3,'max 3 unique on-screen characters')
            ok(set(cut['characters'])<=set(sc['characters']),'cut character refs');ok(set(cut['props'])<=set(sc['props']),'cut prop refs')
            ok('portrait 9:16' in cut['frame'],'per-frame portrait 9:16')
            ok('photorealistic live-action film still' in cut['frame'].lower(),'photo style per frame')
            start,end=cut['beats'];ok(type(start) is int and type(end) is int and 1<=start<=end<=len(sc['flow']),'beat range int bounds')
            actual_claims[seg['sceneIndex']].extend(range(start,end+1))
            beats=sc['flow'][start-1:end]
            ds=sum(len(''.join(z['line'].split()))/s['params']['charsPerSecond'] for z in beats if 'line' in z)
            ac=sum('action' in z for z in beats)*s['params']['actionSeconds']
            ok(ds+ac<=cut['seconds']+1e-9,'actions plus dialogue fit cut; stronger than original dialogue-only gate')
            shot=f'{seg["id"]}#{ci}';entry=time_map[shot]
            ok(abs(entry['start']-total)<1e-8 and abs(entry['end']-(total+cut['seconds']))<1e-8,'time continuity')
            ok(abs(entry['reservedHoldSeconds']-(cut['seconds']-ds-ac))<1e-8,'hold explicitly budgeted')
            total+=cut['seconds'];seg_total+=cut['seconds'];dialogue_seconds+=ds;action_seconds+=ac
        ok(9<=seg_total<=15,'all candidate segments satisfy recommended 9-15 seconds')
    for si,claims in actual_claims.items():ok(claims==list(range(1,len(ep['scenes'][si-1]['flow'])+1)),'claims exactly once in order')
    ok(cut_count==8 and total==60,'exact planned 8 cuts / 60 seconds')
    ok(len(scenes)==1,'one physical scene; two script occurrences are not two locations')
    ok(abs(dialogue_seconds-20/4.5)<1e-8,'dialogue character count including punctuation is 20')
    ok(action_count==19 and action_seconds==47.5,'19 action beats at 2.5 seconds')
    ok(abs(total-dialogue_seconds-action_seconds-8.055555555555557)<1e-8,'8.0556 seconds reserved hold')
    for overlay in t['postproductionText']:
        ok(overlay['shot'] in time_map,'overlay shot exists');ok(0<overlay['durationSeconds']<=time_map[overlay['shot']]['seconds'],'overlay exposure fits shot')
    ok(t['postproductionText'][1]['text']=='别开后门','exact warning kept outside image prompt language restriction')
    ok(p['costModel']['actualCallsThisReview']==0 and p['costModel']['actualChargeThisReview']==0,'review makes zero service submissions')
    assets={x['id'] for x in p['assets']};frames={x['id'] for x in p['keyframes']};videos={x['id'] for x in p['videos']}
    ok(len(frames)==8 and len(videos)==4,'production task counts')
    for task in p['keyframes']:
        ok(set(task['depends_on'])<=assets,'frame dependency closure');ok(task['shot'] in time_map,'task shot known')
        ok(not (folder/task['output']).exists(),'no fabricated media file')
    for task in p['videos']:ok(set(task['depends_on'])<=frames,'video dependency closure')
    with (folder/'shots.csv').open(encoding='utf-8-sig',newline='') as handle:rows=list(csv.DictReader(handle))
    ok(len(rows)==8 and sum(float(x['seconds']) for x in rows)==60,'CSV agrees with plan')
    return {'status':'PASS','assertions':len(checks),'plannedSeconds':total,'actualRenderedSeconds':None,'cuts':cut_count,'physicalScenes':len(scenes),
            'visibleCharacterIdentities':len(chars),'dialogueCharacters':20,'dialogueSecondsExact':dialogue_seconds,'actionSeconds':action_seconds,
            'scriptEstimateExact':dialogue_seconds+action_seconds,'reservedHoldSeconds':total-dialogue_seconds-action_seconds,'scope':'independent fixture checks; not media-quality validation'}

def mutation_tests():
    originals={n:json.loads((DEFAULT/(n+'.json')).read_text()) for n in ['outline','cast','art','script','storyboard','identity-map','timeline','production']}
    def mutate(name,fn):
        d=copy.deepcopy(originals);fn(d)
        try:check_fixture(documents=d)
        except (AssertionError,KeyError,TypeError):return {'name':name,'status':'REJECTED_AS_EXPECTED'}
        raise AssertionError('mutant was not rejected: '+name)
    return [
        mutate('cast identity swapped',lambda d:d['identity-map']['characters'].update({'C01':'快递员','C02':'林禾'})),
        mutate('unknown carriedBy',lambda d:d['art']['props'][0].update(carriedBy=['不存在的人'])),
        mutate('wrong 16:9 frame',lambda d:d['storyboard']['episodes'][0]['segments'][0]['cuts'][0].update(frame='photorealistic live-action film still, medium shot, landscape 16:9')),
        mutate('bool used as seconds',lambda d:d['storyboard']['episodes'][0]['segments'][0]['cuts'][0].update(seconds=True)),
        mutate('missing registered scene',lambda d:d['script']['episodes'][0]['scenes'][0].update(sceneId='S99')),
        mutate('duplicate beat claim',lambda d:d['storyboard']['episodes'][0]['segments'][0]['cuts'][1].update(beats=[1,3])),
        mutate('unsupported 61s total',lambda d:d['storyboard']['episodes'][0]['segments'][0]['cuts'][0].update(seconds=8.5)),
        mutate('added confirmed brother face',lambda d:d['storyboard']['episodes'][0]['segments'][3]['cuts'][0]['characters'].append('C03')),
        mutate('changed original dialogue',lambda d:d['script']['episodes'][0]['scenes'][1]['flow'][1].update(line='我是你哥哥，开门。')),
        mutate('unmarked timing hold removed',lambda d:d['timeline']['shots'][0].update(reservedHoldSeconds=100)),
        mutate('string instead of primary bool',lambda d:d['art']['scenes'][0].update(primary='true')),
    ]

if __name__=='__main__':
    result=check_fixture();result['negativeMutationTests']=mutation_tests()
    out=BASE/'tests/results/independent.json';out.parent.mkdir(parents=True,exist_ok=True);out.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(result,ensure_ascii=False,indent=2))
