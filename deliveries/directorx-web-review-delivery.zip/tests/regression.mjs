#!/usr/bin/env node
// Offline regression: assertions compare actual original/candidate behavior.
import assert from 'node:assert/strict';
import {readFileSync, writeFileSync, mkdirSync} from 'node:fs';
import {dirname, resolve, join} from 'node:path';
import {fileURLToPath, pathToFileURL} from 'node:url';
const base=resolve(dirname(fileURLToPath(import.meta.url)),'..');
const f=join(base,'fixtures/watch-shop');
const load=p=>JSON.parse(readFileSync(p,'utf8'));
const clone=x=>structuredClone(x);
const read=n=>load(join(f,n+'.json'));
const models=['outline','characters','art','script','storyboard'];
const orig={},cand={};
for(const n of models){
 orig[n]=await import(pathToFileURL(join(base,'upstream/skills',`novel-${n}/scripts/novel-${n}.mjs`)));
 cand[n]=await import(pathToFileURL(join(base,'candidate-skills',`novel-${n}/scripts/novel-${n}.mjs`)));
}
const outline=read('outline'),cast=read('cast'),art=read('art'),script=read('script'),board=read('storyboard');
const ctx={outline,cast,art,script};
const source=readFileSync(join(f,'source.txt'),'utf8');
const reproDir=join(base,'tests/repro');mkdirSync(reproDir,{recursive:true});
const save=(name,x)=>writeFileSync(join(reproDir,name+'.json'),JSON.stringify(x,null,2)+'\n');
let checks=[];
const check=(label,fn)=>{fn();checks.push({label,status:'PASS'});};
const controls={};for(const n of ['outline','cast','art','script','storyboard'])controls[n]=load(join(f,'original-format',n+'.json'));
const cctx={...controls};
check('single-episode major: original rejects, candidate accepts; no new fields',()=>{
 const errors=orig.outline.validateOutline(outline);
 assert.equal(errors.length,1);assert.match(errors[0],/大爆点/);
 assert.deepEqual(cand.outline.validateOutline(outline),[]);
 save('single-episode-major',outline);
});
check('multi-episode major still rejected if first appears only in final episode',()=>{
 const d=clone(outline);d.params.episodes=2;d.beats.forEach(x=>x.episode=2);
 assert.equal(cand.outline.gateReport(d).find(x=>x.id==='major-early').ok,false);
});
check('single-episode still needs at least one major',()=>{
 const d=clone(outline);d.beats.forEach(x=>x.weight='minor');
 assert.equal(cand.outline.gateReport(d).find(x=>x.id==='major-early').ok,false);
});
check('default max 5 rejects 60 seconds in 8 cuts; explicit existing max 8 accepts',()=>{
 const d=clone(controls.storyboard);
 assert.ok(orig.storyboard.validateStoryboard(d,cctx).some(x=>/分镜 2–5/.test(x)));
 d.params.maxCutSeconds=8;
 assert.deepEqual(orig.storyboard.validateStoryboard(d,cctx),[]);
 save('default-cadence-incompatible',controls.storyboard);
});
check('original-format controls for cast/art/script validate independently of single-episode outline rule',()=>{
 assert.deepEqual(orig.characters.validateCast(controls.cast.characters,source,'zh','realistic'),[]);
 assert.deepEqual(orig.art.validateArt(controls.art,orig.art.castNamesOf(controls.cast)),[]);
 assert.deepEqual(orig.script.validateScript(controls.script,cctx),[]);
});
check('all candidate validators accept complete watch-shop fixture',()=>{
 assert.deepEqual(cand.outline.validateOutline(outline),[]);
 assert.deepEqual(cand.characters.validateCast(cast.characters,source,'zh',cast.style),[]);
 assert.deepEqual(cand.art.validateArt(art,cand.art.castNamesOf(cast)),[]);
 assert.deepEqual(cand.script.validateScript(script,ctx),[]);
 assert.deepEqual(cand.storyboard.validateStoryboard(board,ctx),[]);
});
// Use a valid original-style board as baseline to isolate dialogue defects.
const compatible=clone(controls.storyboard);compatible.params.maxCutSeconds=8;
const line='<d>[Chinese] 刚才送错了包裹，要取回怀表。</d>';
check('wrong-cut dialogue: original accepts, candidate rejects',()=>{
 const d=clone(compatible),s=d.episodes[0].segments[1];
 s.h3Prompt=s.h3Prompt.replace(line,'').replace('[Shot 1]','[Shot 1] '+line);
 assert.deepEqual(orig.storyboard.validateStoryboard(d,cctx),[]);
 assert.ok(cand.storyboard.validateStoryboard(d,cctx).some(x=>/台词/.test(x)));
 save('dialogue-wrong-cut',d);
});
check('extra dialogue: original accepts, candidate rejects',()=>{
 const d=clone(compatible);d.episodes[0].segments[0].h3Prompt=d.episodes[0].segments[0].h3Prompt.replace('[Shot 1]','[Shot 1] <d>[Chinese] 门后一定是哥哥。</d>');
 assert.deepEqual(orig.storyboard.validateStoryboard(d,cctx),[]);
 assert.ok(cand.storyboard.validateStoryboard(d,cctx).some(x=>/台词/.test(x)));
 save('dialogue-extra-unfounded-identity',d);
});
check('duplicate dialogue is rejected by candidate',()=>{
 const d=clone(compatible),s=d.episodes[0].segments[1];s.h3Prompt=s.h3Prompt.replace(line,line+' '+line);
 assert.ok(cand.storyboard.validateStoryboard(d,cctx).some(x=>/台词/.test(x)));
});
check('wrong language tag: original accepts, candidate rejects',()=>{
 const d=clone(compatible);d.episodes[0].segments[1].h3Prompt=d.episodes[0].segments[1].h3Prompt.replace(line,line.replace('[Chinese]','[English]'));
 assert.deepEqual(orig.storyboard.validateStoryboard(d,cctx),[]);
 assert.ok(cand.storyboard.validateStoryboard(d,cctx).some(x=>/台词/.test(x)));
 save('dialogue-wrong-tag',d);
});
check('dialogue moved to soundscape: original accepts, candidate rejects',()=>{
 const d=clone(compatible),s=d.episodes[0].segments[1];s.h3Prompt=s.h3Prompt.replace(line,'').replace('overall_soundscape:','overall_soundscape: '+line);
 assert.deepEqual(orig.storyboard.validateStoryboard(d,cctx),[]);
 assert.ok(cand.storyboard.validateStoryboard(d,cctx).some(x=>/台词/.test(x)));
 save('dialogue-in-soundscape',d);
});
check('unclosed extra dialogue block rejected',()=>{
 const d=clone(compatible);d.episodes[0].segments[0].h3Prompt+='<d>broken';
 assert.ok(cand.storyboard.validateStoryboard(d,cctx).some(x=>/台词/.test(x)));
});
check('missing hookBeat is a real schema documentation gap',()=>{
 const d=clone(script);delete d.episodes[0].hookBeat;
 assert.ok(orig.script.validateScript(d,ctx).some(x=>/hookBeat/.test(x)));
 save('missing-undocumented-hookBeat',d);
});
check('new photo style is candidate-only: original art rejects it',()=>{
 assert.ok(orig.art.validateArt(art).some(x=>/style 必须/.test(x)));
 assert.ok(orig.storyboard.validateStoryboard(board,ctx).some(x=>/预设/.test(x)));
});
check('photo candidate forbids banning photorealism in all asset tiers',()=>{
 const c=clone(cast);c.characters[0].image.negativePrompt+=', photorealistic';
 assert.ok(cand.characters.validateCast(c.characters,source,'zh','photorealistic').length>0);
 const a=clone(art);a.scenes[0].image.negativePrompt+=', photorealistic';
 assert.ok(cand.art.validateArt(a).length>0);
});
check('original character splitter intentionally normalises CRLF; regression expectation must match',()=>{
 const raw=readFileSync(join(base,'upstream/skills/novel-characters/examples/渡口.txt'),'utf8');
 const long=raw.repeat(150),chunks=orig.characters.chunkText(long);
 assert.ok(raw.includes('\r\n'));assert.equal(long.includes(chunks[0].slice(0,200)),false);
 assert.equal(long.replace(/\r\n/g,'\n').includes(chunks[0].slice(0,200)),true);
});
check('frame 9:16 accepted only as text: no native aspectRatio schema enforcement claimed',()=>{
 const d=clone(compatible);d.episodes[0].segments[0].cuts[0].frame=d.episodes[0].segments[0].cuts[0].frame.replace('portrait 9:16','landscape 16:9');
 assert.deepEqual(orig.storyboard.validateStoryboard(d,cctx),[]);
 save('wrong-aspect-original-validator-blindspot',d);
});
check('scene-light batches are not video-call counts; exact 60-second totals and missing-frame export',()=>{
 const st=cand.storyboard.computeStats(board,script);
 assert.equal(st.totals.seconds,60);assert.equal(st.totals.cuts,8);assert.equal(st.totals.segments,4);assert.equal(st.batches.length,2);
 const pack=cand.storyboard.exportPack(board,script);
 assert.equal(pack.missingTotal,8);assert.equal(pack.manifest.length,4);
 assert.deepEqual(pack.manifest[0].cutStarts,[0,7.5]);
});
check('reference order regenerated from cut durations, stale first line rejected',()=>{
 const d=clone(compatible);d.episodes[0].segments[0].cuts[0].seconds=7.4;d.episodes[0].segments[0].cuts[1].seconds=7.6;
 assert.ok(cand.storyboard.validateStoryboard(d,cctx).some(x=>/对齐指令|切点/.test(x)));
});
check('candidate export is a missing-media plan, not production readiness',()=>{
 const pack=cand.storyboard.exportPack(board,script);
 assert.ok(pack.manifest.every(x=>x.missing.length===2));
});
mkdirSync(join(base,'tests/results'),{recursive:true});
const result={status:'PASS',assertionGroups:checks.length,node:process.version,scope:'local deterministic regression; no media generation, no service calls',checks};
writeFileSync(join(base,'tests/results/regression.json'),JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify(result,null,2));
