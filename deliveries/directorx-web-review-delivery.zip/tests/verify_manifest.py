#!/usr/bin/env python3
"""Check every delivered file, including extra/missing entries."""
from pathlib import Path
import hashlib, json, sys
B=Path(__file__).resolve().parents[1]
def included(p):
    return p.is_file() and p.name!='MANIFEST.json' and '__pycache__' not in p.parts and p.suffix!='.pyc'
def verify():
    manifest=json.loads((B/'MANIFEST.json').read_text())
    declared={x['path']:x for x in manifest['files']}
    actual={str(p.relative_to(B)) for p in B.rglob('*') if included(p)}
    assert set(declared)==actual,{'missing':sorted(set(declared)-actual),'extra':sorted(actual-set(declared))}
    for name,x in declared.items():
        p=B/name;assert p.resolve().is_relative_to(B)
        data=p.read_bytes();assert len(data)==x['bytes'],name+' size mismatch'
        assert hashlib.sha256(data).hexdigest()==x['sha256'],name+' SHA256 mismatch'
        assert x['purpose'],name+' missing purpose'
    print(f'PASS: {len(declared)} files verified; MANIFEST.json excludes its own hash by design.')
if __name__=='__main__':verify()
