"""Build authored, offline fixtures. Does not generate media or call services."""
from pathlib import Path
import json, subprocess, csv, copy

BASE=Path(__file__).resolve().parents[1]
F=BASE/'fixtures/watch-shop'
F.mkdir(parents=True,exist_ok=True)

def dump(path,obj):
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

def presets(tree):
    files=[BASE/tree/f'novel-{n}/scripts/novel-{n}.mjs' for n in ['characters','art','storyboard']]
    code=';'.join(f'const m{i}=await import({json.dumps(p.as_uri())})' for i,p in enumerate(files))
    code+=';console.log(JSON.stringify({character:m0.STYLE_PRESETS,art:m1.SCENE_STYLE_PRESETS,board:m2.STYLE_PRESETS}))'
    return json.loads(subprocess.check_output(['node','--input-type=module','-e',code],text=True))

P=presets('candidate-skills')
SOURCE='晚上九点，修表师林禾准备关店。失联三年的哥哥寄来一只旧怀表，表停在九点十分，表盖内侧刻着“别开后门”。门外响起敲门声。一名浑身湿透的快递员站在前门，说刚才送错了包裹，要取回怀表。林禾看见他的袖口夹着哥哥工作室的铜钥匙，却没有问。怀表突然走了一格。后门传来哥哥熟悉的声音：“小禾，是我。”她握紧怀表，关掉了店里的灯。'
(F/'source.txt').write_text(SOURCE+'\n',encoding='utf-8')
TITLE='别开后门（附件短篇制作候选）'
outline={
 'source':TITLE,'lang':'zh',
 'params':{'episodes':1,'minutesPerEpisode':1,'genre':'写实轻悬疑','adaptMode':'忠实','preferences':['9:16','最多8个最终镜头','身份疑点不落事实'],
           'thresholds':{'maxLeads':1,'maxSupport':0,'maxFunctional':1,'maxPrimaryScenes':1}},
 'adaptation':{'core':'修表师收到失联哥哥寄来的旧怀表，前门索表与后门熟悉声音形成夹击，她关灯而未揭晓身份。',
   'keep':[{'what':'九点与九点十分的错位、表盖警告、袖口铜钥匙、走一格、熟悉声音及关灯结尾','why':'原文线索链与悬念','evidence':'怀表突然走了一格。'},
           {'what':'不确认门后身份，不解释钥匙来历','why':'保留原作未解部分','evidence':'后门传来哥哥熟悉的声音：'}],
   'cut':[],'merge':[],
   'risks':[{'what':'声音被错误确认为哥哥本人','plan':'仅用VO，声源始终不入画，delivery标记身份未知'},
            {'what':'刻字与精细表针变化不稳定','plan':'精确字样后期叠加；表针只计划走一格，不推定新时间'},
            {'what':'跨镜人脸、湿袖和怀表持握连续性','plan':'显式参考绑定与逐镜检查；本次不出图'}]},
 'characters':[{'id':'C01','name':'林禾','role':'修表师，主视角','tier':'lead','arc':'从准备关店转为警觉，选择关灯而不求证','from':['原作林禾']},
               {'id':'C02','name':'快递员','role':'前门索回怀表者，动机未知','tier':'functional','from':['原作快递员']}],
 'scenes':[{'id':'S01','name':'修表店内（前门与后门同一空间）','primary':True,'reusePlan':'本集同一店内反复使用；以灯亮/熄灯过渡区分，门外不另开景'}],
 'beats':[{'id':'B01','type':'警告与来客','weight':'minor','episode':1,'setup':'旧怀表刻有警告','payoff':'前门有人声称送错包裹并索表'},
          {'id':'B02','type':'悬疑升级','weight':'major','episode':1,'setup':'袖口出现哥哥工作室铜钥匙，林禾未问','payoff':'怀表走一格，后门出现熟悉声音，林禾关灯'}],
 'episodes':[{'ep':1,'synopsis':'晚上九点，林禾准备关店，收到失联三年哥哥寄来的旧怀表，表停九点十分且刻有警告。湿透的快递员在前门索表；她看见袖口夹着哥哥工作室铜钥匙却没有问。表走一格，后门传来熟悉声音，林禾握紧表关灯。声源身份与钥匙来历均未知。',
              'hook':'现实时间与停表时间不符，来自失联亲属的物件带来警告',
              'suspense':'灯灭后不展示门后人，熟悉声音不能证明其身份',
              'sceneIds':['S01'],'characterIds':['C01','C02'],'warnings':['手部特写','刻字','湿衣连续性','声源身份未知']}]
}

cast={'source':TITLE,'lang':'zh','style':'photorealistic',
      'summary':'晚上九点，一间修表店即将关门。修表师收到失联三年哥哥寄来的旧怀表。前门的湿透快递员要求取回怀表，店内外的信息逐渐相互矛盾。', 'characters':[]}
char_specs=[
 ('林禾',['小禾'],'protagonist','准备关店却被怀表线索打断的修表师。','女（原文她）','约28岁（制作假设）','修表师；现代中国城镇为制作假设',
  '成年东亚女性，深色齐肩发，灰色工作衫（制作假设）；不以外貌补充身世', ['细致','克制','警觉'],
  '安静的观察先于提问','护住怀表并判断危险，内心动机不再补写','从例行收工到握表关灯',
  [{'name':'快递员','relation':'在前门要求取回怀表，互不信任尚未得到证实'}],['修表师林禾准备关店。','她握紧怀表，关掉了店里的灯。'],
  'an adult East Asian Chinese woman, about twenty-eight, contemporary small-town China, shoulder-length dark hair, a grey work shirt',
  '成年东亚女性，现代中国城镇，深色齐肩发、灰色工作衫；年龄外观与地域为制作假设',
  '中音区女声，质地清晰而克制','中','适中，遇异常留停顿','普通话（制作假设）','警觉但不惊叫','像静听细小表针声的修理者',
  'Adult female Mandarin voice, clear middle register, restrained, moderate pace, precise articulation. No spoken lines are assigned in this fixture.'),
 ('快递员',[],'minor','湿透的来客索回怀表，袖口夹着铜钥匙。','男（制作假设，原文未明示）','约35岁（制作假设）','快递员；现代中国城镇为制作假设',
  '成年东亚男性，短发、深蓝配送外套；衣物浑身湿透为原文，其余为制作假设',['简短','急促','难辨意图'],
  '话语平直，未证实善恶','声称送错包裹，要取回怀表；真实目的未知','功能性角色，不增转变',
  [{'name':'林禾','relation':'前门索回怀表的对象'}],['一名浑身湿透的快递员站在前门','他的袖口夹着哥哥工作室的铜钥匙'],
  'an adult East Asian Chinese man, about thirty-five, contemporary small-town China, short dark hair, a soaked navy delivery jacket',
  '成年东亚男性，现代中国城镇，短发、湿透深蓝配送外套；年龄外观与地域为制作假设',
  '中低音男声，话语简短','中低','正常略急，保持可辨','普通话（制作假设）','克制，意图不明','像门口要求更正配送的来客，不演成已证实反派',
  'Adult male Mandarin voice, low-middle register, plain brief delivery, moderate pace, intent ambiguous, not a theatrical villain.'),
]
for (name,aliases,importance,one,gender,age,identity,appearance,personality,temperament,motivation,arc,relationships,evidence,visual,local,timbre,pitch,pace,accent,emotion,hint,voice_en) in char_specs:
 cp=P['character']['photorealistic']
 sheet=(f"Single character model sheet on ONE 16:9 landscape canvas, pure white background. {cp['render']}. {visual}. {cp['surface']}. "
        f"LEFT ZONE about 34% of the canvas width: complete bust portrait, face identity master. RIGHT-TOP ZONE: three full-body front, side and rear views, same face and clothes. "
        f"RIGHT-BOTTOM ZONE: four isolated fabric and hair details. thin hairline rules. PROPORTIONS ARE CRITICAL: equal figure height and head-to-body ratio; feet on one baseline. "
        f"If space is tight, the detail studies give way, not the figures. {cp['lighting']}.")
 cast['characters'].append({'name':name,'aliases':aliases,'importance':importance,'oneLiner':one,
  'persona':{'gender':gender,'ageRange':age,'identity':identity,'appearance':appearance,'personality':personality,'temperament':temperament,'motivation':motivation,'arc':arc,'relationships':relationships,'evidence':evidence},
  'image':{'style':'摄影写实（候选档）','prompt':f"{cp['render']}. Three-quarter bust portrait of {visual}, neutral background, soft directional light, cold fill. {cp['surface']}.",
           'promptLocal':local+'，中性背景，四分之三半身，柔和方向主光与冷色补光。','negativePrompt':cp['negative'],'tags':cp['tags'],'sheet':sheet},
  'voice':{'timbre':timbre,'pitch':pitch,'pace':pace,'accent':accent,'emotion':emotion,'referenceHint':hint,'prompt':voice_en,'promptLocal':timbre+'；'+pace+'；'+accent+'；'+emotion}})

ap=P['art']['photorealistic']
art={'source':TITLE,'style':'photorealistic','scenes':[{
 'id':'S01','name':outline['scenes'][0]['name'],'primary':True,
 'summary':'唯一舞台；前门来客可见、后门声源不可见，在同一轴线建立不确定性。门位、材质为制作假设。',
 'anchors':[{'name':'木质修表工作台','desc':'画面左侧，磨损木面（制作假设）'},
            {'name':'前门竖玻璃框','desc':'画面前右侧，同一固定位置（制作假设）'},
            {'name':'后门不透明门板','desc':'店后方始终关闭，不展示声源（制作假设）'}],
 'lighting':[{'state':'夜间灯亮','prompt':'Empty watch repair shop at 21:00, warm work lamp and dim cool light through the front doorway, no people.'},
             {'state':'夜间熄灯过渡','prompt':'Empty same watch repair shop, work lamp initially on then switched off, weak cool residual light, no person and no silhouette behind the closed rear door.'}],
 'image':{'prompt':f"{ap['render']}. Empty contemporary Chinese watch repair shop, no people, worn wooden workbench on left, glazed front door at right, opaque closed rear door at back. 21:00, warm work lamp, cool doorway fill.",
          'negativePrompt':ap['negative'],
          'sheet':f"ONE 16:9 landscape environment reference sheet, large main view plus bottom and right L-shaped detail strip, fixed door topology. {ap['render']}. {ap['surface']}. Empty scene, no people. Show lamp-on and lamp-off variants without changing geometry.",
          'tags':ap['tags']},'usage':{'episodes':[1],'beats':['警告与来客','悬疑升级']}}], 'props':[]}
props=[
 ('P01','旧怀表','原作核心警告和异常运动的载体，停九点十分，后走一格；不得推定走到九点十一分。',
  [('旧金属表壳','旧金属材质；具体划痕位置为制作假设'),('停表盘面','初始读数九点十分，不推定后来的新读数'),('内盖刻字区','原文别开后门，实际字形由后期叠加保证')],
  [('合上','Closed old pocket watch, handheld scale, worn metal shell.'),('打开停表','Open old pocket watch, handheld scale, stopped at 9:10, blank inner-lid engraving area reserved for postproduction.'),('走一格','Same open old pocket watch, handheld scale, one small tick of an unspecified hand, no asserted new clock reading.')],
  ['林禾'],'an old metal pocket watch, handheld scale, stopped at 9:10, open inner lid with blank engraving area for exact postproduction text'),
 ('P02','铜钥匙','袖口可见的哥哥工作室铜钥匙；来源和为何在袖口均未知。',
  [('铜材质','暖铜色与轻包浆，具体旧化为制作假设'),('钥匙形制','简单铜钥匙，无新增徽记或文字（制作假设）'),('袖口夹持','从湿袖口露出一部分，不展示交接过程')],
  [('独立参考','A simple copper key, handheld scale, warm patina, no emblem, on pure white background.')],['快递员'],
  'a simple copper key, handheld scale, warm patina, no emblem or lettering')]
for pid,name,summary,anchors,states,carried,visual in props:
 art['props'].append({'id':pid,'name':name,'scale':'手持级','summary':summary,
  'anchors':[{'name':a,'desc':d} for a,d in anchors], 'states':[{'state':s,'prompt':p+' Pure white background, no people, no hands.'} for s,p in states],
  'relatedScenes':['S01'],'carriedBy':carried,
  'image':{'prompt':f"{ap['render']}. {visual}, pure white background, no people, no hands.",
           'negativePrompt':ap['negative']+', hands, fingers',
           'sheet':f"ONE 16:9 landscape prop sheet, large three-quarter main view and bottom/right L-shaped details, pure white background. {ap['render']}. {ap['surface']}. {visual}. No people, no hands. State views share identical geometry.",
           'tags':ap['tags']},'usage':{'episodes':[1],'beats':['警告与来客','悬疑升级'] if pid=='P01' else ['悬疑升级']}})

# Each cut receives a nonempty contiguous range. No face is invented for VO.
actions=[
 ['店内时钟显示晚上九点，林禾完成收工动作。','旧怀表包裹停在工作台上，原文信息由后期字幕说明为失联三年的哥哥寄来。','林禾把旧怀表取到身前。'],
 ['林禾打开怀表。','表盘停在九点十分。','表盖内侧的警告进入视线，准确字形由后期叠加。'],
 ['前门敲门声打断安静。','林禾转向前门，湿透的快递员停在门口。'],
 ['快递员留在前门，湿衣保持一致。', {'speaker':'C02','line':'刚才送错了包裹，要取回怀表。','delivery':'平直略急，只陈述声称的送错，不证实真相'}],
 ['铜钥匙从快递员湿袖口露出。','林禾看见那是哥哥工作室的钥匙，没有发问；不解释钥匙如何到此。'],
 ['林禾视线回到旧怀表。','怀表突然走了一格。','林禾凝视表盘，不显示新读数。'],
 ['后门方向成为林禾注意的焦点，门保持关闭。', {'speaker':'VO','line':'小禾，是我。','delivery':'后门传来的熟悉声音，听感像哥哥；声源身份未知，不确认是哥哥；画内人物闭口'},'林禾听着，不回答。'],
 ['林禾握紧怀表。','她伸手关灯。','店内灯光熄灭，后门声源仍未入画。'],
]
flows=[]; ranges=[]
for k,beats in enumerate(actions):
 flows.append([{'action':b} if isinstance(b,str) else b for b in beats])
sc1=sum(flows[:6],[]); sc2=sum(flows[6:],[])
script={'source':TITLE,'params':{'charsPerSecond':4.5,'actionSeconds':2.5,'tolerance':0.15,'maxLineChars':35},
 'episodes':[{'ep':1,'targetSeconds':60,'hook':outline['episodes'][0]['hook'],'hookBeat':[1,3],
  'cliff':outline['episodes'][0]['suspense'],'beatsClaimed':['警告与来客','悬疑升级'],
  'scenes':[{'sceneId':'S01','lighting':'夜间灯亮','characters':['C01','C02'],'props':['P01','P02'],'flow':sc1},
            {'sceneId':'S01','lighting':'夜间熄灯过渡','characters':['C01'],'props':['P01'],'flow':sc2}]}]}

seconds=[7.5,7.5,7,8,7,8,7,8]
sizes=['medium','extreme-close','wide','medium','extreme-close','extreme-close','close','medium']
phrase={'medium':'medium shot','extreme-close':'extreme close-up','wide':'wide shot','close':'close-up'}
chars=[['C01'],[],['C01','C02'],['C02'],[],['C01'],['C01'],['C01']]
props_by_cut=[['P01'],['P01'],[],[],['P02'],['P01'],['P01'],['P01']]
frames=[
 'An adult East Asian woman with shoulder-length dark hair and grey work shirt at the worn wooden repair bench, old pocket watch in front of her, front glazed doorway on right, rear opaque door closed.',
 'An open old pocket watch dial stopped at 9:10, blank inner lid area reserved for exact engraved warning added in postproduction; hands are outside the crop.',
 'The same adult woman turns toward the front glazed doorway, where a soaked adult East Asian man in a navy delivery jacket stands; opaque rear door stays closed, no other person.',
 'The same soaked adult East Asian man in a navy delivery jacket remains at the front doorway, facing inward. No unexplained movement toward the rear door.',
 'A copper key partly caught in the soaked navy jacket cuff, same front doorway background out of focus; no face or hand in crop, no engraved emblem.',
 'The open old pocket watch held by the woman, dial remains at the initial stopped position at this keyframe; the tick occurs later, no claimed new clock reading.',
 'The same woman listens toward the closed opaque rear door, lips closed, nobody behind the door is shown, lamp initially remains on.',
 'The same woman holds the pocket watch firmly near her chest and reaches toward the lamp switch, lamp still on at this initial keyframe; rear door closed, no new person.',
]
motion=[
 'The woman finishes her closing routine and brings the old pocket watch closer. Do not add another arrival or a flashback.',
 'She opens the watch and observes the stopped 9:10 dial and the inner-lid warning. Leave enough time to read the warning added in postproduction; do not invent another inscription.',
 'Front-door knocking interrupts the room. The woman turns; the soaked courier remains at the front doorway. Keep both characters distinct.',
 'The soaked courier remains at the front doorway. (S1) An adult male Mandarin voice, low-middle register, brief plain delivery, says <d>[Chinese] 刚才送错了包裹，要取回怀表。</d> His claim is not established as truth.',
 'Reveal the copper key caught in the soaked sleeve. The woman notices it without a spoken question. No explanation or handover is shown.',
 'The woman looks back at the pocket watch. One unspecified hand makes a single small tick; do not infer a new reading or a supernatural cause.',
 '(S1) An unidentified familiar adult voice from the closed rear door says in an off-screen voiceover <d>[Chinese] 小禾，是我。</d> The visible woman listens while her lips remain completely closed. Do not identify or show the source.',
 'The woman grips the pocket watch, reaches to the switch and extinguishes the shop lamp. End in darkness with weak residual doorway light, keeping the voice source off-screen and the rear door closed.',
]
board={'source':TITLE,'style':'photorealistic','promptLang':'en',
 'params':{'maxSegmentSeconds':15,'minCutSeconds':2,'maxCutSeconds':8,'maxOnScreen':3,'tolerance':0},'episodes':[{'ep':1,'segments':[]}]}
cursor=1; tasks=[]; start=0; shot_rows=[]; timeline=[]
for seg_i in range(4):
 segid=f'E01-{seg_i+1:02d}'; cuts=[]; descriptions=[]; scene_index=1 if seg_i<3 else 2
 if seg_i==3: cursor=1
 for ci in range(2):
  k=seg_i*2+ci; stop=cursor+len(flows[k])-1
  cut={'beats':[cursor,stop],'seconds':seconds[k],'size':sizes[k],'camera':'Static Shot','characters':chars[k],'props':props_by_cut[k],
       'frame':f"Photorealistic live-action film still, {phrase[sizes[k]]}, portrait 9:16. {frames[k]} Cool muted palette, natural skin and material texture, no painting, no watermark, no borders.",
       'note':'仅制作候选，未生成；表针、刻字、持握和衣物状态需成图人工核对。'}
  cuts.append(cut)
  marker='[Shot 1]' if ci==0 else f'[Shot 2] At 00:{int(seconds[k-1]):02d}.{int(round((seconds[k-1]%1)*1000)):03d},'
  descriptions.append(f'{marker} Fully anchor composition and visible identities to <Picture {ci+1}>. Static Shot. '+motion[k])
  key=f'{segid}#{ci+1}'; frame=f'h3/{segid}/f{ci+1}.png'
  env='S01/夜间灯亮' if k<6 else 'S01/夜间熄灯过渡（参考起点仍灯亮）'
  refs=[env]+chars[k]+props_by_cut[k]
  tasks.append({'id':f'F{k+1:02d}','kind':'keyframe','shot':key,'output':frame,'status':'NOT_GENERATED','references_order':refs,
   'depends_on':['A-S01-LIT']+[f'A-{c}' for c in chars[k]]+[f'A-{p}' for p in props_by_cut[k]],
   'capability':'Qwen2.1 图像编辑作为待验证组合方案；Krea2仅待选，未实测；不声明多参考上限。',
   'retry_impacts':[f'V{seg_i+1:02d}',f'QC-{key}','邻接镜头连续性复核']})
  dlg=sum(len(b['line'])/4.5 for b in flows[k] if 'line' in b)
  act=sum('action' in b for b in flows[k])*2.5
  timeline.append({'shot':key,'start':start,'end':start+seconds[k],'seconds':seconds[k],'sceneIndex':scene_index,'beats':[cursor,stop],
     'estimatedDialogueSeconds':dlg,'estimatedActionSeconds':act,'reservedHoldSeconds':seconds[k]-dlg-act,
     'onScreen':chars[k],'props':props_by_cut[k],'aspectRatio':'9:16','status':'PLANNED_NOT_RENDERED'})
  shot_rows.append([key,start,start+seconds[k],seconds[k],'S01',scene_index,':'.join(map(str,[cursor,stop])),';'.join(chars[k]),';'.join(props_by_cut[k]),sizes[k],'Static Shot',';'.join(refs),
     f'先完成资产参考→F{k+1:02d}→V{seg_i+1:02d}→本镜与邻镜QC','Qwen2.1编辑候选；Krea2仅待选；H3视频仅有限小样证据',
     f'仅该关键帧、V{seg_i+1:02d}整段、该段音画与相邻镜连续性；不自动重做其他段','未生成',
     ' / '.join(b if isinstance(b,str) else b['line'] for b in actions[k])])
  cursor=stop+1; start+=seconds[k]
 alignment=f'How the reference pictures align with the target video — Picture 1 (from Shot 1) aligns with the 0.00-second mark of the target video; Picture 2 (from Shot 2) aligns with the {seconds[seg_i*2]:.2f}-second mark of the target video.'
 sound=['Quiet shop room tone, faint ordinary clock ambience. No off-screen footsteps or additional voices.',
        'Front-door knock, wet fabric movement, quiet room tone; no added dialogue.',
        'Subtle sleeve rustle, then a single small watch tick. No new warning sound or implied mechanism.',
        'Quiet room tone and a small switch click, ambience thins after lamp extinguishes. Do not repeat dialogue here.'][seg_i]
 board['episodes'][0]['segments'].append({'id':segid,'sceneIndex':scene_index,'cuts':cuts,
   'h3Prompt':alignment+'\n\nintegrated_multimodal_description:\n'+'\n'.join(descriptions)+'\n\noverall_soundscape: '+sound+'\n\nnon_diegetic_music: N/A.',
   'note':'15秒是制作请求候选，不代表附件单个5.167秒H3小样已证实该时长或多参考切点控制。'})

for name,doc in [('outline',outline),('cast',cast),('art',art),('script',script),('storyboard',board)]: dump(F/(name+'.json'),doc)
dump(F/'timeline.json',{'status':'AUTHOR_PLAN_NOT_VIDEO_MEASUREMENT','totalSeconds':start,'dialogueBasis':'非空白字符含标点/4.5；动作2.5秒每拍；保留停顿另计','shots':timeline,
 'postproductionText':[{'shot':'E01-01#1','text':'失联三年，哥哥寄来一只旧怀表。','durationSeconds':5,'placement':'独立后期叙事字幕，不伪装包裹原有文字'},
                       {'shot':'E01-01#2','text':'别开后门','durationSeconds':4,'placement':'怀表内盖刻字，后期贴合；不依赖图像模型字形'},
                       {'shot':'E01-03#1','text':'哥哥工作室的铜钥匙','durationSeconds':4,'placement':'后期主观认知字幕，不在钥匙上虚构铭文'}]})
dump(F/'identity-map.json',{'note':'制作侧映射，不是原schema字段；不按数组位置猜身份。背景提及的哥哥不建画内人脸；VO声源身份未知。',
 'characters':{'C01':'林禾','C02':'快递员'},'voices':{'VO':{'label':'后门熟悉声音','identity':'unknown','visible':False}}})
dump(F/'production.json',{'status':'OFFLINE_CANDIDATE_NO_SUBMISSIONS','aspectRatio':'9:16','targetSeconds':60,'maxFinalCuts':8,
 'assumptions':['现代中国城镇、林禾约28岁及服饰为制作假设；快递员男性约35岁为制作假设，原文未明示','唯一店内空间；前后门拓扑、台灯和陈设为制作假设','哥哥寄件、钥匙归属按原文处理；钥匙来历与门后身份未知','不新增角色或台词；快递员原文间接引语转成直接引语，未添加动机','9:16仅存制作侧配置和frame文本，不冒充原schema字段','摄影写实为新增候选枚举；原realistic是半写实厚涂，原版对照位于original-format'],
 'assets':[{'id':a,'status':'NOT_GENERATED','first':'独立参考资产提示词','capability':'Qwen2.1文生图/编辑仅候选；Krea2未实测',
            'retry_impacts':[t['id'] for t in tasks if a in t['depends_on']]} for a in ['A-S01-LIT','A-C01','A-C02','A-P01','A-P02']],
 'keyframes':tasks,
 'videos':[{'id':f'V{i+1:02d}','segment':f'E01-{i+1:02d}','secondsRequested':15,'picture_order':[f'F{2*i+1:02d}',f'F{2*i+2:02d}'],
            'depends_on':[f'F{2*i+1:02d}',f'F{2*i+2:02d}'],'status':'NOT_SUBMITTED','capability':'H3候选；只证实附件单个云端小样完成，15秒、多图定点、声音和竖屏未验证',
            'retry_impacts':['本段视频','本段对白对齐','与前后段接缝QC'],'retryRule':'不自动重提收费任务；先确认此前提交状态及费用，再由未来制作流程决定'} for i in range(4)],
 'costModel':{'actualCallsThisReview':0,'actualChargeThisReview':0,'plannedVideoCalls':4,'plannedKeyframeCalls':8,
              'minimumAssetReferences':5,'amount':'未知，不以历史小样98币外推15秒费用','batchNote':'sceneId|lighting分组仅排产复用参考；不能当作视频调用数或费用单'}})
with (F/'shots.csv').open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.writer(f);w.writerow(['shot','start_s','end_s','seconds','sceneId','sceneIndex','beats','characters','props','size','camera','references_in_order','generate_first_and_dependencies','capability_candidate','retry_impacts','status','content']);w.writerows(shot_rows)

# Original-schema control: keep original realistic style phrases. Still fails
# the original outline single-episode rule and default cut cadence on purpose.
O=presets('upstream/skills')
orig=F/'original-format';orig.mkdir(exist_ok=True)
for name,doc in [('outline',outline),('cast',cast),('art',art),('script',script),('storyboard',board)]:
 d=copy.deepcopy(doc)
 if name in ['cast','art','storyboard']: d['style']='realistic'
 if name=='cast':
  for c in d['characters']:
   for key in ['prompt','sheet']: c['image'][key]=c['image'][key].replace(P['character']['photorealistic']['render'],O['character']['realistic']['render'])
   c['image']['style']='原版半写实厚涂对照；不是摄影写实成品'
 if name=='art':
  for a in d['scenes']+d['props']:
   for key in ['prompt','sheet']: a['image'][key]=a['image'][key].replace(P['art']['photorealistic']['render'],O['art']['realistic']['render'])
 if name=='storyboard':
  del d['params']['maxCutSeconds']  # Original default of 5, deliberately incompatible.
  for s in d['episodes'][0]['segments']:
   for c in s['cuts']: c['frame']=c['frame'].replace('Photorealistic live-action film still','cinematic film still')
 dump(orig/(name+'.json'),d)
print('Built five complete candidate JSONs, original-format controls, 8-cut 60-second timeline and production dependency plan.')
