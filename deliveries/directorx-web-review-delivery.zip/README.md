# DirectorX 小说到分镜：离线审查交付候选

本包完成上传《先读我_测试指令.md》的**任务一**：审查五套 Skill，做有证据的局部修改，并以修表店短篇制作完整 JSON 和压力测试。只使用上传 ZIP；未访问用户电脑、外部知识库或收费服务，未登录或发布 GitHub。附件中的工具、并发、审批指令均作为审查对象，未被当作本会话指令执行。

**交付状态：离线候选可复现，不是已生成的视频。** 制作计划为 1 集、60 秒、9:16、8 镜、4 段、2 名画内角色、1 个实体场景、2 件道具。声音来自后门，但身份未知。钥匙来历没有补写。

## 先读这些文件

- [audit.md](audit.md)：10 个按影响排序的问题，证据、最小反例和已做修改。
- [fixtures/watch-shop/PLAN.md](fixtures/watch-shop/PLAN.md)：完整制作计划、台词与停顿预算、逐镜依赖及失败影响。
- [fixtures/watch-shop/](fixtures/watch-shop/)：原作、五份完整候选 JSON、原版格式对照、镜头 CSV、身份映射和制作侧配置。
- [tests/results/summary.json](tests/results/summary.json)：真实运行结果与退出码；原始日志同目录。
- [READING_INVENTORY.md](READING_INVENTORY.md)：实际读取范围、未通读及未使用材料。
- [UNVERIFIED.md](UNVERIFIED.md)：未执行或无法由本次检查证明的项目。

## 兼容性务必区分

| 路径 | 含义 |
| --- | --- |
| `upstream/skills/` | 上传的原始五套 Skill，逐字节保留，用来复现原始行为 |
| `candidate-skills/` | 同目录结构的审查候选；原始样例仍保留 |
| `patches/*.patch` | 针对 `skills/…` 的 unified diff；实际应用后与候选文件逐字节一致 |
| `fixtures/watch-shop/{outline,cast,art,script,storyboard}.json` | 候选规则下已通过 Node 校验的完整制作数据；没有媒体文件 |
| `fixtures/watch-shop/original-format/` | 用原版已有字段与 `realistic` 枚举的对照数据；原版 outline 和默认 storyboard **预期失败**，不是可投产版本 |

候选仅扩展已有 `style` 字段的枚举，增加 `photorealistic`，没有把新字段塞入原版 schema。原版资产的 `realistic` 是半写实厚涂，不等于摄影写实。主样例使用新增摄影档，只能由候选脚本校验；这点不是向后兼容声明。

另两项必要调整：单集允许 major 落在唯一一集；显式使用**已有** `maxCutSeconds: 8`，因为默认 8×5=40 秒装不下 60 秒。`aspectRatio`、身份映射、停顿时间和任务依赖只存在于另列的制作侧文件，不宣称属于上游 schema。

## 本地复现（无需安装依赖或配置密钥）

需 Node.js 18+、Python 3.10+、Git；本次实测 Node v24.19.0、Python 3.12.14。解压后在本目录运行：

```bash
python3 tests/verify_manifest.py
python3 tests/run_all.py
```

第一个命令核对收到的文件；第二个命令重新运行原版/候选自测、上传自带《渡口》五 JSON 的 CLI 校验、修表店正反例、独立检查、seed/render/export 以及补丁应用验证。原版已知失败使用**精确预期退出码**记录，不被写成原版通过。测试失败会返回非零；没有联网和生成步骤。

只跑新增检查：

```bash
node tests/regression.mjs
python3 tests/check_fixture.py
```

重新构建作者填写的 fixture（不调用模型、不生成图片）：

```bash
python3 tests/build_fixture.py
```

`run_all.py` 会更新结果日志与 Markdown、H3 提示词清单，所以重跑后原始 MANIFEST 的结果文件哈希会变化。这是预期行为；先校验原包，重跑后可用 `python3 tests/package.py` 重新建立清单及 ZIP。不要把重跑导致的哈希变化误报为原包损坏。

补丁使用方式：在上传项目的根目录（含 `skills/`）执行 `git apply --check <patch>` 再 `git apply <patch>`。每个补丁对应一个原文件，不要对已经替换为候选的目录再次应用。无需创建、重置或推送任何 Git 仓库。

## 已执行结果

| 检查 | 实际结果 |
| --- | --- |
| 原版自测 | outline 220、art 146、script 153、storyboard 185 通过；characters 因 CRLF 比较失败，后续断言未跑完 |
| 候选自测 | 220 / 313 / 146 / 153 / 185，合计 1,017 项通过 |
| 上传《渡口》五 JSON CLI 校验 | 五套均通过；不代表跨文件角色资产齐全或生成效果通过 |
| 修表店候选五 JSON CLI 校验 | 五套均通过；剧本估时 51.9 秒，分镜计划精确 60 秒 |
| 新增 Node 回归 | 20 组通过，含原版放过的错镜台词等反例 |
| Python 独立检查 | 458 项通过；11 个故障变体均按预期拒绝 |
| 补丁与导出 | 补丁实际应用后逐字节等于候选；导出 4 段提示词，8 张分镜图全部明确标缺失 |
| 图像 / TTS / 视频 / 收费 API | **未执行，调用 0，费用 0** |

这里的“通过”仅指明示范围内的确定性检查。没有实测配音速度、模型身份保持、H3 多参考按时刻锁帧、15 秒时长、9:16 服务参数或动态成片质量。任务二和三未执行，不作为任务一的前提。

## 目录

```text
README.md / audit.md / READING_INVENTORY.md / UNVERIFIED.md
LICENSE.upstream / SOURCES.md / MANIFEST.json
upstream/skills/             原始审查材料与自测
candidate-skills/            五套可审阅候选，保持原结构
patches/                    可实际应用的局部差异
fixtures/watch-shop/         原作、五 JSON、shots.csv、时间线、制作任务表
tests/                      零依赖检查、反例、真实日志、打包工具
prompts/                    可复用离线审查与返修指令
```

本包没有安装这些 Skill 到任何产品运行时；其原有运行时工具名和元数据未做通用平台适配，不能声称已安装可调用。

## 出处与许可证

唯一来源为本会话上传的 `DirectorX-WebGPT-Review.zip`。附件没有提供可独立确认的公开仓库 URL 或 commit，因此不捏造 GitHub 地址。`upstream/材料来源.json` 中本机路径只是附件出处说明，不曾访问。

原始代码随附 [LICENSE.upstream](LICENSE.upstream)，保持原 Apache License 2.0 正文和原有版权内容；候选是对这些文件的审查修改，不为第三方原作另写许可声明。新报告、fixture 与检查脚本的归属及发布由接收者自行安排；本 README 不替权利人增加授权。更多内容见 [SOURCES.md](SOURCES.md)。
