# 别开后门（附件短篇制作候选） · 美术设定集

> 画风：摄影写实（审查候选）

## 场景清单

| ID | 场景 | 类型 | 出现集 | 锚点 | 光照 | 变体 |
| --- | --- | --- | --- | --- | --- | --- |
| S01 | 修表店内（前门与后门同一空间） | 主场景 | 1 | 3 | 夜间灯亮、夜间熄灯过渡 | — |

---

## S01 修表店内（前门与后门同一空间）

唯一舞台；前门来客可见、后门声源不可见，在同一轴线建立不确定性。门位、材质为制作假设。

### 一致性锚点

1. **木质修表工作台** — 画面左侧，磨损木面（制作假设）
2. **前门竖玻璃框** — 画面前右侧，同一固定位置（制作假设）
3. **后门不透明门板** — 店后方始终关闭，不展示声源（制作假设）

### 光照与时段

- **夜间灯亮**：`Empty watch repair shop at 21:00, warm work lamp and dim cool light through the front doorway, no people.`
- **夜间熄灯过渡**：`Empty same watch repair shop, work lamp initially on then switched off, weak cool residual light, no person and no silhouette behind the closed rear door.`

### 出图提示词包

**主视角 EN**

```text
Photorealistic live-action environment and prop reference photography, grounded perspective, natural material texture. Empty contemporary Chinese watch repair shop, no people, worn wooden workbench on left, glazed front door at right, opaque closed rear door at back. 21:00, warm work lamp, cool doorway fill.
```

**反向提示词**

```text
people, human figures, crowds, painting, illustration, cartoon, warped geometry, text, watermark, signature
```

**设定图 EN**

```text
ONE 16:9 landscape environment reference sheet, large main view plus bottom and right L-shaped detail strip, fixed door topology. Photorealistic live-action environment and prop reference photography, grounded perspective, natural material texture. Worn wood grain, patina on metal, natural shadows, no brush texture. Empty scene, no people. Show lamp-on and lamp-off variants without changing geometry.
```

`photorealistic`, `live-action`, `reference sheet`, `natural materials`

---

## 道具清单

| ID | 道具 | 尺度 | 状态 | 关联场景 | 出现集 | 锚点 |
| --- | --- | --- | --- | --- | --- | --- |
| P01 | 旧怀表 | 手持级 | 合上、打开停表、走一格 | S01 | 1 | 3 |
| P02 | 铜钥匙 | 手持级 | 独立参考 | S01 | 1 | 3 |

---

## P01 旧怀表

原作核心警告和异常运动的载体，停九点十分，后走一格；不得推定走到九点十一分。

### 一致性锚点

1. **旧金属表壳** — 旧金属材质；具体划痕位置为制作假设
2. **停表盘面** — 初始读数九点十分，不推定后来的新读数
3. **内盖刻字区** — 原文别开后门，实际字形由后期叠加保证

### 状态变体

- **合上**：`Closed old pocket watch, handheld scale, worn metal shell. Pure white background, no people, no hands.`
- **打开停表**：`Open old pocket watch, handheld scale, stopped at 9:10, blank inner-lid engraving area reserved for postproduction. Pure white background, no people, no hands.`
- **走一格**：`Same open old pocket watch, handheld scale, one small tick of an unspecified hand, no asserted new clock reading. Pure white background, no people, no hands.`

### 出图提示词包

**主视角 EN**

```text
Photorealistic live-action environment and prop reference photography, grounded perspective, natural material texture. an old metal pocket watch, handheld scale, stopped at 9:10, open inner lid with blank engraving area for exact postproduction text, pure white background, no people, no hands.
```

**反向提示词**

```text
people, human figures, crowds, painting, illustration, cartoon, warped geometry, text, watermark, signature, hands, fingers
```

**设定图 EN**

```text
ONE 16:9 landscape prop sheet, large three-quarter main view and bottom/right L-shaped details, pure white background. Photorealistic live-action environment and prop reference photography, grounded perspective, natural material texture. Worn wood grain, patina on metal, natural shadows, no brush texture. an old metal pocket watch, handheld scale, stopped at 9:10, open inner lid with blank engraving area for exact postproduction text. No people, no hands. State views share identical geometry.
```

---

## P02 铜钥匙

袖口可见的哥哥工作室铜钥匙；来源和为何在袖口均未知。

### 一致性锚点

1. **铜材质** — 暖铜色与轻包浆，具体旧化为制作假设
2. **钥匙形制** — 简单铜钥匙，无新增徽记或文字（制作假设）
3. **袖口夹持** — 从湿袖口露出一部分，不展示交接过程

### 状态变体

- **独立参考**：`A simple copper key, handheld scale, warm patina, no emblem, on pure white background. Pure white background, no people, no hands.`

### 出图提示词包

**主视角 EN**

```text
Photorealistic live-action environment and prop reference photography, grounded perspective, natural material texture. a simple copper key, handheld scale, warm patina, no emblem or lettering, pure white background, no people, no hands.
```

**反向提示词**

```text
people, human figures, crowds, painting, illustration, cartoon, warped geometry, text, watermark, signature, hands, fingers
```

**设定图 EN**

```text
ONE 16:9 landscape prop sheet, large three-quarter main view and bottom/right L-shaped details, pure white background. Photorealistic live-action environment and prop reference photography, grounded perspective, natural material texture. Worn wood grain, patina on metal, natural shadows, no brush texture. a simple copper key, handheld scale, warm patina, no emblem or lettering. No people, no hands. State views share identical geometry.
```

