# 别开后门（附件短篇制作候选） · 分镜（第 1 集）

## E01

> 4 段 8 切 · 共 60 秒 / 目标 60 秒

### E01-01 · 修表店内（前门与后门同一空间）（夜间灯亮） · 15 秒 · 2 个分镜

| 切 | 起点 | 秒 | 景别 | 运镜 | 画面 | 人物 |
| --- | --- | --- | --- | --- | --- | --- |
| #1 | 0.00s | 7.5 | 中景 | Static Shot（固定） | 店内时钟显示晚上九点，林禾完成收工动作。 旧怀表包裹停在工作台上，原文信息由后期字幕说明为失联三年的哥哥寄来。 林禾把旧怀表取到身前。 | 林禾 |
| #2 | 7.50s | 7.5 | 大特写 | Static Shot（固定） | 林禾打开怀表。 表盘停在九点十分。 表盖内侧的警告进入视线，准确字形由后期叠加。 |  |

**H3 视频提示词**

```text
How the reference pictures align with the target video — Picture 1 (from Shot 1) aligns with the 0.00-second mark of the target video; Picture 2 (from Shot 2) aligns with the 7.50-second mark of the target video.

integrated_multimodal_description:
[Shot 1] Fully anchor composition and visible identities to <Picture 1>. Static Shot. The woman finishes her closing routine and brings the old pocket watch closer. Do not add another arrival or a flashback.
[Shot 2] At 00:07.500, Fully anchor composition and visible identities to <Picture 2>. Static Shot. She opens the watch and observes the stopped 9:10 dial and the inner-lid warning. Leave enough time to read the warning added in postproduction; do not invent another inscription.

overall_soundscape: Quiet shop room tone, faint ordinary clock ambience. No off-screen footsteps or additional voices.

non_diegetic_music: N/A.
```

### E01-02 · 修表店内（前门与后门同一空间）（夜间灯亮） · 15 秒 · 2 个分镜

| 切 | 起点 | 秒 | 景别 | 运镜 | 画面 | 人物 |
| --- | --- | --- | --- | --- | --- | --- |
| #1 | 0.00s | 7 | 全景 | Static Shot（固定） | 前门敲门声打断安静。 林禾转向前门，湿透的快递员停在门口。 | 林禾、快递员 |
| #2 | 7.00s | 8 | 中景 | Static Shot（固定） | 快递员留在前门，湿衣保持一致。 快递员：「刚才送错了包裹，要取回怀表。」 | 快递员 |

**H3 视频提示词**

```text
How the reference pictures align with the target video — Picture 1 (from Shot 1) aligns with the 0.00-second mark of the target video; Picture 2 (from Shot 2) aligns with the 7.00-second mark of the target video.

integrated_multimodal_description:
[Shot 1] Fully anchor composition and visible identities to <Picture 1>. Static Shot. Front-door knocking interrupts the room. The woman turns; the soaked courier remains at the front doorway. Keep both characters distinct.
[Shot 2] At 00:07.000, Fully anchor composition and visible identities to <Picture 2>. Static Shot. The soaked courier remains at the front doorway. (S1) An adult male Mandarin voice, low-middle register, brief plain delivery, says <d>[Chinese] 刚才送错了包裹，要取回怀表。</d> His claim is not established as truth.

overall_soundscape: Front-door knock, wet fabric movement, quiet room tone; no added dialogue.

non_diegetic_music: N/A.
```

### E01-03 · 修表店内（前门与后门同一空间）（夜间灯亮） · 15 秒 · 2 个分镜

| 切 | 起点 | 秒 | 景别 | 运镜 | 画面 | 人物 |
| --- | --- | --- | --- | --- | --- | --- |
| #1 | 0.00s | 7 | 大特写 | Static Shot（固定） | 铜钥匙从快递员湿袖口露出。 林禾看见那是哥哥工作室的钥匙，没有发问；不解释钥匙如何到此。 |  |
| #2 | 7.00s | 8 | 大特写 | Static Shot（固定） | 林禾视线回到旧怀表。 怀表突然走了一格。 林禾凝视表盘，不显示新读数。 | 林禾 |

**H3 视频提示词**

```text
How the reference pictures align with the target video — Picture 1 (from Shot 1) aligns with the 0.00-second mark of the target video; Picture 2 (from Shot 2) aligns with the 7.00-second mark of the target video.

integrated_multimodal_description:
[Shot 1] Fully anchor composition and visible identities to <Picture 1>. Static Shot. Reveal the copper key caught in the soaked sleeve. The woman notices it without a spoken question. No explanation or handover is shown.
[Shot 2] At 00:07.000, Fully anchor composition and visible identities to <Picture 2>. Static Shot. The woman looks back at the pocket watch. One unspecified hand makes a single small tick; do not infer a new reading or a supernatural cause.

overall_soundscape: Subtle sleeve rustle, then a single small watch tick. No new warning sound or implied mechanism.

non_diegetic_music: N/A.
```

### E01-04 · 修表店内（前门与后门同一空间）（夜间熄灯过渡） · 15 秒 · 2 个分镜

| 切 | 起点 | 秒 | 景别 | 运镜 | 画面 | 人物 |
| --- | --- | --- | --- | --- | --- | --- |
| #1 | 0.00s | 7 | 特写 | Static Shot（固定） | 后门方向成为林禾注意的焦点，门保持关闭。 画外音：「小禾，是我。」 林禾听着，不回答。 | 林禾 |
| #2 | 7.00s | 8 | 中景 | Static Shot（固定） | 林禾握紧怀表。 她伸手关灯。 店内灯光熄灭，后门声源仍未入画。 | 林禾 |

**H3 视频提示词**

```text
How the reference pictures align with the target video — Picture 1 (from Shot 1) aligns with the 0.00-second mark of the target video; Picture 2 (from Shot 2) aligns with the 7.00-second mark of the target video.

integrated_multimodal_description:
[Shot 1] Fully anchor composition and visible identities to <Picture 1>. Static Shot. (S1) An unidentified familiar adult voice from the closed rear door says in an off-screen voiceover <d>[Chinese] 小禾，是我。</d> The visible woman listens while her lips remain completely closed. Do not identify or show the source.
[Shot 2] At 00:07.000, Fully anchor composition and visible identities to <Picture 2>. Static Shot. The woman grips the pocket watch, reaches to the switch and extinguishes the shop lamp. End in darkness with weak residual doorway light, keeping the voice source off-screen and the rear door closed.

overall_soundscape: Quiet room tone and a small switch click, ambience thins after lamp extinguishes. Do not repeat dialogue here.

non_diegetic_music: N/A.
```

## 生成批次单

| 场景 | 光照 | 段 | 需要的角色 | 道具 |
| --- | --- | --- | --- | --- |
| S01 修表店内（前门与后门同一空间） | 夜间灯亮 | E01-01、E01-02、E01-03 | 林禾、快递员 | 旧怀表、铜钥匙 |
| S01 修表店内（前门与后门同一空间） | 夜间熄灯过渡 | E01-04 | 林禾 | 旧怀表 |

## 配音对齐单

| 段 · 切 | 说话人 | 台词 | 台词秒数 |
| --- | --- | --- | --- |
| E01-02#2 | 快递员 | 刚才送错了包裹，要取回怀表。 | 3.1 |
| E01-04#1 | 画外音 | 小禾，是我。 | 1.3 |

