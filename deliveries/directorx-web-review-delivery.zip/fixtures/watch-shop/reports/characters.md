# 别开后门（附件短篇制作候选） — 角色表

共 2 位角色：林禾、快递员

## 故事摘要

晚上九点，一间修表店即将关门。修表师收到失联三年哥哥寄来的旧怀表。前门的湿透快递员要求取回怀表，店内外的信息逐渐相互矛盾。

---

## 林禾（小禾）

> 主角 · 准备关店却被怀表线索打断的修表师。

### 画像

- **性别**：女（原文她）
- **年龄**：约28岁（制作假设）
- **身份**：修表师；现代中国城镇为制作假设
- 细致 / 克制 / 警觉

**外貌**　成年东亚女性，深色齐肩发，灰色工作衫（制作假设）；不以外貌补充身世

**性情**　安静的观察先于提问

**动机**　护住怀表并判断危险，内心动机不再补写

**人物弧光**　从例行收工到握表关灯

**关系**

- 快递员 — 在前门要求取回怀表，互不信任尚未得到证实

**原文依据**

> 修表师林禾准备关店。

> 她握紧怀表，关掉了店里的灯。

### 形象

**画风**　摄影写实（候选档）

`photorealistic`, `live-action`, `character sheet`, `natural texture`

**出图提示词 EN**

```text
Photorealistic live-action character reference photography, anatomically grounded, natural skin and fabric texture. Three-quarter bust portrait of an adult East Asian Chinese woman, about twenty-eight, contemporary small-town China, shoulder-length dark hair, a grey work shirt, neutral background, soft directional light, cold fill. Natural skin pores, slight facial asymmetry, individual loose hair strands, worn fabric weave; no brush texture.
```

成年东亚女性，现代中国城镇，深色齐肩发、灰色工作衫；年龄外观与地域为制作假设，中性背景，四分之三半身，柔和方向主光与冷色补光。

**反向提示词**

```text
painting, illustration, cartoon, plastic skin, extra fingers, malformed hands, text, watermark, signature
```

**角色设定图提示词 EN**

```text
Single character model sheet on ONE 16:9 landscape canvas, pure white background. Photorealistic live-action character reference photography, anatomically grounded, natural skin and fabric texture. an adult East Asian Chinese woman, about twenty-eight, contemporary small-town China, shoulder-length dark hair, a grey work shirt. Natural skin pores, slight facial asymmetry, individual loose hair strands, worn fabric weave; no brush texture. LEFT ZONE about 34% of the canvas width: complete bust portrait, face identity master. RIGHT-TOP ZONE: three full-body front, side and rear views, same face and clothes. RIGHT-BOTTOM ZONE: four isolated fabric and hair details. thin hairline rules. PROPORTIONS ARE CRITICAL: equal figure height and head-to-body ratio; feet on one baseline. If space is tight, the detail studies give way, not the figures. LEFT ZONE: soft directional portrait key light. RIGHT ZONES: flat even orthographic lighting, no cast shadows.
```

### 声音

- **音色**：中音区女声，质地清晰而克制
- **音高**：中
- **语速**：适中，遇异常留停顿
- **口音**：普通话（制作假设）
- **情绪**：警觉但不惊叫
- **类比**：像静听细小表针声的修理者

**音色提示词 EN**

```text
Adult female Mandarin voice, clear middle register, restrained, moderate pace, precise articulation. No spoken lines are assigned in this fixture.
```

中音区女声，质地清晰而克制；适中，遇异常留停顿；普通话（制作假设）；警觉但不惊叫

---

## 快递员

> 龙套 · 湿透的来客索回怀表，袖口夹着铜钥匙。

### 画像

- **性别**：男（制作假设，原文未明示）
- **年龄**：约35岁（制作假设）
- **身份**：快递员；现代中国城镇为制作假设
- 简短 / 急促 / 难辨意图

**外貌**　成年东亚男性，短发、深蓝配送外套；衣物浑身湿透为原文，其余为制作假设

**性情**　话语平直，未证实善恶

**动机**　声称送错包裹，要取回怀表；真实目的未知

**人物弧光**　功能性角色，不增转变

**关系**

- 林禾 — 前门索回怀表的对象

**原文依据**

> 一名浑身湿透的快递员站在前门

> 他的袖口夹着哥哥工作室的铜钥匙

### 形象

**画风**　摄影写实（候选档）

`photorealistic`, `live-action`, `character sheet`, `natural texture`

**出图提示词 EN**

```text
Photorealistic live-action character reference photography, anatomically grounded, natural skin and fabric texture. Three-quarter bust portrait of an adult East Asian Chinese man, about thirty-five, contemporary small-town China, short dark hair, a soaked navy delivery jacket, neutral background, soft directional light, cold fill. Natural skin pores, slight facial asymmetry, individual loose hair strands, worn fabric weave; no brush texture.
```

成年东亚男性，现代中国城镇，短发、湿透深蓝配送外套；年龄外观与地域为制作假设，中性背景，四分之三半身，柔和方向主光与冷色补光。

**反向提示词**

```text
painting, illustration, cartoon, plastic skin, extra fingers, malformed hands, text, watermark, signature
```

**角色设定图提示词 EN**

```text
Single character model sheet on ONE 16:9 landscape canvas, pure white background. Photorealistic live-action character reference photography, anatomically grounded, natural skin and fabric texture. an adult East Asian Chinese man, about thirty-five, contemporary small-town China, short dark hair, a soaked navy delivery jacket. Natural skin pores, slight facial asymmetry, individual loose hair strands, worn fabric weave; no brush texture. LEFT ZONE about 34% of the canvas width: complete bust portrait, face identity master. RIGHT-TOP ZONE: three full-body front, side and rear views, same face and clothes. RIGHT-BOTTOM ZONE: four isolated fabric and hair details. thin hairline rules. PROPORTIONS ARE CRITICAL: equal figure height and head-to-body ratio; feet on one baseline. If space is tight, the detail studies give way, not the figures. LEFT ZONE: soft directional portrait key light. RIGHT ZONES: flat even orthographic lighting, no cast shadows.
```

### 声音

- **音色**：中低音男声，话语简短
- **音高**：中低
- **语速**：正常略急，保持可辨
- **口音**：普通话（制作假设）
- **情绪**：克制，意图不明
- **类比**：像门口要求更正配送的来客，不演成已证实反派

**音色提示词 EN**

```text
Adult male Mandarin voice, low-middle register, plain brief delivery, moderate pace, intent ambiguous, not a theatrical villain.
```

中低音男声，话语简短；正常略急，保持可辨；普通话（制作假设）；克制，意图不明

