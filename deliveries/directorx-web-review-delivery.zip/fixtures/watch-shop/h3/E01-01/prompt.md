# E01-01 · H3 提示词

首帧 = **f1.png**。图片按 Picture 序号挂载：

- Picture 1 = f1.png（**首帧**，钉 0.00 秒）
- Picture 2 = f2.png（钉 7.50 秒）

---

How the reference pictures align with the target video — Picture 1 (from Shot 1) aligns with the 0.00-second mark of the target video; Picture 2 (from Shot 2) aligns with the 7.50-second mark of the target video.

integrated_multimodal_description:
[Shot 1] Fully anchor composition and visible identities to <Picture 1>. Static Shot. The woman finishes her closing routine and brings the old pocket watch closer. Do not add another arrival or a flashback.
[Shot 2] At 00:07.500, Fully anchor composition and visible identities to <Picture 2>. Static Shot. She opens the watch and observes the stopped 9:10 dial and the inner-lid warning. Leave enough time to read the warning added in postproduction; do not invent another inscription.

overall_soundscape: Quiet shop room tone, faint ordinary clock ambience. No off-screen footsteps or additional voices.

non_diegetic_music: N/A.
