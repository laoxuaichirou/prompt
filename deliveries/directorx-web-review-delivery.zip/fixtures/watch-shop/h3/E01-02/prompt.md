# E01-02 · H3 提示词

首帧 = **f1.png**。图片按 Picture 序号挂载：

- Picture 1 = f1.png（**首帧**，钉 0.00 秒）
- Picture 2 = f2.png（钉 7.00 秒）

---

How the reference pictures align with the target video — Picture 1 (from Shot 1) aligns with the 0.00-second mark of the target video; Picture 2 (from Shot 2) aligns with the 7.00-second mark of the target video.

integrated_multimodal_description:
[Shot 1] Fully anchor composition and visible identities to <Picture 1>. Static Shot. Front-door knocking interrupts the room. The woman turns; the soaked courier remains at the front doorway. Keep both characters distinct.
[Shot 2] At 00:07.000, Fully anchor composition and visible identities to <Picture 2>. Static Shot. The soaked courier remains at the front doorway. (S1) An adult male Mandarin voice, low-middle register, brief plain delivery, says <d>[Chinese] 刚才送错了包裹，要取回怀表。</d> His claim is not established as truth.

overall_soundscape: Front-door knock, wet fabric movement, quiet room tone; no added dialogue.

non_diegetic_music: N/A.
