# E01-03 · H3 提示词

首帧 = **f1.png**。图片按 Picture 序号挂载：

- Picture 1 = f1.png（**首帧**，钉 0.00 秒）
- Picture 2 = f2.png（钉 7.00 秒）

---

How the reference pictures align with the target video — Picture 1 (from Shot 1) aligns with the 0.00-second mark of the target video; Picture 2 (from Shot 2) aligns with the 7.00-second mark of the target video.

integrated_multimodal_description:
[Shot 1] Fully anchor composition and visible identities to <Picture 1>. Static Shot. Reveal the copper key caught in the soaked sleeve. The woman notices it without a spoken question. No explanation or handover is shown.
[Shot 2] At 00:07.000, Fully anchor composition and visible identities to <Picture 2>. Static Shot. The woman looks back at the pocket watch. One unspecified hand makes a single small tick; do not infer a new reading or a supernatural cause.

overall_soundscape: Subtle sleeve rustle, then a single small watch tick. No new warning sound or implied mechanism.

non_diegetic_music: N/A.
