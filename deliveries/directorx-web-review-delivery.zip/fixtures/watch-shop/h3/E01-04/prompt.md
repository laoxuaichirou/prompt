# E01-04 · H3 提示词

首帧 = **f1.png**。图片按 Picture 序号挂载：

- Picture 1 = f1.png（**首帧**，钉 0.00 秒）
- Picture 2 = f2.png（钉 7.00 秒）

---

How the reference pictures align with the target video — Picture 1 (from Shot 1) aligns with the 0.00-second mark of the target video; Picture 2 (from Shot 2) aligns with the 7.00-second mark of the target video.

integrated_multimodal_description:
[Shot 1] Fully anchor composition and visible identities to <Picture 1>. Static Shot. (S1) An unidentified familiar adult voice from the closed rear door says in an off-screen voiceover <d>[Chinese] 小禾，是我。</d> The visible woman listens while her lips remain completely closed. Do not identify or show the source.
[Shot 2] At 00:07.000, Fully anchor composition and visible identities to <Picture 2>. Static Shot. The woman grips the pocket watch, reaches to the switch and extinguishes the shop lamp. End in darkness with weak residual doorway light, keeping the voice source off-screen and the rear door closed.

overall_soundscape: Quiet room tone and a small switch click, ambience thins after lamp extinguishes. Do not repeat dialogue here.

non_diegetic_music: N/A.
