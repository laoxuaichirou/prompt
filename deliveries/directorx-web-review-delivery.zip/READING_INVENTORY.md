# 实际读取与未读取范围

只使用上传 ZIP；未访问出处元数据中的本机路径、外部知识库或任何收费服务。

**读取失败：无。** 下表明确区分全文、重点片段、执行、只解析和未使用；执行自测意味着程序读取完整源码，不等于人工逐行通读。core/source-materials是重复汇编，只索引，不能说已全文审查。

先读取任务指令及出处、五个Skill工作流程与五个schema；再定位验证器、运行原自测，按失败定位相关代码。以下逐文件范围即本报告证据覆盖。

| 上传包相对路径 | 实际范围 |
| --- | --- |
| `LICENSE.upstream` | 保留原许可证字节；未作法律解释 |
| `core-materials.md` | 仅开头与FILE/标题索引；作为重复汇编未全文通读，以独立skills文件为证据 |
| `materials/canvas-scene-bindings.candidate.json` | 未读取内容/未查看图片：任务二和三本次未执行；仅统计条目与哈希 |
| `materials/qwen-A-review.json` | 未读取内容/未查看图片：任务二和三本次未执行；仅统计条目与哈希 |
| `materials/qwen21-edit-B.json` | 未读取内容/未查看图片：任务二和三本次未执行；仅统计条目与哈希 |
| `materials/qwen21-edit.json` | 未读取内容/未查看图片：任务二和三本次未执行；仅统计条目与哈希 |
| `materials/qwen21-product-blue-B.png` | 未读取内容/未查看图片：任务二和三本次未执行；仅统计条目与哈希 |
| `materials/qwen21-product-blue.png` | 未读取内容/未查看图片：任务二和三本次未执行；仅统计条目与哈希 |
| `materials/source-cup.png` | 未读取内容/未查看图片：任务二和三本次未执行；仅统计条目与哈希 |
| `skills/novel-art/SKILL.md` | 读取主流程与约束；知识库目录只按索引查看，未访问任何外部资源 |
| `skills/novel-art/examples/渡口-art.json` | JSON全文解析；ID/类型/角色场景道具及首集样本抽查；实际跑对应CLI和依赖自测，不声称逐字人工审美审读 |
| `skills/novel-art/references/prop-pass.md` | 全文读取相关参考说明，未执行其中生成或本机命令 |
| `skills/novel-art/references/report-style.md` | 可读取但未通读：与任务一核心检查无直接依赖；仅归档和哈希 |
| `skills/novel-art/references/scene-pass.md` | 全文读取相关参考说明，未执行其中生成或本机命令 |
| `skills/novel-art/references/schema.md` | 全文读取真实结构说明，与代码门对照；不是正式JSON Schema文件 |
| `skills/novel-art/references/sheet.md` | 可读取但未通读：与任务一核心检查无直接依赖；仅归档和哈希 |
| `skills/novel-art/scripts/novel-art.mjs` | 源码重点阅读：20–335：预设、seed、门和校验；CLI通过实际执行核对；其余渲染未逐行通读 |
| `skills/novel-art/scripts/selftest.mjs` | 实际运行并读完整结果；源码只抽看关键断言（characters前120行及风格/渲染断言索引），不是逐行人工通读 |
| `skills/novel-characters/SKILL.md` | 读取主流程与约束；知识库目录只按索引查看，未访问任何外部资源 |
| `skills/novel-characters/examples/渡口-cast.json` | JSON全文解析；ID/类型/角色场景道具及首集样本抽查；实际跑对应CLI和依赖自测，不声称逐字人工审美审读 |
| `skills/novel-characters/examples/渡口-cast.md` | 可读取但未通读：与任务一核心检查无直接依赖；仅归档和哈希 |
| `skills/novel-characters/examples/渡口.txt` | 字节与换行读取，供真实引文、chunk和自测；未将本短篇另做压力改编 |
| `skills/novel-characters/references/profile-pass.md` | 全文读取相关参考说明，未执行其中生成或本机命令 |
| `skills/novel-characters/references/report-style.md` | 可读取但未通读：与任务一核心检查无直接依赖；仅归档和哈希 |
| `skills/novel-characters/references/roster-pass.md` | 可读取但未通读：与任务一核心检查无直接依赖；仅归档和哈希 |
| `skills/novel-characters/references/schema.md` | 全文读取真实结构说明，与代码门对照；不是正式JSON Schema文件 |
| `skills/novel-characters/references/sheet.md` | 可读取但未通读：与任务一核心检查无直接依赖；仅归档和哈希 |
| `skills/novel-characters/references/style-presets.md` | 全文读取相关参考说明，未执行其中生成或本机命令 |
| `skills/novel-characters/scripts/novel-characters.mjs` | 源码重点阅读：1–240、450–640、1530–1795附近：分块、预设、校验、CLI；渲染只抽看，未通读全部HTML/CSS |
| `skills/novel-characters/scripts/selftest.mjs` | 实际运行并读完整结果；源码只抽看关键断言（characters前120行及风格/渲染断言索引），不是逐行人工通读 |
| `skills/novel-outline/SKILL.md` | 读取主流程与约束；知识库目录只按索引查看，未访问任何外部资源 |
| `skills/novel-outline/examples/渡口-outline.json` | JSON全文解析；ID/类型/角色场景道具及首集样本抽查；实际跑对应CLI和依赖自测，不声称逐字人工审美审读 |
| `skills/novel-outline/references/episode-pass.md` | 可读取但未通读：与任务一核心检查无直接依赖；仅归档和哈希 |
| `skills/novel-outline/references/outline-pass.md` | 全文读取相关参考说明，未执行其中生成或本机命令 |
| `skills/novel-outline/references/report-style.md` | 可读取但未通读：与任务一核心检查无直接依赖；仅归档和哈希 |
| `skills/novel-outline/references/schema.md` | 全文读取真实结构说明，与代码门对照；不是正式JSON Schema文件 |
| `skills/novel-outline/references/volume-pass.md` | 可读取但未通读：与任务一核心检查无直接依赖；仅归档和哈希 |
| `skills/novel-outline/scripts/novel-outline.mjs` | 源码重点阅读：1–475：常量、质量门、校验、引用；其余CLI/渲染通过执行结果核对，未逐行通读 |
| `skills/novel-outline/scripts/selftest.mjs` | 实际运行并读完整结果；源码只抽看关键断言（characters前120行及风格/渲染断言索引），不是逐行人工通读 |
| `skills/novel-script/SKILL.md` | 读取主流程与约束；知识库目录只按索引查看，未访问任何外部资源 |
| `skills/novel-script/examples/渡口-script.json` | JSON全文解析；ID/类型/角色场景道具及首集样本抽查；实际跑对应CLI和依赖自测，不声称逐字人工审美审读 |
| `skills/novel-script/references/report-style.md` | 可读取但未通读：与任务一核心检查无直接依赖；仅归档和哈希 |
| `skills/novel-script/references/schema.md` | 全文读取真实结构说明，与代码门对照；不是正式JSON Schema文件 |
| `skills/novel-script/references/script-pass.md` | 全文读取相关参考说明，未执行其中生成或本机命令 |
| `skills/novel-script/scripts/novel-script.mjs` | 源码重点阅读：1–329、namer关键行：计时、质量门、校验、seed与名称映射；渲染通过执行结果核对 |
| `skills/novel-script/scripts/selftest.mjs` | 实际运行并读完整结果；源码只抽看关键断言（characters前120行及风格/渲染断言索引），不是逐行人工通读 |
| `skills/novel-storyboard/SKILL.md` | 读取主流程与约束；知识库目录只按索引查看，未访问任何外部资源 |
| `skills/novel-storyboard/examples/渡口-storyboard.json` | JSON全文解析；ID/类型/角色场景道具及首集样本抽查；实际跑对应CLI和依赖自测，不声称逐字人工审美审读 |
| `skills/novel-storyboard/references/frame.md` | 全文读取相关参考说明，未执行其中生成或本机命令 |
| `skills/novel-storyboard/references/h3-prompt.md` | 全文读取相关参考说明，未执行其中生成或本机命令 |
| `skills/novel-storyboard/references/report-style.md` | 可读取但未通读：与任务一核心检查无直接依赖；仅归档和哈希 |
| `skills/novel-storyboard/references/schema.md` | 全文读取真实结构说明，与代码门对照；不是正式JSON Schema文件 |
| `skills/novel-storyboard/references/storyboard-pass.md` | 全文读取相关参考说明，未执行其中生成或本机命令 |
| `skills/novel-storyboard/scripts/novel-storyboard.mjs` | 源码重点阅读：1–640、1400–1505附近：计时、分镜门、H3、导出、CLI；报告常量按关键词抽查，渲染模板未逐行通读 |
| `skills/novel-storyboard/scripts/selftest.mjs` | 实际运行并读完整结果；源码只抽看关键断言（characters前120行及风格/渲染断言索引），不是逐行人工通读 |
| `source-materials.md` | 仅开头与FILE/标题索引；作为重复汇编未全文通读，以独立skills文件为证据 |
| `先读我_测试指令.md` | 全文读取；作为用户请求指定的任务范围，材料内部Skill指令仍只作审查对象 |
| `材料来源.json` | 全文读取；本机路径仅作背景，未访问 |

全部输入条目的字节数和SHA256见 tests/input-inventory.json。未通读的参考文档/HTML报告没有被拿来证明本文结论；可选任务图片也未伪称视觉审查过。
