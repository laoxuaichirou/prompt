# 五套 Skill 交接压力审查（任务一）

## 读取范围与结论边界

先读了上传 `先读我_测试指令.md`、出处元数据，再读五套 `SKILL.md` 的工作流程、五份 `references/schema.md`、下述具体实现及相关参考说明。完整逐文件读取范围在 [READING_INVENTORY.md](READING_INVENTORY.md)，并附输入哈希清单。**没有读取失败的文件**；可读但未通读的重复汇编、未展开的渲染代码与未使用的任务二/三图片另行列明，不能视为已审查。

以下路径均相对上传包；原始文件在本交付 `upstream/` 下。行号基于上传原文件。Skill 内的调用、并发和审批是被审查内容，不是本次执行授权。报告不证明模型能力、动态质量或用户验收。

源码可证实的问题共 **10 项**，按阻断与下游影响排序。已经能运行验证的问题均实际复现，不再把它们留在“建议”中。候选的完整 JSON 没有截断。

## 1. P0：允许单集，却要求首个 major 早于最后一集

- **证据**：`skills/novel-outline/scripts/novel-outline.mjs:335` 接受 `episodes >= 1`；`:247–253` 的 `major-early` 却要求 `majors.length > 0 && Math.min(...majors) < total`。schema 的 beats 段同样写“最早的 major 不能落在最后一集”。
- **最小反例**：总集数 1、唯一 major 的 `episode: 1`，结果需要 `1 < 1`。不可能通过，删掉 major 也失败。可执行完整输入：`tests/repro/single-episode-major.json`。
- **实测**：原版完整校验只报这一个问题；候选通过。另测两集只在末集出现 major 仍拒绝，单集无 major 仍拒绝。
- **已修**：仅为 `total === 1` 允许 `majors.includes(1)`；不放宽多集规则，同步三处说明。见对应 outline 补丁。

## 2. P0：台词校验按整段查找，错镜、额外台词和错误语言标签会通过

- **证据**：`skills/novel-storyboard/scripts/novel-storyboard.mjs:436–437` 用 `re.test(h3)`，查整个 segment；正则的标签是任意 `[^\]]+`，不是固定 Chinese。只检查被认领句子存在，不拒绝额外对白。
- **最小反例**：保留分镜、秒数及台词原文，只把属于 Shot 2 的 `<d>[Chinese] 刚才送错了包裹，要取回怀表。</d>` 移到同段 Shot 1；或向无台词镜头插入“门后一定是哥哥。”；或把 `[Chinese]` 改 `[English]`。完整输入在 `tests/repro/dialogue-*.json`。另有挪到音景字段的变体。
- **实测**：上述错镜、增词、错标签、挪音景原版均接受；候选均拒绝。新增重复块、未闭合块亦拒绝。
- **已修**：每个 cut 只查 `slices[ci]`，与其认领的**完整有序台词列表**对账，限制 Chinese 标签，并拒绝描述外、未归属和未闭合的台词块。没有修改剧本台词。
- **语言相关证据与界限**：storyboard schema 第 19 行默认 en，第 28 行却写默认中文；已改成英文。`h3Remainder` 允许双引号内画面文字；`frame` 则全面拦 CJK。故本例刻字走后期贴合，不能将中文字直接塞入 frame 并声称能过原门。原有语言检查仍是启发式，不证明全文语种、说话人或 VO 唇形语义正确；候选说明已明确。

## 3. P1：60 秒且最多 8 镜与默认 2–5 秒冲突；段/镜术语与参数又混用

- **证据**：`skills/novel-storyboard/SKILL.md:80,93` 写每切 2–5 秒硬门及每段 9–15 秒；脚本 `DEFAULT_PARAMS` 允许 `maxCutSeconds` 配置，segment 门只检查 `0 < total <= maxSegmentSeconds`，没有 9 秒下限。SKILL 接力表还写不存在的 `params.maxShotSeconds`、H3“每镜一段”，seed 说明写 shots 留空，真实字段为 segments。
- **最小反例**：8×5=40，小于 60；即使宽松接受 60 秒的 -15% 下限也要 51 秒，40 仍不够。`tests/repro/default-cadence-incompatible.json` 有完整 8 镜 60 秒输入，原默认逐镜拒绝。
- **已修/已有能力复用**：不改默认值、不造参数，仅在本例显式设 `maxCutSeconds: 8`，4 个 segment 各 15 秒；镜长 `7.5,7.5,7,8,7,8,7,8`。同步文档将默认档和硬上限区分，并纠正参数与层级。原脚本在这份原格式对照上加已有 maxCutSeconds=8 也能通过镜长门；单集 major 是另一处独立阻断。
- **产品建议**：先做约束可满足性检查，给出参数选择原因。9–15 秒若要成为硬门，应另行设计明确参数和场尾例外；本次没有偷偷新增这个硬门，样例自愿满足它。

## 4. P1：额外切镜不是零成本；参考顺序与“生成批次”不能充当调用或能力保证

- **证据**：`skills/novel-storyboard/SKILL.md:38` 原句“多切一镜的成本几乎为零”，`:99` 又要求一切一图、每格一次调用；`references/frame.md` 先挂环境/人物/道具。脚本 `computeStats:226` 的批次按 `sceneId|lighting` 分组，而 `exportPack:600–633` 的 Picture 序是每段 `f1,f2,…` 关键帧序。两个列表属于不同阶段。
- **最小反例**：本例只有 2 个场景光照批次，却有 4 段视频候选调用、8 张关键帧。新增一次切镜至少新增一张关键帧计划及下游整段和接缝 QC。把资产参考列表直接当 H3 Picture 列表会把时刻和图错配。
- **实测**：统计确为 2 批/4 段/8 镜；export 4 份提示词、8 张全部标缺失；修改第一切秒数而不改首行及 Shot 2 切点会被拒绝。
- **已修**：撤去零成本论断，纠正报告文案；文档区分资产参考顺序与按切点排列的分镜图。`production.json` 和 `shots.csv` 已列逐镜依赖、候选能力与局部重试影响，不编造节点、工作流 ID 或报价。
- **待运行验证**：固定首行逐字通过仅证明本地约定，不能证实服务接受 15 秒、按给定时刻锁帧、参考图数量或连续性。附件仅记录 H3 单个小样 124/24≈5.167 秒、98 RH 币；本次未验证视频文件、模型身份和动态质量，不能按此外推整片费用。

## 5. P1：cast 没有 C 编号，缺少统一身份桥；自由文本 carriedBy 没有闭合检查

- **证据**：`skills/novel-characters/references/schema.md` 角色卡以 name/aliases 为键，不含 id；outline、script、storyboard 使用 C01。`novel-art/references/schema.md` 的 `carriedBy` 是自由文本；art 校验只对 `relatedScenes` 做存在检查。原版《渡口》cast 有 4 张卡，而 outline 还登记 `C05` 更夫，五套 CLI 均能各自通过，并不代表每个编号都有资产。
- **最小反例**：按 cast 数组顺序绑定 C01/C02，排序交换后引用仍是合法 C 编号，脸却绑错；`carriedBy: ["不存在的人"]` 也不会被原 art 校验发现。
- **已做**：增加制作侧 `identity-map.json`，显式绑定 C01→林禾、C02→快递员，绝不按位置猜。Python 独立检查核对一对一、outline 名称、cast 存在、relationships、carriedBy、全部 C/S/P 和任务依赖。交换映射、未知持有人等变体实测拒绝。保留原 schema，不向 cast 硬塞 id。
- **界限**：这是生产侧新增检查，不宣称已经补强所有原校验器。VO 声源不建人脸，`delivery` 和制作侧信息写身份未知；既不新增画内人物，也不确认为哥哥本人。

## 6. P1：最终 9:16 与固定 16:9 分镜图要求冲突

- **证据**：`skills/novel-storyboard/SKILL.md:99`、`references/frame.md:7` 固定一张 16:9 关键帧；真实 JSON schema 没有画幅字段，原检查只查英文、景别与风格词。
- **最小反例**：将一个 frame 中的 `portrait 9:16` 换为 `landscape 16:9`，原 Node 校验仍通过。反例为 `tests/repro/wrong-aspect-original-validator-blindspot.json`。
- **已修**：分镜图按最终画幅，角色/道具/环境设定表仍允许 16:9 横排；不裁成九宫格，不虚构服务端 ratio 字段。主样例全部 frame 明写 portrait 9:16，制作侧 production/timeline 记画幅，Python 反例检查会拒绝横屏 frame。
- **待运行验证**：图片/视频 API 参数是否支持并正确输出竖屏未测试；仅靠提示词不能保证像素尺寸。

## 7. P1：三个 realistic 同名但视觉要求不同，不能满足严格摄影写实交接

- **证据**：`novel-characters/scripts/novel-characters.mjs:222` 强制包含 `Semi-realistic character illustration, painterly rendering…`；art 脚本第 28 行也强制 painterly；storyboard 第 74 行仅要求 `cinematic film still`。这是不同资产规范，不是同名就证明一致。
- **最小反例**：只写摄影写实、不带那句厚涂 render 的角色/场景 sheet 会被原版拒绝；加回厚涂句能过门，却又和摄影目标混搭。原 default 样例只能作为半写实对照。
- **已修（可选扩展）**：在三个预设表新增 `photorealistic`，给摄影渲染句、材质、反向词和标签；原 realistic/ghibli 内容与默认值不变。同步真实 schema 文档的**候选枚举**说明。检查新摄影档不能把 photorealistic 放反向词；所有旧样例回归仍通过。
- **兼容分界**：主样例的 style 值是候选扩展，原 art/storyboard 拒绝；`original-format/` 给出不含新枚举的完整对照。没有声称主样例兼容未经修改的原版。新档的图像视觉结果未验证。

## 8. P1：真实校验要求 hookBeat，schema 却没列出

- **证据**：`skills/novel-script/scripts/novel-script.mjs:148–165` 必须有 `[场,拍]`；`references/schema.md` 的 episode 表只有 ep、targetSeconds、hook、cliff、beatsClaimed、scenes。`hookWindow` 也在真实脚本默认参数中，schema 只介绍四个参数。
- **最小反例**：从本例已通过的 script 删除 `episodes[0].hookBeat`，即变成按文档所列字段填写的对象，原版报缺 hookBeat；完整输入在 `tests/repro/missing-undocumented-hookBeat.json`。
- **已修**：仅补 schema 的必填 hookBeat、1 起算规则与已存在的 hookWindow 参数，不更改已工作的剧本验证器。样例 `hookBeat: [1,3]` 指向取起旧怀表的具象。seed 是未完成底稿，不假装它已具备完整剧本。

## 9. P2：道具必须同时跨集，使单集核心道具落选

- **证据**：`skills/novel-art/references/prop-pass.md:7`：“三个条件同时满足…有特写、跨集出现、承载剧情”；SKILL 其他位置又说通常 3–8 件。单集自然不可能跨集。
- **最小反例**：本例怀表和铜钥匙均承载悬疑，有细节镜头，但只有一集。机械执行原选取说明会把它们删掉，分镜失去可核对的核心资产；这不是 art 验证器要求的下限。
- **已修**：改为承载剧情，且有特写、状态变化或跨镜/跨集复用之一；保留数量建议，不凑到 3 件。交付两件道具完整状态、尺度、锚点和引用。未生成状态参考，计划中都不是实际文件。

## 10. P2：角色原自测在上传的 CRLF 原文上误报

- **证据**：原 `novel-characters/scripts/novel-characters.mjs:26` 把 CRLF 改 LF；`scripts/selftest.mjs:57,61` 却在原始 `SOURCE.repeat(150)` 中查规范化的片段。上传《渡口.txt》有 24 个 CRLF。
- **最小反例**：`raw.repeat(150).includes(chunkText(raw.repeat(150))[0].slice(0,200))` 为 false；对 raw 同样规范化后为 true。`tests/regression.mjs` 有完整读取与断言，不依赖远端材料。
- **实测**：原版自测 exit 1，“块内容来自原文”失败；后续原版断言未继续跑。原版 cast CLI 验证本身成功，不能误诊为拆块算法损坏。
- **已修**：只规范化自测的 long 输入，保留所有断言，不改原文与拆块算法。候选角色自测实测 313 项通过，其他四套共 704 项通过；原始失败日志保留。

## 五份 JSON 的交接核对

| 项 | 上传原版与压力点 | 本次可检查的结果 |
| --- | --- | --- |
| ID | outline 定义 C/S/B，art 定义 S/P，script 引 C/S/P，board 用 sceneIndex+beats | 本例 C01/C02、S01、P01/P02 全闭合，编号唯一；同一 S01 的两次场次不另算实体场景 |
| 人物 | cast 仅名字，VO 可绕过人脸名册 | 独立映射一对一；台词 VO 明记来源未知，不创建哥哥脸 |
| 类型 | 上游是 Markdown 结构约定+手写校验，并非正式 JSON Schema 文件 | 五 JSON 均解析并跑真实 Node；独立检查关键对象/数组/字符串/布尔/有限数值，包含布尔冒充秒数反例；不声称穷举所有畸形输入 |
| 时长 | script 按动作数与字数估计，board 只保证目标容差 | script 19×2.5+20/4.5=51.9444 秒；board 60 秒；逐镜另排 8.0556 秒停顿，候选分镜 tolerance=0 |
| 台词 | 原语句可在同段放错镜仍过门 | 两句共 20 个含标点字符；逐镜有序 `<d>[Chinese]` 校验，额外台词拒绝 |
| 提示词 | frame 英文；H3 默认英文但 schema 一处写中文；中文画面文字有例外 | frame 纯英文，刻字后期补；H3 英文、台词保留中文；人类字段中文；语言判断仍非自然语言完整验证 |
| 批次与参考 | 同 sceneId/lighting 为排产组，不是一次视频调用 | 2 个组、4 段、8 帧；资产参考和 H3 Picture 列表分别记录，所有 PNG 缺失明确标注 |

## 待运行验证（本次未执行）

没有图像/TTS/H3/RH/Krea2 调用，没有真实音轨或视频文件验证；不确认模型身份、费用上限、多参考上限、15 秒请求支持、按时刻切镜、精准刻字、身份保持、口型、画幅服务参数或动态质量。任务二 A/B 图片评价与任务三恢复状态机未做。完整清单在 UNVERIFIED.md。

## 产品建议（不假装已实现）

把身份映射、生产侧画幅、来源证据和资产版本提为明确交接契约；在任何将来的收费生成前先验证服务可用模式与价格，按段而非排产组估调用量；设置局部返修和接缝复核。可以保留本文候选模板，但当前不改整个前端，也不为已运行队列、用户验收或模型能力背书。

全部运行日志、精确命令和退出码见 `tests/results/summary.json`；源代码补丁实际应用且与候选逐字节一致。当前结论为**离线审查与制作候选完成，媒体生成未执行**。
