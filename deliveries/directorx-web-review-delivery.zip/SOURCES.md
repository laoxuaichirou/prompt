# 材料出处与修改说明

唯一来源：本会话上传 `DirectorX-WebGPT-Review.zip`。原文件夹为 `网页GPT审查包/`。输入 ZIP 和每个条目的 SHA256、字节数及读取范围见 `tests/input-inventory.json`。

`upstream/skills/` 保留上传的五套 Skill 原文件，包括示例、参考文档、脚本和自测，未规范化换行或更改内容。`upstream/材料来源.json` 逐字节保留原出处，里面的 G:/E: 路径只是文本，未访问。没有可独立确认的远端仓库 URL 或 commit，因此不声称这对应公开仓库的某一版本。

`LICENSE.upstream` 为上传许可证原文，Apache License 2.0，保留原有声明。候选为本次独立审查修改，逐文件差异位于 patches/；没有给第三方源文件改写许可声明，也没有复制并不存在的上游 NOTICE。本次没有查询外部许可或仓库。

修改分组：

1. 必要缺陷修复：outline 单集 major 例外；storyboard 逐镜完整台词对账；characters CRLF 自测误报；script schema 补已有必填 hookBeat。
2. 必要说明修正：段/镜参数名称，默认与硬门、最终画幅与横排设定表、成本/批次与参考图顺序，单集道具选取、离线执行边界。
3. 可选摄影扩展：characters/art/storyboard 新增 `photorealistic` 预设，原两个预设及默认值保留。art自测的枚举断言同步扩展，不删测试；新增摄影反向词回归。
4. 新写内容：审查报告、修表店 JSON 与制作计划、独立脚本、反例、可复用离线指令、打包与哈希工具。它们不是上游已有实现。

有些原文末尾无换行，补丁使用标准 `\ No newline at end of file` 标记并保留其他行尾；实际应用已验证。MANIFEST.json 对自身不列哈希，避免自引用循环；其余实际打包文件均有用途和 SHA256。不要把清单、H3缺图manifest与源项目中的同名文件混淆。
