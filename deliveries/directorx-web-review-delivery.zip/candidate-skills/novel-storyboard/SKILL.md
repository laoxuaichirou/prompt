
name: novel-storyboard
description: |
  给 AI 短剧出分镜：三层结构——段（一次视频生成，≤15 秒）→ 分镜（段内 2–5 秒的剪切，认领剧本节拍）
  → 分镜图（每切一张关键帧：主分镜图钉 0.00 秒，子分镜图钉各自切点）。
  每段自带一条 MiniMax H3 视频提示词（官方口径默认英文、逐镜换行，promptLang 可切中文）：对齐指令和
  [Shot k] 切点时刻由分镜结构推导、逐字对账，台词逐字进 <d> 块（写法规范已内化为
  references/h3-prompt.md，不依赖外部 skill）。
  产出 storyboard.json + Markdown，用 directorx_bible 钉到画布评审。分镜图出图拿场景与角色设定图当参考图，走 DirectorX 生成闸（可选，占位先行）。
  16 道质量门全部由脚本确定性检查；export 一键导出 H3 投产包（每段提示词 + 按 Picture 序的分镜图清单）。零依赖、零 API key，用当前会话额度。
  Use when asked to 分镜、出分镜、镜头表、切镜、storyboard for AI short drama。
allowed-tools:
  - Read
  - Write
  - Bash
  - Task
  - Glob
triggers:
  - novel-storyboard
  - 分镜
  - 出分镜
  - 镜头表
  - 切镜
  - 首帧
  - storyboard
  - shot list
metadata:
  license: Apache-2.0
  requires:
    bins:
      - node          # >= 18，只用标准库，无 npm 依赖
    optional:
      - directorx      # 有生成能力才出首帧图；没有就只交提示词，其余照常
tags: [novel, storyboard, adaptation, preproduction]

## novel-storyboard

给 AI 短剧出**分镜**——管线里第一个直接面对视频模型的层。**成本前提：每切会新增关键帧、参考依赖和连续性核对，多切镜头不能按零成本估算**，所以这里不心疼镜头数量，上限只有一个：视频模型单段生成的时长（默认 15 秒）。

**核心机制：镜头认领节拍。** 每个镜头声明它覆盖剧本某场的哪几个连续节拍（`sceneIndex` + `beats: [起, 止]`），镜头不许跨场次——换景必换镜。这让分镜和剧本的关系变成可机械对账的：

| 交付 | 解决什么 |
| --- | --- |
| 节拍认领 | 每个节拍被恰好一个镜头认领、顺序不乱——剧本改了重跑 validate，失效的镜头当场点名 |
| 段与分镜分别限时 | 段上限用已有 `params.maxSegmentSeconds`；分镜区间用已有 `minCutSeconds` / `maxCutSeconds`。不存在 maxShotSeconds 字段 |
| 台词装得下 | 认领节拍的台词秒数 ≤ 镜头秒数——逐镜检查，不是拍脑袋 |
| 首帧 + 运动双提示词 | 首帧给图像模型（配合参考图），运动是模型无关的过程描述；景别、运镜是枚举，英文短语必须写进对应提示词 |
| **H3 视频提示词（每个 segment 一条）** | MiniMax H3 的 I2VA 结构：固定对齐指令 + integrated_multimodal_description + overall_soundscape + non_diegetic_music。**认领节拍的台词逐字进 `<d>[Chinese] …</d>` 块**——对白、声景、配乐一段提示词全带上 |
| 生成批次单 | 同场景 + 同光照的镜头归一批，共用同一张环境参考图——AI 版的顺场表，脚本自动汇总 |
| 配音对齐单 | 每句台词对到镜号——TTS 音频贴到哪一段视频，脚本自动汇总 |

`${CLAUDE_SKILL_DIR}` = 本文件所在目录。脚本 `${CLAUDE_SKILL_DIR}/scripts/novel-storyboard.mjs`，零依赖，`node` 直接跑。

**边界（不做的事）**：不写戏不改台词（`novel-script` 的活）、不出场景/角色/道具设定图（`novel-art` / `novel-characters` 的活）、不做视频生成与剪辑合成。口型/唇形同步暂不管——那是生成管线的事。

### Step 0 — 定输入与范围

**script.json 是硬前提**——分镜离开剧本没有意义，validate/render 都必须给 `--script`。其余上游按有则用：

- `--outline` / `--cast`：提示词禁人名检查 + 报告里 C01 显示成人名
- `--art`：报告里 S01 显示成场景名 + 批次单嵌场景设定图

**一次切几集**：跟剧本的批次走（剧本写到哪就分到哪），默认一批 ≤ 3 集。

### Step 1 — seed 工作底稿

```bash
node ${CLAUDE_SKILL_DIR}/scripts/novel-storyboard.mjs seed <script.json> --eps 1-3 > <workdir>/storyboard.json
```

确定性展开：每场的节拍清单（编号、动作/台词、每拍秒数、说话人）进 `seedScenes`，这就是切镜时的工作底稿。**每拍几秒是算出来的，不要让模型重新估。** segments 留空，切镜才是模型的活。

### Step 2 — 逐集分段切镜

每集一份任务，能并发就并发。每份任务拿到：

- `${CLAUDE_SKILL_DIR}/references/storyboard-pass.md` 和 `${CLAUDE_SKILL_DIR}/references/schema.md`（读它们，照着做）
- 该集的 seedScenes 底稿 + 场景卡（art.json 的锚点与光照提示词）+ 角色卡（cast.json 的形象要点）

流程：**先按剧情单元分段**（每段 9–15 秒、不跨场），**段内切 2–5 秒的分镜**。分镜只认领剧本节拍，不发明情节。切之前 `directorx_shot_vocab` 查这一刀怎么切、什么时候别用（对话正反打、进场三件套、反应插入），再写分镜图提示词。

**每段写一条 `h3Prompt`**，照 `${CLAUDE_SKILL_DIR}/references/h3-prompt.md` 写（官方方法论的内化版，**不依赖任何外部 skill**）。官方口径默认英文（`promptLang` 可切中文），**每个镜头独立一行**。要点：首行对齐指令和 `[Shot k]` 切点时刻**由分镜秒数推导，一个字符都不许漂**（validate 逐字对账）；认领台词**逐字**进 `<d>[Chinese] …</d>`；每切的运镜词写进自己那一行；声景与配乐分进后两个字段——**声景也是动作指令，画面改了声景一起改**。

切完把 `seedScenes` 删掉。

### Step 3 — 校验 ⛔ 不能跳

```bash
node ${CLAUDE_SKILL_DIR}/scripts/novel-storyboard.mjs validate <storyboard.json> \
  --script <script.json> --outline <outline.json> --cast <cast.json>
```

16 道质量门全是代码：节拍全覆盖（分镜级，恰好一次、按顺序、连续）、段 0 < 总秒 ≤ 15、**每切 2–5 秒**、台词装得进分镜、每集总时长在剧本目标 ±15% 内、同框 ≤ 3 人（超了必须带拆解说明）、段号 E01-01 格式连号、景别短语在分镜图提示词里、**风格短语统一**（`style` 预设 realistic/ghibli 与角色/场景 skill 同名对齐，同剧分镜图不许画风漂）、运镜用 H3 词表且在自己的 [Shot k] 段落里、**H3 对齐指令由分镜结构推导逐字对账 + 切点时刻逐个对**、**认领台词逐字进 `<d>` 块**、**提示词语言与 promptLang 一致**（双向查：中文写成英文、英文混进中文都拦）、分镜图提示词全英文非空、英文提示词不含角色名（中文 H3 提示词放行）、场次/人物/道具对账剧本。

**有违规逐条修，改完重跑，直到通过。**

### Step 4 — 出分镜图（可选）

一切一张目标画幅关键帧（本案例 9:16），读 `${CLAUDE_SKILL_DIR}/references/frame.md` 照构图与质检要求做。出图走 DirectorX 生成闸：

- **预算先收敛 + 试点先行**：先出第一段的整套分镜图（3–5 张）给用户验收，通过后其余段**全部占位**进 `directorx_propose`，用户确认后再生成
- **没有生成能力就整步跳过**，只交提示词，评审卡显示占位不装有
- **参考图是命根子**：`-i` 挂上该段场景设定图（该光照状态）+ 画内角色的设定图 + 涉及道具的设定图，提示词只负责取景和此刻的姿态
- 一格一次调用绝不批量；输出 `./<段号>/f<切序>.png`（f1 = 主分镜图，每段一个文件夹）
- **默认先出第一段的整套分镜图给用户看效果**（3–5 张），确认画风和正反打构图再往后补——一集约 30–40 格，错了浪费的是整批
- 单个失败跳过不阻断，最后汇总说明

### Step 5 — 输出与汇报

```bash
cd <输出目录>
node ${CLAUDE_SKILL_DIR}/scripts/novel-storyboard.mjs render <剧名>-storyboard.json --md \
  --script <script.json> --outline <outline.json> --art <art.json> > <剧名>-storyboard.md
```

不要另出 HTML。`directorx_bible pin kind:storyboard` 把质量门、时长和分镜表钉到画布。Markdown 每段附完整提示词，DSH 会话可以直接展示。

汇报一句话说清：几集几镜、总时长 vs 目标、几个生成批次、出了几张首帧；没过的门和没出的图明说。

最终落地：

```
<输出目录>/
├── <剧名>-storyboard.json
├── <剧名>-storyboard.md
├── docs/storyboard-review.md
├── manifest.json                  ← export 生成
└── E01-01/                        ← 一段一个文件夹 = 一次生成的全部材料
    ├── f1.png                     ← 主分镜图
    ├── f2.png …
    └── prompt.md
```

## 五个 skill 的接力（管线到此闭环）

```
novel-characters → cast.json       （谁：角色设定图）
novel-outline    → outline.json    （什么：结构与分集）
novel-art        → art.json        （哪里：场景/道具设定图）
novel-script     → script.json     （戏：场次、节拍、台词）
novel-storyboard → storyboard.json （怎么拍：镜头、首帧、批次）
```

分镜是消费端：seed 吃 script.json，只映射不发明。分镜图出图吃 art 和 characters 的设定图当参考。五份 JSON 用 `directorx_bible` 评审，改完再 validate。

## 边界

- 报告界面内置中英（`--lang`，默认中文）；提示词语言由 `promptLang` 单独控制（默认英文）
- 秒数是**下给视频模型的生成时长**不是估算——段上限按你的模型改 `params.maxSegmentSeconds`，切的节奏区间改 `min/maxCutSeconds`
- 口型/唇形同步暂不管——那是生成管线的事
- 分镜图不追求一次到位——它是给视频模型的构图锚，构图对、资产对就够，微调交给重生成

## 知识库参考

以下知识库主题在分镜工作流的不同阶段提供方法论支撑。路径相对于 `${CLAUDE_SKILL_DIR}/../../knowledge/`。

### 切镜阶段（Step 2）

| 主题 | 何时查阅 |
| --- | --- |
| [107-keyframe-animatic](../../knowledge/107-keyframe-animatic) | 理解关键帧与动态分镜的关系，决定主分镜图与子分镜图的构图策略 |
| [109-shot-notation](../../knowledge/109-shot-notation) | 镜头标注规范——景别枚举、运镜短语的标准写法，直接用在分镜 JSON 和提示词里 |
| [124-shot-language-gen](../../knowledge/124-shot-language-gen) | AI 生成语境下的镜头语言选择——哪些景别/运镜组合对视频模型友好 |
| [127-edit-transition-rhythm](../../knowledge/127-edit-transition-rhythm) | 剪辑节奏与转场逻辑——决定段内切镜密度和段间衔接方式 |

### 提示词撰写阶段（Step 2 后半）

| 主题 | 何时查阅 |
| --- | --- |
| [115-video-prompt-engineering](../../knowledge/115-video-prompt-engineering) | 视频提示词工程方法论——H3 提示词的结构、权重、负面提示写法 |
| [116-image-to-video-control](../../knowledge/116-image-to-video-control) | 图生视频的控制技巧——如何让首帧图在视频生成中保持构图意图 |
| [130-prompt-template-library](../../knowledge/130-prompt-template-library) | 提示词模板库——可直接复用的句式片段，加速 H3 提示词撰写 |
| [114-ai-video-model-matrix](../../knowledge/114-ai-video-model-matrix) | 视频模型能力矩阵——了解不同模型在时长、分辨率、一致性上的边界，调整 `params` 参数 |

### 一致性保障（贯穿全流程）

| 主题 | 何时查阅 |
| --- | --- |
| [117-ai-consistency-system](../../knowledge/117-ai-consistency-system) | AI 一致性系统——角色/场景跨镜头保持一致的完整方案，validate 门 11（风格统一）的理论基础 |

### 视觉基底

| 主题 | 何时查阅 |
| --- | --- |
| [00-visual-glossary](../../knowledge/00-visual-glossary) | 视觉术语表——确认景别、光照、构图等术语的精确含义，避免提示词用词歧义 |
| [09-lighting-color](../../knowledge/09-lighting-color) | 光照与色彩语言——配合 art.json 的光照状态，确保提示词中光照描述与场景设定对齐 |

## 自测

```bash
node ${CLAUDE_SKILL_DIR}/scripts/selftest.mjs
```

183 项断言，不调模型、不花额度。16 道质量门每一道都有击穿用例。改完脚本先跑这个。

## 自带样例

`${CLAUDE_SKILL_DIR}/examples/渡口-storyboard.json`：《渡口》第 1 集完整分镜——10 段 34 切认领剧本全部 35 拍，平均 3.5 秒一切，共 119 秒 / 目标 120 秒，2 个生成批次，每段带完整的 H3 视频提示词（多图对齐 + 切点时刻全部对账通过）。当质量基准，也是自测夹具。

## 离线审查候选补充（优先适用于本次评审）

只使用已提供材料；用户要求离线时只产出 JSON、提示词与确定性检查，不执行本文出图、画布或外部知识库步骤。新增摄影写实选项 `photorealistic`，原 realistic 是半写实厚涂，不能仅因同名就宣称三层视觉一致。生成次数、重试与连续性核对都有成本，须单列参考依赖和调用数；同场景光照批次不代表一次视频调用。


## 离线审查候选：镜长、画幅与生成能力边界

上文 2–5 秒为默认节奏档，不是普适硬门。60 秒且最多 8 镜与默认档不兼容（8×5=40）；本案例显式设已有参数 maxCutSeconds=8，保留 minCutSeconds=2、maxSegmentSeconds=15，排 4 段各 15 秒、共 8 镜。9–15 秒是编排建议，现有脚本只守 0<段长≤上限；不得说脚本已检查 9 秒下限。

生成关键帧按最终成片画幅，本案例 9:16；上游 16:9 资产设定表仍可横排。画幅不在现有 JSON schema 中，以制作侧配置记录并在 frame 明写 portrait 9:16，不新造字段冒充原结构。每切新增关键帧、引用和检查；重试可能影响整段及相邻连续性。

场景/人物/道具参考是生成分镜图的输入；H3 的 Picture 1..N 是生成后按切点排序的分镜图，不能混为同一列表。固定首行和逐字切点只证实格式对账，未证实服务按时刻锁帧、多参考可用数、音画连续性或模型遵从率。本次不执行生成。Krea2 仅待选，Qwen2.1 有附件所述有限调用，H3 仅有单个云端小样完成证据；任一收费下单前需独立验证目标时长/模式/费用。
