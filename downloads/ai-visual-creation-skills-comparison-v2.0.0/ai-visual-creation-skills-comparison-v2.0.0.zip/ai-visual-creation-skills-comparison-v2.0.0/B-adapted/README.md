# B：此前整理的改编版

此目录的5个 Skill 连同其内部参考文件，逐字节沿用 v1.0.0：

- creative-workflow-planner
- image-storyboard-director
- visual-consistency-reviewer
- video-prompt-director
- context-driven-dev

标记应为“有历史图片方法实验依据的改编版”，而不是“5个均已验证通过的优化版”。历史实验发生在这些 Skill 打包之前，不能倒推为加载这5份文件的端到端测试。

为保持对照，未根据新测试结果再修改B。`background-notes/` 也来自v1，用于查阅；当前测试范围与证据解释以本包 comparison/ 和根目录 README 为准。
