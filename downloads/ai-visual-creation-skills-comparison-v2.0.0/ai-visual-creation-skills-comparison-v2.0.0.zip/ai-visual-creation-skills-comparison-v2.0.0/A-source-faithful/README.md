# A：原始与忠实封装

| Skill | 分类 | 来源 |
|---|---|---|
| seedance-director | 原始 Skill，逐字节复制 | 用户上传 SKILL.md |
| ctx-6-dev | 原始 Skill，从RAR逐字节提取 | ctx-6-dev.rar |
| tutorial-canvas-foundation | 新制作的忠实封装 | 第1期课程 |
| tutorial-film-production | 新制作的忠实封装 | 第2期课程 |
| ash-swordswoman-source | 原提示词载体，正文不改写 | 灰烬剑姬10秒稿 |
| crimson-blade-source | 原提示词载体，正文不改写 | 红莲利刃15秒稿 |
| visual-ad-source | 原提示词载体，保留重复和矛盾供核对 | 提示词(1).txt |

后五个是本次整理出来的 Skill，不能称为作者原版。课程封装依据和物理页码见各自 references；提示词完整原文保存在各自 references/source.txt。

原文中的模型能力和技术结论属于材料陈述，未因保留原文而得到验证。原版规则与宿主不兼容时如实记录；任何必要的运行适配均另存，并在对照中披露。
