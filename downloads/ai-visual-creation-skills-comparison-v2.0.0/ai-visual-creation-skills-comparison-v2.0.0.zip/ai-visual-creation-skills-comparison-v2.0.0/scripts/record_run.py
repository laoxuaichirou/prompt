#!/usr/bin/env python3
"""Record files from a real user test; no model calls or quality judgments."""
import argparse
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path


def describe(path):
    path = Path(path)
    if not path.is_file():
        raise ValueError(f"File does not exist: {path}")
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return {"filename": path.name, "size_bytes": path.stat().st_size,
            "sha256": digest.hexdigest()}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pair", required=True, choices=["P1", "P2", "P3", "P4", "case"])
    parser.add_argument("--arm", required=True, choices=["A", "B"])
    parser.add_argument("--trial", required=True, type=int)
    parser.add_argument("--mode", required=True, choices=["text", "image", "video", "code"])
    parser.add_argument("--input", required=True, help="Actual submitted prompt or task file")
    parser.add_argument("--output", required=True, nargs="+", help="Actual output files")
    parser.add_argument("--reference", action="append", default=[])
    parser.add_argument("--skill", help="SKILL.md used for this run")
    parser.add_argument("--model", default="unknown")
    parser.add_argument("--seed", default="not-provided")
    parser.add_argument("--stage", choices=["initial", "revision"], default="initial")
    parser.add_argument("--note", default="")
    parser.add_argument("--out", required=True, help="New JSON record file; existing file is not overwritten")
    args = parser.parse_args()
    if args.trial < 1:
        parser.error("--trial must be positive")
    try:
        record = {
            "recorded_at_utc": datetime.now(timezone.utc).isoformat(),
            "pair": args.pair, "arm": args.arm, "trial": args.trial,
            "mode": args.mode, "stage": args.stage,
            "model": args.model, "seed": args.seed,
            "skill": describe(args.skill) if args.skill else None,
            "input": describe(args.input),
            "references": [describe(path) for path in args.reference],
            "outputs": [describe(path) for path in args.output],
            "status": "output-files-recorded",
            "quality_evaluation": "not-evaluated",
            "note": args.note,
        }
        target = Path(args.out)
        target.parent.mkdir(parents=True, exist_ok=True)
        with target.open("x", encoding="utf-8") as stream:
            json.dump(record, stream, ensure_ascii=False, indent=2)
            stream.write("\n")
    except (OSError, ValueError) as error:
        parser.exit(1, f"Could not record run: {error}\n")
    print(target)


if __name__ == "__main__":
    main()
